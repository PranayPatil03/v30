﻿using CRISP.Application.DTOs;
using CRISP.Domain.Entities;

namespace CRISP.Application.Mappings;

// Validations: ValidationDefinition (entity) <-> ValidationDefinitionDto
public static class ValidationMappings
{
    public static ValidationDefinitionDto ToDto(this ValidationDefinition entity) =>
        new()
        {
            ValidationDefinitionId = entity.ValidationDefinitionId,
            IndustryParameterMappingId = entity.IndustryParameterMappingId,
            ValidationType = entity.ValidationName,
            ValidationDescription = entity.Expression,
            ErrorMessage = entity.ErrorMessage,
            DisplayOrder = entity.DisplayOrder,
            IsActive = entity.IsActive
        };

    public static ValidationDefinition ToEntity(this ValidationDefinitionDto dto, int industryParameterMappingId) =>
        new()
        {
            IndustryParameterMappingId = industryParameterMappingId,
            ValidationName = dto.ValidationType?.Trim() ?? string.Empty,
            Expression = dto.ValidationDescription?.Trim() ?? string.Empty,
            ErrorMessage = dto.ErrorMessage?.Trim() ?? string.Empty,
            DisplayOrder = dto.DisplayOrder,
            IsActive = true
        };
}