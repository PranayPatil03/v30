﻿using CRISP.Application.DTOs;
using CRISP.Domain.Entities;

namespace CRISP.Application.Mappings;

// Score Configuration: scale + score rows (entities) <-> ScoreConfigurationDto
public static class ScoreConfigurationMappings
{
    public static ScoreConfigurationDto ToDto(
        int industryParameterMappingId,
        ScaleConfiguration? scale,
        IEnumerable<ScaleConfigurationDetails> details) =>
        new()
        {
            IndustryParameterMappingId = industryParameterMappingId,
            ScaleConfigurationId = scale?.ScaleConfigurationId,
            ScaleCode = scale?.ScaleCode ?? string.Empty,
            ScaleName = scale?.ScaleName ?? string.Empty,
            MinValue = scale?.MinValue ?? 0,
            MaxValue = scale?.MaxValue ?? 0,
            Scores = details
                .OrderByScore()
                .Select(x => new ScoreDto
                {
                    Score = ScoreValues.Display(x.ScoreValue),
                    Definition = x.Definition,
                    MinValue = x.MinValue,
                    MaxValue = x.MaxValue,
                    MinInclusive = true,
                    MaxInclusive = true
                })
                .ToList()
        };

    // one score row of the request; the description is kept from the existing row
    public static ScaleConfigurationDetails ToEntity(
        this ScoreDto score,
        int industryParameterMappingId,
        string? existingDescription) =>
        new()
        {
            IndustryParameterMappingId = industryParameterMappingId,
            ScoreValue = ScoreValues.Display(score.Score),
            Definition = score.Definition?.Trim() ?? string.Empty,
            ScoreDescription = existingDescription,
            MinValue = score.MinValue ?? 0m,
            MaxValue = score.MaxValue ?? 0m
        };
}