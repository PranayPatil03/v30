﻿using CRISP.Application.DTOs;
using CRISP.Domain.Entities;

namespace CRISP.Application.Mappings;

// Industry Parameter Mapping: one grid row per parameter master <-> IndustryParameterMapping (entity)
public static class IndustryParameterMappingMappings
{
    // a grid row: the master, its mapping in this version (if any) and defaults for unmapped masters
    public static IndustryParameterMappingDto ToDto(
        this ParameterDefinitionMaster master,
        IndustryParameterMapping? mapping,
        IReadOnlyList<IndustryParameterMapping> versionMappings,
        int? scaleConfigurationId,
        int? jsonDisplayOrder) =>
        new()
        {
            IndustryParameterMappingId = mapping?.IndustryParameterMappingId ?? 0,
            ParameterDefinitionMasterId = master.ParameterDefinitionMasterId,
            ParameterCode = master.ParameterCode,
            MasterParameterName = master.ParameterName,
            StepName = string.IsNullOrWhiteSpace(mapping?.StepName) ? "Business" : mapping.StepName.Trim(),
            ControlType = mapping?.ControlType ?? "Score",
            IsMapped = mapping?.IsActive == true,
            ParameterDisplayName = string.IsNullOrWhiteSpace(mapping?.ParameterDisplayName)
                ? master.ParameterName
                : mapping.ParameterDisplayName,
            // new mappings follow the master's "Value Driven"
            ValueType = mapping?.ValueType ?? (master.IsValueDriven ? "Value" : "ManualScore"),
            Weight = mapping?.Weight ?? 0m,
            ScaleConfigurationId = scaleConfigurationId,
            DisplayOrder = mapping?.DisplayOrder > 0 ? mapping.DisplayOrder : jsonDisplayOrder ?? 99,
            ParentParameterDefinitionMasterId = mapping?.ParentIndustryParameterMappingId is int parentId
                ? versionMappings.FirstOrDefault(x => x.IndustryParameterMappingId == parentId)?.ParameterDefinitionMasterId
                : null,
            YearFromOffset = mapping?.YearFromOffset,
            YearColumns = mapping?.YearColumns,
            SectionName = mapping?.SectionName,
            OptionsSource = mapping?.OptionsSource
        };

    // copies a ticked grid row onto the mapping entity
    public static void ApplyTo(this IndustryParameterMappingDto row, IndustryParameterMapping mapping)
    {
        mapping.ParameterDisplayName = string.IsNullOrWhiteSpace(row.ParameterDisplayName)
            ? row.MasterParameterName
            : row.ParameterDisplayName.Trim();
        mapping.ValueType = string.IsNullOrWhiteSpace(row.ValueType) ? "ManualScore" : row.ValueType.Trim();
        mapping.StepName = row.StepName;
        mapping.ControlType = row.ControlType;
        mapping.Weight = row.Weight;
        mapping.DisplayOrder = row.DisplayOrder > 0 ? row.DisplayOrder : 99;
        mapping.YearFromOffset = row.YearFromOffset;
        mapping.YearColumns = row.YearColumns;
        mapping.SectionName = string.IsNullOrWhiteSpace(row.SectionName) ? null : row.SectionName.Trim();
        mapping.OptionsSource = string.IsNullOrWhiteSpace(row.OptionsSource) ? null : row.OptionsSource.Trim();
        mapping.IsActive = true;
    }
}