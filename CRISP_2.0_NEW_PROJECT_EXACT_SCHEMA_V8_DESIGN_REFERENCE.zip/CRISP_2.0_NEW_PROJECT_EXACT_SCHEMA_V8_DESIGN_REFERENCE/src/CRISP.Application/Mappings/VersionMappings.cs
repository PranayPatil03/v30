﻿using CRISP.Application.DTOs;
using CRISP.Domain.Entities;

namespace CRISP.Application.Mappings;

// WorkflowJsonVersion (entity) -> VersionDto
public static class VersionMappings
{
    public static VersionDto ToDto(this WorkflowJsonVersion version) =>
        new(
            version.WorkflowJsonVersionId,
            version.VersionNo,
            version.VersionName,
            version.Status,
            version.IsPublished,
            DateTime.UtcNow,
            "Admin")
        {
            JsonContent = version.JsonContent,
            OverallWeightage = 100m
        };
}