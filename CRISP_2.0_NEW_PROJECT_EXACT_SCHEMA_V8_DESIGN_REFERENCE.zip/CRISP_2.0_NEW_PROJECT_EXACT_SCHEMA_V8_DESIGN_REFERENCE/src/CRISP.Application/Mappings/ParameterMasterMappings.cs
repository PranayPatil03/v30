﻿using CRISP.Application.DTOs;
using CRISP.Domain.Entities;

namespace CRISP.Application.Mappings;

// Parameter Master: entity <-> DTO (the repository works with the entity only)
public static class ParameterMasterMappings
{
    public static ParameterDto ToDto(this ParameterDefinitionMaster master) =>
        new(
            master.ParameterDefinitionMasterId,
            master.ParameterCode,
            master.ParameterName,
            master.WhyItMatters,
            master.HowDoWeMeasure,
            0m,
            0,
            master.IsValueDriven,
            [])
        {
            IsActive = master.IsActive
        };

    // copies the editable fields of the form onto the entity
    public static void Apply(this ParameterDto dto, ParameterDefinitionMaster master)
    {
        master.ParameterCode = dto.ParameterCode.Trim();
        master.ParameterName = dto.ParameterName.Trim();
        master.WhyItMatters = dto.WhyItMatters?.Trim() ?? string.Empty;
        master.HowDoWeMeasure = dto.HowDoWeMeasure?.Trim() ?? string.Empty;
        master.IsValueDriven = dto.IsValueDriven;
        master.IsActive = dto.IsActive;
    }
}