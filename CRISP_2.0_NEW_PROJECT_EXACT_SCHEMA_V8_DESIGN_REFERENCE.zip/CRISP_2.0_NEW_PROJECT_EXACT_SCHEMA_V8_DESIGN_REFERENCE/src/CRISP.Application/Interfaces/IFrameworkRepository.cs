using CRISP.Application.DTOs;
using CRISP.Domain.Entities;
namespace CRISP.Application.Interfaces;

public interface IFrameworkRepository
{
    Task<IReadOnlyList<WorkflowDto>> GetWorkflowsAsync(CancellationToken ct = default);
    Task<WorkflowDto> CreateWorkflowAsync(CreateWorkflowRequest request, string skeletonJson, CancellationToken ct = default);
    Task<WorkflowContextDto?> GetWorkflowContextAsync(string workflowCode, CancellationToken ct = default);
    Task<IReadOnlyList<EntityDto>> SearchEntitiesAsync(string? search, CancellationToken ct = default);
    Task<IReadOnlyList<FrameworkLookupDto>>
GetFrameworkOptionsAsync(
    int entityId,
    CancellationToken ct = default);
    Task<IReadOnlyList<IndustrySegmentDto>> GetIndustrySegmentsAsync(string workflowCode, CancellationToken ct = default);
    Task<IReadOnlyList<FrameworkStepDto>> GetStepsAsync(string workflowCode, CancellationToken ct = default);
    Task<IReadOnlyList<FrameworkListDto>> GetFrameworksAsync(CancellationToken ct = default);
    Task<ParameterDto?> GetParameterAsync(int parameterId, CancellationToken ct = default);
    Task<IReadOnlyList<ParameterDto>> GetParametersAsync(string code, CancellationToken ct = default);
    Task<IReadOnlyList<IndustrySegmentDto>> GetAllIndustriesAsync(
    CancellationToken ct = default);


    Task<FrameworkDto?> GetFrameworkAsync(int id, int? versionNo = null, CancellationToken ct = default);
    Task<FrameworkDto?> GetFrameworkShellAsync(int id, CancellationToken ct = default);
    Task<IReadOnlyList<FrameworkParameterDto>> GetFrameworkParameterValuesAsync(int id, CancellationToken ct = default);
    Task<string?> GetFrameworkValueJsonAsync(int frameworkId, CancellationToken ct = default);
    Task<string?> GetFrameworkValueJsonAsync(int frameworkId, int versionNo, CancellationToken ct = default);
    Task SaveFrameworkValueJsonAsync(int frameworkId, int versionNo, string jsonContent, CancellationToken ct = default);
    Task ClearFrameworkValueJsonAsync(int frameworkId, CancellationToken ct = default);
    Task<FrameworkDto> SaveFrameworkAsync(FrameworkDto framework, CancellationToken ct = default);

    // ---------------------------------------------------------------- parameter master (entities only)

    // all masters, active and inactive
    Task<List<ParameterDefinitionMaster>> GetParameterMastersAsync(
        CancellationToken ct = default);

    Task<ParameterDefinitionMaster?> GetParameterMasterAsync(
        int parameterDefinitionMasterId,
        CancellationToken ct = default);

    Task<bool> ParameterCodeExistsAsync(
        string parameterCode,
        int exceptParameterDefinitionMasterId,
        CancellationToken ct = default);

    // inserts (id 0) or updates the master
    Task SaveParameterMasterAsync(
        ParameterDefinitionMaster master,
        CancellationToken ct = default);

    // workflow versions that map the master
    Task<List<ParameterMasterUsage>> GetParameterMasterUsageAsync(
        int parameterDefinitionMasterId,
        CancellationToken ct = default);

    Task DeleteParameterMasterAsync(
        int parameterDefinitionMasterId,
        CancellationToken ct = default);

    Task<WorkflowJsonVersion?> GetWorkflowVersionAsync(
    string workflowCode,
    int versionNo,
    CancellationToken ct = default);

    // ---------------------------------------------------------------- industry parameter mapping (entities only)

    // all mappings of a version and industry (mapped and unticked)
    Task<List<IndustryParameterMapping>> GetIndustryParameterMappingsAsync(
        int workflowJsonVersionId,
        int industryId,
        CancellationToken ct = default);

    // mapping id -> scale id, for the mappings that have scores
    Task<Dictionary<int, int>> GetScaleIdsAsync(
        IReadOnlyCollection<int> industryParameterMappingIds,
        CancellationToken ct = default);

    // inserts (id 0) / updates the mappings, then links each child to its parent
    // (parentMasterIds: child master id -> parent master id, null = no parent)
    Task SaveIndustryParameterMappingsAsync(
        IReadOnlyList<IndustryParameterMapping> mappings,
        IReadOnlyDictionary<int, int?> parentMasterIds,
        CancellationToken ct = default);

    // ---------------------------------------------------------------- score configuration (entities only)

    Task<IndustryParameterMapping?> GetIndustryParameterMappingAsync(
        int industryParameterMappingId,
        CancellationToken ct = default);

    Task<WorkflowJsonVersion?> GetWorkflowVersionByIdAsync(
        int workflowJsonVersionId,
        CancellationToken ct = default);

    // score rows of one mapping, lowest score first
    Task<List<ScaleConfigurationDetails>> GetScaleDetailsAsync(
        int industryParameterMappingId,
        CancellationToken ct = default);

    Task<ScaleConfiguration?> GetScaleAsync(
        int scaleConfigurationId,
        CancellationToken ct = default);

    Task<ScaleConfiguration?> GetScaleByCodeAsync(
        string scaleCode,
        CancellationToken ct = default);

    // inserts / updates the scale and replaces the score rows of the mapping
    Task SaveScoreConfigurationAsync(
        int industryParameterMappingId,
        ScaleConfiguration scale,
        IReadOnlyList<ScaleConfigurationDetails> details,
        CancellationToken ct = default);


    // ---------------------------------------------------------------- validations (entities only)

    // all validation rows of a mapping (active and inactive)
    Task<List<ValidationDefinition>> GetValidationsAsync(
        int industryParameterMappingId,
        CancellationToken ct = default);

    // replaces the validation rows of the mapping
    Task ReplaceValidationsAsync(
        int industryParameterMappingId,
        IReadOnlyList<ValidationDefinition> validations,
        CancellationToken ct = default);

    // ---------------------------------------------------------------- versions / workflow definition (entities only)

    // starts a transaction for several repository calls; repository saves join it
    Task<IUnitOfWorkTransaction> BeginTransactionAsync(
        CancellationToken ct = default);

    // all versions of a workflow
    Task<List<WorkflowJsonVersion>> GetWorkflowVersionsAsync(
        string workflowCode,
        CancellationToken ct = default);

    Task AddWorkflowVersionAsync(
        WorkflowJsonVersion version,
        CancellationToken ct = default);

    // status / JSON changes of existing versions
    Task UpdateWorkflowVersionsAsync(
        IReadOnlyList<WorkflowJsonVersion> versions,
        CancellationToken ct = default);

    // copies the version-owned rows (mappings with parents, score rows, popup fields, popup rules)
    // of the active mappings of one version to another version
    Task CopyVersionConfigurationAsync(
        int sourceWorkflowJsonVersionId,
        int targetWorkflowJsonVersionId,
        int industryId,
        CancellationToken ct = default);

    // case-insensitive
    Task<ParameterDefinitionMaster?> GetParameterMasterByCodeAsync(
        string parameterCode,
        CancellationToken ct = default);

    // active framework rules of a version (not the popup score rules)
    Task<List<RuleDefinition>> GetFrameworkRulesAsync(
        int workflowJsonVersionId,
        CancellationToken ct = default);

    Task AddRuleDefinitionsAsync(
        IReadOnlyList<RuleDefinition> rules,
        CancellationToken ct = default);

    Task<List<ScaleConfigurationDetails>> GetScaleDetailsForMappingsAsync(
        IReadOnlyCollection<int> industryParameterMappingIds,
        CancellationToken ct = default);

    Task<List<ValidationDefinition>> GetValidationsForMappingsAsync(
        IReadOnlyCollection<int> industryParameterMappingIds,
        CancellationToken ct = default);
}

// a workflow version in which a parameter master is mapped
public record ParameterMasterUsage(string WorkflowCode, int VersionNo);