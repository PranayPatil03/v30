namespace CRISP.Application.Interfaces;

public interface IRuleEngineExecutor
{
    Task<RuleEngineExecutionResult> ExecuteAsync(
    string workflowJson,
    string workflowName,
    IReadOnlyDictionary<string, decimal> scores,
    CancellationToken ct = default);

    /*
     * Runs one workflow object:
     *   { "WorkflowName": "...", "GlobalParams": [ { "Name", "Expression" } ], "Rules": [ { "RuleName", "Expression", "OutputExpression" } ] }
     * GlobalParams are calculated in order; every input and GlobalParam value is returned,
     * together with the output of the first successful rule.
     */
    Task<RuleWorkflowResult> ExecuteWorkflowAsync(
    string workflowJson,
    IReadOnlyDictionary<string, object> inputs,
    CancellationToken ct = default);
}
public sealed record RuleEngineExecutionResult(
bool Success,
decimal Score,
string Formula,
string Message);
public sealed record RuleWorkflowResult(
bool Success,
IReadOnlyDictionary<string, object?> Values,
object? FirstSuccessOutput,
string Message);