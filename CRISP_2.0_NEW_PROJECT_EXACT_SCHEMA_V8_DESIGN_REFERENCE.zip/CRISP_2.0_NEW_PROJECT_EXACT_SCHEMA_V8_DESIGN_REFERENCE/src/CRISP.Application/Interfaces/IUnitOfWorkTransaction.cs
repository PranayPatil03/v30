﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Interfaces
{
    public interface IUnitOfWorkTransaction : IAsyncDisposable
    {
        Task CommitAsync(CancellationToken ct = default);
    }
}
