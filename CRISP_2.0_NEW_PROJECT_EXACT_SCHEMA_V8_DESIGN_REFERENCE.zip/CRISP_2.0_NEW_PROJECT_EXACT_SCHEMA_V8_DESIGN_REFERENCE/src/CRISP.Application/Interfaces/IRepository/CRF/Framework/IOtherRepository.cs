﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Interfaces.IRepository.CRF.Framework
{

    public interface IOtherRepository
    {
        // top-level rows of a framework step ("Others", "ParentGroup")
        Task<List<IndustryParameterMapping>> GetOthersAsync(int workflowJsonVersionId, string stepName, CancellationToken ct = default);

        Task<List<IndustryParameterMapping>> GetChildrenAsync(int parentIndustryParameterMappingId, CancellationToken ct = default);

        Task<List<ParameterFieldDefinition>> GetFieldsAsync(int industryParameterMappingId, CancellationToken ct = default);

        Task<List<FrameworkParameterResponse>> GetResponsesAsync(int assessmentResponseId, CancellationToken ct = default);

        Task SaveResponsesAsync(List<FrameworkParameterResponse> responses, CancellationToken ct = default);

        Task<IndustryParameterMapping?> GetMappingAsync(int industryParameterMappingId, CancellationToken ct = default);

        // every active field of every parameter of the version (shared context of all popups)
        Task<List<ParameterFieldDefinition>> GetVersionFieldsAsync(int workflowJsonVersionId, CancellationToken ct = default);

        // score rules of a popup, in the order they are tried
        Task<List<RuleDefinition>> GetRulesAsync(int industryParameterMappingId, CancellationToken ct = default);

        Task<List<ParameterDefinitionMaster>> GetMastersAsync(IReadOnlyCollection<int> parameterDefinitionMasterIds, CancellationToken ct = default);

        Task<List<ScaleConfigurationDetails>> GetScaleDetailsAsync(IReadOnlyCollection<int> industryParameterMappingIds, CancellationToken ct = default);

        Task<List<FrameworkParameterScore>> GetScoresAsync(int assessmentResponseId, CancellationToken ct = default);

        // replaces the saved answers of the given fields and stores the calculated score, in one transaction
        Task SavePopupAsync(
            int assessmentResponseId,
            IReadOnlyCollection<int> fieldIds,
            List<FrameworkParameterResponse> responses,
            FrameworkParameterScore? calculatedScore,
            CancellationToken ct = default);

        Task SaveAnalystScoresAsync(
            int assessmentResponseId,
            IReadOnlyDictionary<int, AnalystAnswer> answersByMappingId,
            CancellationToken ct = default);

        // active ratings, strongest (AAA) first
        Task<List<RatingScale>> GetRatingScaleAsync(CancellationToken ct = default);
    }

    // what the analyst entered for one row: a score and/or a text answer
    public record AnalystAnswer(decimal? Score, string? ValueText);
}