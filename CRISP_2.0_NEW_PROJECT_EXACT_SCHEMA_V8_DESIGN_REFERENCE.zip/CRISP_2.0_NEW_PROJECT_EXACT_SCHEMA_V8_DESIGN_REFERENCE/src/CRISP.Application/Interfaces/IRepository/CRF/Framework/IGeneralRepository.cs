﻿using CRISP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Interfaces.IRepository.CRF.Framework
{
    public interface IGeneralRepository
    {
        Task<FrameworkGeneral?> GetAsync(int assessmentResponseId, CancellationToken ct = default);

        Task<FrameworkGeneral> SaveAsync(FrameworkGeneral entity, CancellationToken ct = default);
    }

}
