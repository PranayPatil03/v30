﻿using CRISP.Domain.Entities;

namespace CRISP.Application.Interfaces.IRepository.CRF.Framework;

public sealed record CodedRow(IndustryParameterMapping Mapping, string Code);
public interface IOutputRepository
{
    Task<AssessmentResponse?> GetAssessmentAsync(int assessmentResponseId, CancellationToken ct = default);
    Task<FrameworkGeneral?> GetGeneralAsync(int assessmentResponseId, CancellationToken ct = default);
    Task<int?> GetIndustryDetailsIdAsync(int workflowJsonVersionId, CancellationToken ct = default);
    // active rows of one step of the version, in display order
    Task<List<CodedRow>> GetRowsAsync(int workflowJsonVersionId, string stepName, CancellationToken ct = default);
    Task<List<FrameworkOutputDetails>> GetOutputAsync(int assessmentResponseId, CancellationToken ct = default);
    // replaces the saved output of one assessment in one transaction
    Task SaveOutputAsync(int assessmentResponseId, IReadOnlyList<FrameworkOutputDetails> rows, CancellationToken ct =
default);
    Task<List<RatingMatrix>> GetRatingMatricesAsync(int workflowJsonVersionId, CancellationToken ct = default);
    Task<List<RatingBand>> GetRatingBandsAsync(int workflowJsonVersionId, CancellationToken ct = default);
}