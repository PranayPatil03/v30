﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Interfaces.IRepository.CRF.Framework
{
    public sealed record SpreadValue(int Year, int TemplateCode, int? RowPosition, int? SubCategoryCode, decimal Value);

    public interface ISpreadRepository
    {
        Task<string?> GetCustomerCodeAsync(int assessmentResponseId, CancellationToken ct = default);

        // a spread version was uploaded for this year
        Task<bool> HasYearAsync(string customerCode, int year, CancellationToken ct = default);

        Task<List<SpreadValue>> GetValuesAsync(string customerCode, IReadOnlyCollection<int> years, CancellationToken ct = default);
    }

}
