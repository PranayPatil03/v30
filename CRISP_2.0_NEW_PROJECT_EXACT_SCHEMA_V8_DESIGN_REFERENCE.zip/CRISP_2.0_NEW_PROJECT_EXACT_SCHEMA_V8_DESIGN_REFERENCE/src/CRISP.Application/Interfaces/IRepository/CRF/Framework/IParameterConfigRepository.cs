﻿using CRISP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Interfaces.IRepository.CRF.Framework
{
    public sealed record ParameterConfigSource(
         IndustryParameterMapping Mapping,
         WorkflowJsonVersion Version,
         string ParameterCode,
         string? ParentName,
         List<ParameterFieldDefinition> Fields,
         List<RuleDefinition> Rules,
         List<ScaleConfigurationDetails> Scores,
         // active fields of the other parameters of the same version and industry
         List<ParameterFieldDefinition> OtherFields)
    {
        // the module a popup opens from (e.g. Liquidity) and its scores 1..5
        public IndustryParameterMapping? Parent { get; init; }

        public List<ScaleConfigurationDetails> ParentScores { get; init; } = [];

        // popups under this mapping (when it is a module)
        public List<RelatedMapping> Children { get; init; } = [];
    }

    public sealed record RelatedMapping(int MappingId, string Name, string? ControlType, int RowCount, string? Label = null);

    public interface IParameterConfigRepository
    {
        Task<ParameterConfigSource?> GetAsync(int industryParameterMappingId, CancellationToken ct = default);

        // other mappings (any workflow / version) that already have popup rows, to start from a copy
        Task<List<RelatedMapping>> GetCopySourcesAsync(int industryParameterMappingId, CancellationToken ct = default);

        // replaces fields and rules of the mapping and stores the texts, in one transaction
        Task SaveAsync(
            int industryParameterMappingId,
            string? detailsDescription,
            string? detailsNote,
            List<ParameterFieldDefinition> fields,
            List<RuleDefinition> rules,
            IReadOnlyDictionary<int, string?> scoreDescriptions,
            CancellationToken ct = default);
    }

}
