﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Interfaces.IServices.CRF.Framework
{
    public interface IOutputService
    {
        Task<FrameworkOutputDto> GetAsync(int assessmentResponseId, CancellationToken ct = default);
        Task<RunOutputResultDto> RunAsync(int assessmentResponseId, RunOutputRequestDto request, string userName,
CancellationToken ct = default);
        Task SaveRatingsAsync(SaveOutputRatingsRequestDto request, CancellationToken ct = default);
    }
    // financial risk of chapter 14A; null when the version has no financial configuration yet
    public interface IFinancialRiskService
    {
        Task<FinancialRiskResult?> RunAsync(AssessmentResponse assessment, FrameworkGeneral general, CancellationToken ct =
default);
    }
    public sealed record FinancialRiskResult(decimal FinancialScore, decimal? FinancialScoreProj, decimal?
AdjustedBusinessScore);
}
