﻿using CRISP.Application.DTOs.CRF.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Interfaces.IServices.CRF.Framework
{
    public interface IFrameworkValidationService
    {
        Task<List<TabErrorsDto>> ValidateAsync(int assessmentResponseId, CancellationToken ct);
    }
}
