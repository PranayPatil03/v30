﻿using CRISP.Application.DTOs.CRF.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Interfaces.IServices.CRF.Framework
{
    public interface IOtherService
    {
        // rows of a framework step: "Others" or "ParentGroup"
        Task<List<OtherTabDto>> GetOtherTabsAsync(
            int workflowJsonVersionId,
            int assessmentResponseId,
            string stepName,
            CancellationToken ct = default);

        Task<List<OtherModuleDto>> GetModulesAsync(
            int parentIndustryParameterMappingId,
            CancellationToken ct = default);

        Task<List<OtherFieldDto>> GetFieldsAsync(
            int industryParameterMappingId,
            int assessmentResponseId,
            CancellationToken ct = default);

        Task<ParentGroupResultDto> CalculateParentGroupAsync(
            ParentGroupCalculateRequestDto request,
            CancellationToken ct = default);

        Task SaveAsync(
            SaveOtherTabRequestDto request,
            CancellationToken ct = default);

        // popup with saved values and everything the rule engine calculates
        Task<PopupDto> GetPopupAsync(
            int industryParameterMappingId,
            int assessmentResponseId,
            CancellationToken ct = default);

        // recalculates with the values on screen, nothing is saved
        Task<PopupDto> CalculatePopupAsync(
            SavePopupRequestDto request,
            CancellationToken ct = default);

        Task<PopupDto> SavePopupAsync(
            SavePopupRequestDto request,
            CancellationToken ct = default);

        Task SaveScoresAsync(
            SaveOtherScoresRequestDto request,
            CancellationToken ct = default);
    }
}