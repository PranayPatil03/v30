﻿using CRISP.Application.DTOs.CRF.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Interfaces.IServices.CRF.Framework
{
    public interface IParameterConfigService
    {
        Task<ParameterConfigDto> GetAsync(int industryParameterMappingId, CancellationToken ct = default);

        // checks codes, settings and compiles every formula and rule with the rule engine
        Task<ParameterConfigCheckDto> CheckAsync(SaveParameterConfigRequest request, CancellationToken ct = default);

        // popups of other workflows / versions to start from a copy
        Task<List<RelatedParameterDto>> GetCopySourcesAsync(int industryParameterMappingId, CancellationToken ct = default);

        // calculates the unsaved configuration with sample values (nothing is saved)
        Task<ParameterConfigTryDto> TryAsync(ParameterConfigTryRequest request, CancellationToken ct = default);

        Task<ParameterConfigDto> SaveAsync(SaveParameterConfigRequest request, CancellationToken ct = default);
    }

}
