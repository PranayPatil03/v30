﻿using CRISP.Application.DTOs.CRF.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Interfaces.IServices.CRF.Framework
{
    public interface IGeneralService
    {
        Task<GeneralDto?> GetAsync(
            int assessmentResponseId,
            CancellationToken ct = default);

        Task<GeneralDto> SaveAsync(
            GeneralDto request,
            CancellationToken ct = default);
    }

}
