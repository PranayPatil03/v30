namespace CRISP.Application.DTOs;

/// <summary>One master parameter and its configuration for a specific workflow version.</summary>
public class IndustryParameterMappingDto
{
    public int IndustryParameterMappingId { get; set; }
    public int ParameterDefinitionMasterId { get; set; }
    public string ParameterCode { get; set; } = string.Empty;
    public string MasterParameterName { get; set; } = string.Empty;
    public bool IsMapped { get; set; }
    public string ParameterDisplayName { get; set; } = string.Empty;
    public string ValueType { get; set; } = "Score";
    public decimal Weight { get; set; }
    public int? ScaleConfigurationId { get; set; }
    public int DisplayOrder { get; set; }

    public string StepName { get; set; }
    = string.Empty;

    public string ControlType { get; set; }
        = string.Empty;

    // popup under a Module row (e.g. Update Liquidity Details under Liquidity): the parent's master id
    public int? ParentParameterDefinitionMasterId { get; set; }

    // popup year columns: first year = latest FY + YearFromOffset, YearColumns columns
    public int? YearFromOffset { get; set; }
    public int? YearColumns { get; set; }

    // Parent/Group tab: block of the tab ("Likelihood of Support") and list of a Dropdown row ("RatingScale" | "YesNo")
    public string? SectionName { get; set; }
    public string? OptionsSource { get; set; }
}

public class SaveIndustryParameterMappingsRequest
{
    public string WorkflowCode { get; set; } = string.Empty;
    public int VersionNo { get; set; }
    public int IndustryDetailsId { get; set; }
    public List<IndustryParameterMappingDto> Mappings { get; set; } = [];
}