namespace CRISP.Application.DTOs;

public sealed class BusinessParameterDetailsDto
{
    public BusinessParameterDetailsDto(
    int id,
    int industrySegmentId,
    string industryName,
    decimal weight,
    string status,
    string workflowCode,
    int workflowVersionNo)
    {
        Id = id;
        IndustrySegmentId = industrySegmentId;
        IndustryName = industryName;
        Weight = weight;
        Status = status;

        WorkflowCode = workflowCode;
        WorkflowVersionNo = workflowVersionNo;
    }
    public int Id { get; set; }
    public int IndustrySegmentId { get; set; }
    public string IndustryName { get; set; } = string.Empty;
    public decimal Weight { get; set; }
    public string Status { get; set; } = string.Empty;
    public string WorkflowCode { get; set; } = string.Empty;
    public int WorkflowVersionNo { get; set; }


    public List<VersionDto> AvailableVersions
    {
        get;
        set;
    }
    = [];

    public int RequestedVersion
    {
        get;
        set;
    }

}