﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.DTOs
{
    public class ValidationDefinitionDto
    {
        public int ValidationDefinitionId { get; set; }

        public int IndustryParameterMappingId { get; set; }

        public string ValidationType { get; set; } = "";

        public string ValidationDescription { get; set; } = "";

        public string ErrorMessage { get; set; } = "";

        public int DisplayOrder { get; set; }

        public bool IsActive { get; set; }
    }
}