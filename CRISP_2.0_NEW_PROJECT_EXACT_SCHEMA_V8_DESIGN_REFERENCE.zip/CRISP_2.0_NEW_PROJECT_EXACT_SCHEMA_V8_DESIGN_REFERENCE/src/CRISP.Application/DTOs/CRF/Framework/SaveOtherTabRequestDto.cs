﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.DTOs.CRF.Framework
{
    public sealed class SaveOtherTabRequestDto
    {
        public int AssessmentResponseId { get; set; }

        public List<OtherFieldDto> Fields { get; set; } = new List<OtherFieldDto>();
    }


    public sealed class SaveOtherTabResponseDto
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
    }

}
