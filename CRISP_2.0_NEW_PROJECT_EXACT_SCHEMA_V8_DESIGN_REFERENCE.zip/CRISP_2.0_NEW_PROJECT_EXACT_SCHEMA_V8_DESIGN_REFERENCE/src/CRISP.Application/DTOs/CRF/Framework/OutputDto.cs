﻿namespace CRISP.Application.DTOs.CRF.Framework;
// Output tab: blocks in display order ("Rating", "Financial Risk", "Adjustments")
public class FrameworkOutputDto
{
    public int AssessmentResponseId { get; set; }
    public string Status { get; set; } = "Draft";
    public DateTime? CalculatedOn { get; set; }
    public List<OutputSectionDto> Sections { get; set; } = [];
}
public class OutputSectionDto
{
    public string Title { get; set; } = string.Empty;
    public List<OutputRowDto> Rows { get; set; } = [];
}
public class OutputRowDto
{
    public int IndustryParameterMappingId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string ControlType { get; set; } = string.Empty;   // Calculated = read-only, Dropdown = analyst
    public string? Value { get; set; }                         // "AA-" or "1" (notches)
    public List<string> Options { get; set; } = [];           // ratings for Dropdown rows
}
public class TabErrorsDto
{
    public string TabName { get; set; } = string.Empty;        // "Business Tab", "General Tab" ...
    public List<string> Messages { get; set; } = [];
}
public class RunOutputResultDto
{
    public bool Success => Errors.Count == 0;
    public List<TabErrorsDto> Errors { get; set; } = [];
    public FrameworkOutputDto? Output { get; set; }
}
// Business tab inputs, evaluated again on the server (same request as /evaluate)
public class RunOutputRequestDto
{
    public EvaluateRequest Business { get; set; } = new();
}
public class SaveOutputRatingsRequestDto
{
    public int AssessmentResponseId { get; set; }
    public Dictionary<int, string?> Ratings { get; set; } = [];   // mappingId -> rating (Analyst N1, RC)
}