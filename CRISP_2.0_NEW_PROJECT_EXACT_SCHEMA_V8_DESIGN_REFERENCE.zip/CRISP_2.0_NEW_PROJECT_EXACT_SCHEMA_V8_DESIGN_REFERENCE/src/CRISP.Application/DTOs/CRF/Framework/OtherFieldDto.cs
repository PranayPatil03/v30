﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.DTOs.CRF.Framework
{
    public sealed class OtherFieldDto
    {
        public int ParameterFieldDefinitionId { get; set; }

        public int IndustryParameterMappingId { get; set; }

        public string FieldName { get; set; } = string.Empty;

        public string FieldType { get; set; } = string.Empty;

        public bool IsRequired { get; set; }

        public string? Value { get; set; }
    }

}
