﻿namespace CRISP.Application.DTOs.CRF.Framework
{
    // everything an admin configures for one mapped parameter of a version (no SQL needed):
    // popup fields, popup score rules and the "Show Details" texts
    public class ParameterConfigDto
    {
        public int IndustryParameterMappingId { get; set; }

        public string ParameterName { get; set; } = string.Empty;

        public string ParameterCode { get; set; } = string.Empty;

        public string StepName { get; set; } = string.Empty;

        public string ControlType { get; set; } = string.Empty;

        public string? ParentName { get; set; }

        public string WorkflowCode { get; set; } = string.Empty;

        public int VersionNo { get; set; }

        // only Draft versions can be changed
        public bool IsReadOnly { get; set; }

        public int? YearFromOffset { get; set; }

        public int? YearColumns { get; set; }

        public string? DetailsDescription { get; set; }

        public string? DetailsNote { get; set; }

        public List<FieldConfigDto> Fields { get; set; } = [];

        public List<RuleConfigDto> Rules { get; set; } = [];

        public List<ScoreTextDto> Scores { get; set; } = [];

        // field codes of the other parameters of the version (usable in formulas)
        public List<string> OtherFieldCodes { get; set; } = [];

        // the same fields with their labels, for the formula / rule pickers
        public List<CodeInfoDto> OtherFields { get; set; } = [];

        // ---- for the setup checklist

        public decimal Weight { get; set; }

        public int? ParentMappingId { get; set; }

        public decimal? ParentWeight { get; set; }

        public bool ParentHasDetails { get; set; }

        // scores 1..5 of the module the popup opens from (score steps choose from these)
        public List<ScoreTextDto> ParentScores { get; set; } = [];

        // popups of this mapping when it is a module
        public List<RelatedParameterDto> Children { get; set; } = [];
    }

    public class RelatedParameterDto
    {
        public int MappingId { get; set; }

        public string Name { get; set; } = string.Empty;

        public string? ControlType { get; set; }

        public int RowCount { get; set; }

        public string Label { get; set; } = string.Empty;
    }

    public class CodeInfoDto
    {
        public string Code { get; set; } = string.Empty;

        public string Label { get; set; } = string.Empty;

        public string FieldType { get; set; } = "Number";

        public string? OptionsJson { get; set; }

        public bool IsYearWise { get; set; }
    }

    public class FieldConfigDto
    {
        public int ParameterFieldDefinitionId { get; set; }

        public int DisplayOrder { get; set; }

        public string FieldCode { get; set; } = string.Empty;

        public string FieldName { get; set; } = string.Empty;

        // Number | YesNo | Radio | Text
        public string FieldType { get; set; } = "Number";

        public string? SectionName { get; set; }

        public bool IsYearWise { get; set; }

        // Input | Spread | Formula | Rule | Heading | Note | Spacer
        public string SourceType { get; set; } = "Input";

        public string? SpreadRows { get; set; }

        public bool SpreadByTemplate { get; set; }

        public short SpreadSign { get; set; } = 1;

        public int SpreadYearOffset { get; set; }

        public string? Formula { get; set; }

        public string? DefaultValue { get; set; }

        public bool IsOverridable { get; set; }

        public string? OptionsJson { get; set; }

        public bool IsRequired { get; set; }

        public short? ChartSign { get; set; }

        public string? ResultRole { get; set; }

        public string? HelpText { get; set; }

        public string? ShowWhen { get; set; }
    }

    public class RuleConfigDto
    {
        public int RuleDefinitionId { get; set; }

        public int DisplayOrder { get; set; }

        public string RuleName { get; set; } = string.Empty;

        // condition; empty = always
        public string? Expression { get; set; }

        // e.g. 5
        public string OutputExpression { get; set; } = string.Empty;

        public bool IsActive { get; set; } = true;
    }

    public class ScoreTextDto
    {
        public int ScaleConfigurationDetailsId { get; set; }

        public string ScoreValue { get; set; } = string.Empty;

        public string Definition { get; set; } = string.Empty;

        public string? ScoreDescription { get; set; }
    }

    public class SaveParameterConfigRequest
    {
        public int IndustryParameterMappingId { get; set; }

        public string? DetailsDescription { get; set; }

        public string? DetailsNote { get; set; }

        public List<FieldConfigDto> Fields { get; set; } = [];

        public List<RuleConfigDto> Rules { get; set; } = [];

        public List<ScoreTextDto> Scores { get; set; } = [];
    }

    public class ParameterConfigCheckDto
    {
        public bool IsValid => Errors.Count == 0;

        public List<string> Errors { get; set; } = [];
    }

    // "Try it": calculate the (unsaved) configuration with sample values
    public class ParameterConfigTryRequest
    {
        public SaveParameterConfigRequest Config { get; set; } = new();

        // field code -> one value per year column (single-value fields: one value)
        public Dictionary<string, List<string?>> Values { get; set; } = [];
    }

    public class ParameterConfigTryDto
    {
        public int YearColumns { get; set; }

        // field code -> one value per year column (single-value fields: one value)
        public Dictionary<string, List<string?>> Values { get; set; } = [];

        public string? Message { get; set; }
    }
}