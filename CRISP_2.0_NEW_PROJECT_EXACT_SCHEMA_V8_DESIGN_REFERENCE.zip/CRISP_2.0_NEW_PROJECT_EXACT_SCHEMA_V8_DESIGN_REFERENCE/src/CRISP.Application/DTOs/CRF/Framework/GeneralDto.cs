﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.DTOs.CRF.Framework
{
    public class GeneralDto
    {
        public int FrameworkGeneralId { get; set; }

        public int AssessmentResponseId { get; set; }

        public int EntityId { get; set; }

        public int WorkflowJsonVersionId { get; set; }

        public int? NoOfPastYears { get; set; }

        public int? NoOfProjectedYears { get; set; }

        public int? LatestFinancialYear { get; set; }

        public bool IsListed { get; set; }

        public bool IsParentSupported { get; set; }

        public string? ParentType { get; set; }
    }
}