﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.DTOs.CRF.Framework
{
    public class OtherTabDto
    {
        public int IndustryParameterMappingId { get; set; }

        public string ParameterName { get; set; } = string.Empty;

        public string ValueType { get; set; } = string.Empty;

        public string ControlType { get; set; } = string.Empty;

        public decimal? SelectedScore { get; set; }
        public List<ScoreOptionDto> ScoreOptions { get; set; }
        = [];
        public bool HasChildren { get; set; }

        // popups under a Module row (e.g. Contingent Liability | Update Liquidity Details)
        public List<OtherModuleDto> Children { get; set; } = [];

        // from the rule engine; the analyst may choose this score or worse
        public decimal? CalculatedScore { get; set; }

        public decimal? MinAllowedScore { get; set; }

        // "Show Details" panel (HTML from the admin)
        public string? Description { get; set; }

        public string? DetailsNote { get; set; }

        // Parent/Group tab ------------------------------------------------

        // block of the tab, e.g. "Likelihood of Support" (empty = the parameters table)
        public string? SectionName { get; set; }

        public decimal Weight { get; set; }
        public int DisplayOrder { get; set; }
        // 1 = row under a Group row (e.g. Strategic Importance under "Strategic Importance + Business Linkages")
        public int Level { get; set; }

        public int? ParentIndustryParameterMappingId { get; set; }

        // choices of a Dropdown row (ratings, Yes/No)
        public List<string> Options { get; set; } = [];

        // saved text answer (provider name, selected rating, Yes/No)
        public string? ValueText { get; set; }

        // the (i) tooltip: the parameter master's "why it matters"
        public string? HelpText { get; set; }
    }

    public class ScoreOptionDto
    {
        public decimal Value { get; set; }

        // the score as configured: "1" or "A" (letter scores are saved as ValueText)
        public string Code { get; set; } = string.Empty;

        public string Label { get; set; } = string.Empty;

        // long text in the assessment table (HTML)
        public string? Description { get; set; }
    }
}