﻿namespace CRISP.Application.DTOs.CRF.Framework
{
    // one popup of the Others tab (e.g. Update Liquidity Details), built from the field configuration
    public class PopupDto
    {
        public int IndustryParameterMappingId { get; set; }

        public string Name { get; set; } = string.Empty;

        // year columns, empty when the popup has no year-wise fields
        public List<int> Years { get; set; } = [];

        public int? LatestFinancialYear { get; set; }

        public List<PopupFieldDto> Fields { get; set; } = [];

        public decimal? CalculatedScore { get; set; }

        public decimal? MinAllowedScore { get; set; }

        // shown above the tables, e.g. "Please upload spreads for FY2025"
        public string? Warning { get; set; }
    }

    public class PopupFieldDto
    {
        public int FieldId { get; set; }

        public string FieldCode { get; set; } = string.Empty;

        public string FieldName { get; set; } = string.Empty;

        public string FieldType { get; set; } = string.Empty;

        public string? SectionName { get; set; }

        public bool IsYearWise { get; set; }

        public string SourceType { get; set; } = string.Empty;

        // Input fields and overridable calculated fields
        public bool IsEditable { get; set; }

        public bool IsOverridable { get; set; }

        public bool IsRequired { get; set; }

        public short? ChartSign { get; set; }

        // (i) icon tooltip
        public string? HelpText { get; set; }

        // e.g. CL_EXISTS=Yes: show only when that field has that value
        public string? ShowWhen { get; set; }

        public List<string> Options { get; set; } = [];

        // one per year (Year = null for single-value fields)
        public List<PopupValueDto> Values { get; set; } = [];
    }

    public class PopupValueDto
    {
        public int? Year { get; set; }

        public string? Value { get; set; }

        public bool IsOverridden { get; set; }
    }

    public class SavePopupRequestDto
    {
        public int AssessmentResponseId { get; set; }

        public int IndustryParameterMappingId { get; set; }

        public List<PopupValueInputDto> Values { get; set; } = [];
    }

    public class PopupValueInputDto
    {
        public int FieldId { get; set; }

        public int? Year { get; set; }

        public string? Value { get; set; }

        // calculated field: analyst typed another value
        public bool IsOverridden { get; set; }
    }

    public class SaveOtherScoresRequestDto
    {
        public int AssessmentResponseId { get; set; }

        public List<OtherScoreInputDto> Scores { get; set; } = [];
    }

    public class OtherScoreInputDto
    {
        public int IndustryParameterMappingId { get; set; }

        public decimal? Score { get; set; }

        // text answer of a Text / Dropdown row (Parent/Group tab)
        public string? ValueText { get; set; }
    }
}