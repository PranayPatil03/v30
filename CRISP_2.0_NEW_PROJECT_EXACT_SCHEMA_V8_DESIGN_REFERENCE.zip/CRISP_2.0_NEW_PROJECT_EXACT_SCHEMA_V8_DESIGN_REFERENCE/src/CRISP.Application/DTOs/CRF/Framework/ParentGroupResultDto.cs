﻿namespace CRISP.Application.DTOs.CRF.Framework
{
    // Parent/Group tab: weighted score, the Calculated rows (uplift ...) and what is still unanswered
    public class ParentGroupResultDto
    {
        public decimal? WeightedScore { get; set; }

        public List<ParentGroupValueDto> Results { get; set; } = [];

        // rows the analyst has not answered yet
        public List<string> Missing { get; set; } = [];

        // "CODE = value" given to the rule steps, to help write them
        public List<string> Inputs { get; set; } = [];
    }

    public class ParentGroupValueDto
    {
        public int IndustryParameterMappingId { get; set; }

        public string Name { get; set; } = string.Empty;

        public string? Value { get; set; }
    }

    public class ParentGroupCalculateRequestDto
    {
        public int WorkflowJsonVersionId { get; set; }

        public int AssessmentResponseId { get; set; }
    }
}