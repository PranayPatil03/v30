﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.DTOs.CRF.Framework
{
    public sealed class OtherModuleDto
    {
        public int IndustryParameterMappingId { get; set; }

        public int ParentIndustryParameterMappingId { get; set; }

        public string ModuleName { get; set; } = string.Empty;

        public string ControlType { get; set; } = string.Empty;
    }
}
