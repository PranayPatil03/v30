﻿using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;
using CRISP.Domain.Entities;

namespace CRISP.Application.DTOs;

// reads a score written as 1, 1.5 or "A"; writes numbers as numbers and anything else as text
public sealed class ScoreTextJsonConverter : JsonConverter<string>
{
    public override string Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options) =>
        reader.TokenType switch
        {
            JsonTokenType.Number => ScoreValues.ToText(reader.GetDecimal()),
            JsonTokenType.String => reader.GetString()?.Trim() ?? string.Empty,
            JsonTokenType.Null => string.Empty,
            _ => throw new JsonException($"Unexpected token {reader.TokenType} for a score.")
        };

    public override void Write(Utf8JsonWriter writer, string value, JsonSerializerOptions options)
    {
        if (decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out var number))
            writer.WriteNumberValue(number);
        else
            writer.WriteStringValue(value);
    }
}