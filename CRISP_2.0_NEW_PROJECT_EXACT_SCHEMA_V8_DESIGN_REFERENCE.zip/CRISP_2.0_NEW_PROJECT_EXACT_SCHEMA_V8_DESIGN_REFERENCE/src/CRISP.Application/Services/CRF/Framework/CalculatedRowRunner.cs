﻿using CRISP.Application.Interfaces;
using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Application.Services.CRF.Framework;
using System.Globalization;
using System.Text.Json.Nodes;
namespace CRISP.Application.Services.CRF.Framework;
// Extra Calculated rows an admin adds to the Output step: each row runs its RuleDefinition steps
// (first true wins) with the rating chain results as inputs; a row with the Ratings list turns the
// number into the rating of that order. Every result is an input of the next row.
public class CalculatedRowRunner
{
    private readonly IOtherRepository _repository;
    private readonly IRuleEngineExecutor _ruleEngine;
    public CalculatedRowRunner(IOtherRepository repository, IRuleEngineExecutor ruleEngine)
    {
        _repository = repository;
        _ruleEngine = ruleEngine;
    }
    public sealed record RowResult(int MappingId, string Code, decimal? Number, string? Text);
    public async Task<List<RowResult>> RunAsync(
        IReadOnlyList<CodedRow> rows,
        Dictionary<string, object> inputs,                       // filled by the caller, extended here
        IReadOnlyDictionary<int, string> ratingByOrder,           // 1 -> "AAA" ... 20 -> "D"
        CancellationToken ct = default)
    {
        var results = new List<RowResult>();
        foreach (var (row, code) in rows.OrderBy(x => x.Mapping.DisplayOrder))
        {
            var rules = await _repository.GetRulesAsync(row.IndustryParameterMappingId, ct);
            if (rules.Count == 0)
                continue;
            var workflow = new JsonObject
            {
                ["WorkflowName"] = $"Output{row.IndustryParameterMappingId}",
                ["GlobalParams"] = new JsonArray(),
                ["Rules"] = new JsonArray(rules.Select(r => (JsonNode)new JsonObject
                {
                    ["RuleName"] = r.RuleName,
                    ["Expression"] = string.IsNullOrWhiteSpace(r.Expression) ? "true" : r.Expression,
                    ["OutputExpression"] = r.OutputExpression
                }).ToArray())
            };
            var run = await _ruleEngine.ExecuteWorkflowAsync(workflow.ToJsonString(), inputs, ct);
            if (!run.Success)
                throw new InvalidOperationException($"'{row.ParameterDisplayName}' could not be calculated: {run.Message}");
            var number = PopupCalculator.ParseDecimal(Convert.ToString(run.FirstSuccessOutput,
CultureInfo.InvariantCulture));
            string? text = null;
            if (number is decimal n && string.Equals(row.OptionsSource, "RatingScale", StringComparison.OrdinalIgnoreCase))
            {
                var order = (int)Math.Clamp(Math.Round(n), 1, ratingByOrder.Count);
                text = ratingByOrder[order];
                inputs[$"{code}_ORDER"] = (decimal)order;
            }
            inputs[code] = (object?)text ?? number ?? 0m;
            results.Add(new RowResult(row.IndustryParameterMappingId, code, number, text));
        }
        return results;
    }
}