﻿using System.Globalization;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Application.Interfaces;
using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Application.Interfaces.IServices.CRF.Framework;
using CRISP.Application.Services.CRF.Framework;
using CRISP.Domain.Entities;

namespace CRISP.Application.Services
{
    /*
     * Admin configuration of one mapped parameter (replaces the SQL setup scripts):
     *   popup fields      -> ParameterFieldDefinition
     *   popup score rules -> RuleDefinition (linked to the mapping)
     *   Show Details      -> IndustryParameterMapping.Details*, ScaleConfigurationDetails.ScoreDescription
     * Before saving, every formula and rule is compiled with the rule engine.
     */
    public sealed class ParameterConfigService : IParameterConfigService
    {
        private static readonly Regex CodePattern = new("^[A-Za-z_][A-Za-z0-9_]*$", RegexOptions.Compiled);

        private static readonly string[] SourceTypes =
        [
            FieldSourceTypes.Input, FieldSourceTypes.Spread, FieldSourceTypes.Formula, FieldSourceTypes.Rule,
            FieldSourceTypes.Heading, FieldSourceTypes.Note, FieldSourceTypes.Spacer
        ];

        private static readonly string[] ResultRoles =
            [FieldResultRoles.Score, FieldResultRoles.ParentScore, FieldResultRoles.MinScore];

        private readonly IParameterConfigRepository _repository;
        private readonly IRuleEngineExecutor _ruleEngine;

        public ParameterConfigService(
            IParameterConfigRepository repository,
            IRuleEngineExecutor ruleEngine)
        {
            _repository = repository;
            _ruleEngine = ruleEngine;
        }

        public async Task<ParameterConfigDto> GetAsync(int industryParameterMappingId, CancellationToken ct = default)
        {
            var source = await _repository.GetAsync(industryParameterMappingId, ct)
                         ?? throw new InvalidOperationException("Parameter mapping not found.");

            return new ParameterConfigDto
            {
                IndustryParameterMappingId = source.Mapping.IndustryParameterMappingId,
                ParameterName = source.Mapping.ParameterDisplayName,
                ParameterCode = source.ParameterCode,
                StepName = source.Mapping.StepName ?? string.Empty,
                ControlType = source.Mapping.ControlType ?? string.Empty,
                ParentName = source.ParentName,
                WorkflowCode = source.Version.WorkflowCode,
                VersionNo = source.Version.VersionNo,
                IsReadOnly = IsReadOnly(source.Version),
                YearFromOffset = source.Mapping.YearFromOffset,
                YearColumns = source.Mapping.YearColumns,
                DetailsDescription = source.Mapping.DetailsDescription,
                DetailsNote = source.Mapping.DetailsNote,
                Fields = source.Fields.Select(ToDto).ToList(),
                Rules = source.Rules.Select(r => new RuleConfigDto
                {
                    RuleDefinitionId = r.RuleDefinitionId,
                    DisplayOrder = r.DisplayOrder,
                    RuleName = r.RuleName,
                    Expression = r.Expression,
                    OutputExpression = r.OutputExpression,
                    IsActive = r.IsActive
                }).ToList(),
                Scores = source.Scores.Select(s => new ScoreTextDto
                {
                    ScaleConfigurationDetailsId = s.ScaleConfigurationDetailsId,
                    ScoreValue = s.ScoreValue,
                    Definition = s.Definition,
                    ScoreDescription = s.ScoreDescription
                }).ToList(),
                OtherFieldCodes = source.OtherFields
                    .Where(f => !string.IsNullOrWhiteSpace(f.FieldCode) && FieldSourceTypes.HasValue(f.SourceType))
                    .Select(f => f.FieldCode!)
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .OrderBy(x => x)
                    .ToList(),
                Weight = source.Mapping.Weight,
                ParentMappingId = source.Parent?.IndustryParameterMappingId,
                ParentWeight = source.Parent?.Weight,
                ParentHasDetails = !string.IsNullOrWhiteSpace(source.Parent?.DetailsDescription),
                ParentScores = source.ParentScores.Select(s => new ScoreTextDto
                {
                    ScaleConfigurationDetailsId = s.ScaleConfigurationDetailsId,
                    ScoreValue = s.ScoreValue,
                    Definition = s.Definition,
                    ScoreDescription = s.ScoreDescription
                }).ToList(),
                Children = source.Children.Select(ToRelated).ToList(),
                OtherFields = source.OtherFields
                    .Where(f => !string.IsNullOrWhiteSpace(f.FieldCode) && FieldSourceTypes.HasValue(f.SourceType))
                    .GroupBy(f => f.FieldCode!, StringComparer.OrdinalIgnoreCase)
                    .Select(g => g.First())
                    .OrderBy(f => f.FieldCode)
                    .Select(f => new CodeInfoDto
                    {
                        Code = f.FieldCode!,
                        Label = f.FieldName,
                        FieldType = f.FieldType,
                        OptionsJson = f.OptionsJson,
                        IsYearWise = f.IsYearWise
                    })
                    .ToList()
            };
        }

        public async Task<List<RelatedParameterDto>> GetCopySourcesAsync(int industryParameterMappingId, CancellationToken ct = default) =>
            (await _repository.GetCopySourcesAsync(industryParameterMappingId, ct)).Select(ToRelated).ToList();

        private static RelatedParameterDto ToRelated(RelatedMapping x) => new()
        {
            MappingId = x.MappingId,
            Name = x.Name,
            ControlType = x.ControlType,
            RowCount = x.RowCount,
            Label = x.Label ?? x.Name
        };

        public async Task<ParameterConfigTryDto> TryAsync(ParameterConfigTryRequest request, CancellationToken ct = default)
        {
            var source = await _repository.GetAsync(request.Config.IndustryParameterMappingId, ct)
                         ?? throw new InvalidOperationException("Parameter mapping not found.");

            var config = request.Config;
            var fields = config.Fields
                .Where(f => FieldSourceTypes.HasValue(f.SourceType) && !string.IsNullOrWhiteSpace(f.FieldCode))
                .OrderBy(f => f.DisplayOrder)
                .ToList();

            var yearCount = fields.Any(f => f.IsYearWise) ? Math.Max(source.Mapping.YearColumns ?? 1, 1) : 0;
            var result = new ParameterConfigTryDto { YearColumns = yearCount };

            // start with the typed sample values (or the default)
            foreach (var f in fields)
            {
                var typed = request.Values.GetValueOrDefault(f.FieldCode) ?? [];
                var count = f.IsYearWise ? yearCount : 1;
                result.Values[f.FieldCode] = Enumerable.Range(0, count)
                    .Select(i => f.SourceType is FieldSourceTypes.Formula or FieldSourceTypes.Rule
                        ? null
                        : i < typed.Count && !string.IsNullOrWhiteSpace(typed[i]) ? typed[i] : f.DefaultValue)
                    .ToList();
            }

            // fields of other parameters: their default (0 / first option)
            var others = source.OtherFields
                .Where(f => !string.IsNullOrWhiteSpace(f.FieldCode) && FieldSourceTypes.HasValue(f.SourceType))
                .Where(f => fields.All(p => !string.Equals(p.FieldCode, f.FieldCode, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            object Input(string? fieldType, string? optionsJson, string? value) =>
                fieldType is "Number" or "Decimal" or "Percent" or null or ""
                    ? PopupCalculator.ParseDecimal(value) ?? 0m
                    : value ?? (IsStringArray(optionsJson) ? JsonSerializer.Deserialize<List<string>>(optionsJson!)!.FirstOrDefault() ?? "" : "");

            var hasScoreField = fields.Any(f => f.ResultRole == FieldResultRoles.Score);
            var rules = hasScoreField ? config.Rules.Where(r => r.IsActive).OrderBy(r => r.DisplayOrder).ToList() : [];

            // one run per year column
            for (var year = 0; year < yearCount; year++)
            {
                var formulas = fields.Where(f => f.IsYearWise && f.SourceType == FieldSourceTypes.Formula).ToList();
                var inputs = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                foreach (var f in others)
                    inputs[f.FieldCode!] = Input(f.FieldType, f.OptionsJson, f.DefaultValue);
                foreach (var f in fields.Where(f => !formulas.Contains(f)))
                    inputs[f.FieldCode] = Input(f.FieldType, f.OptionsJson, result.Values[f.FieldCode][f.IsYearWise ? year : 0]);

                var run = await _ruleEngine.ExecuteWorkflowAsync(TryWorkflow(source, formulas, rules, $"Year{year + 1}"), inputs, ct);
                if (!run.Success)
                {
                    result.Message = $"Year column {year + 1}: {Friendly(run.Message, config.Fields)}";
                    return result;
                }

                foreach (var f in formulas)
                    result.Values[f.FieldCode][year] = Format(run.Values.GetValueOrDefault(f.FieldCode));
                foreach (var f in fields.Where(f => f.IsYearWise && f.ResultRole == FieldResultRoles.Score))
                    result.Values[f.FieldCode][year] = Format(run.FirstSuccessOutput);
            }

            // single-value formulas, with CODE_Y1, CODE_Y2 ... of the year columns
            var singles = fields.Where(f => !f.IsYearWise && f.SourceType == FieldSourceTypes.Formula).ToList();
            if (singles.Count > 0)
            {
                var inputs = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                foreach (var f in others.Where(f => !f.IsYearWise))
                    inputs[f.FieldCode!] = Input(f.FieldType, f.OptionsJson, f.DefaultValue);
                foreach (var f in fields.Where(f => !f.IsYearWise && !singles.Contains(f)))
                    inputs[f.FieldCode] = Input(f.FieldType, f.OptionsJson, result.Values[f.FieldCode][0]);
                foreach (var f in fields.Where(f => f.IsYearWise))
                {
                    for (var i = 0; i < yearCount; i++)
                        inputs[$"{f.FieldCode}_Y{i + 1}"] = Input(f.FieldType, f.OptionsJson, result.Values[f.FieldCode][i]);
                }

                var run = await _ruleEngine.ExecuteWorkflowAsync(TryWorkflow(source, singles, [], "Single"), inputs, ct);
                if (!run.Success)
                {
                    result.Message = Friendly(run.Message, config.Fields);
                    return result;
                }

                foreach (var f in singles)
                    result.Values[f.FieldCode][0] = Format(run.Values.GetValueOrDefault(f.FieldCode));
            }

            return result;
        }

        private static string TryWorkflow(
            ParameterConfigSource source,
            List<FieldConfigDto> formulas,
            List<RuleConfigDto> rules,
            string suffix) =>
            new JsonObject
            {
                ["WorkflowName"] = $"Try{source.Mapping.IndustryParameterMappingId}{suffix}{Guid.NewGuid():N}",
                ["GlobalParams"] = new JsonArray(formulas
                    .Select(f => (JsonNode)new JsonObject { ["Name"] = f.FieldCode, ["Expression"] = f.Formula ?? "0m" })
                    .ToArray()),
                ["Rules"] = new JsonArray(rules
                    .Select(r => (JsonNode)new JsonObject
                    {
                        ["RuleName"] = r.RuleName,
                        ["Expression"] = string.IsNullOrWhiteSpace(r.Expression) ? "true" : r.Expression,
                        ["OutputExpression"] = r.OutputExpression
                    })
                    .ToArray())
            }.ToJsonString();

        private static string? Format(object? value) => value switch
        {
            null => null,
            decimal d => Math.Round(d, 2).ToString(CultureInfo.InvariantCulture),
            double d => Math.Round(Convert.ToDecimal(d), 2).ToString(CultureInfo.InvariantCulture),
            IFormattable f => f.ToString(null, CultureInfo.InvariantCulture),
            _ => value.ToString()
        };

        // rule engine messages in the words of the configuration screen
        private static string Friendly(string? message, List<FieldConfigDto> fields)
        {
            if (string.IsNullOrWhiteSpace(message))
                return "The calculation failed.";

            string Name(string code)
            {
                var field = fields.FirstOrDefault(f => string.Equals(f.FieldCode, code, StringComparison.OrdinalIgnoreCase));
                return field is null || string.IsNullOrWhiteSpace(field.FieldName) ? code : $"\"{field.FieldName}\" ({code})";
            }

            var where = string.Empty;
            var formula = Regex.Match(message, @"ScopedParam:\s*(\w+)");
            var rule = Regex.Match(message, @"rule `([^`]+)`");
            if (formula.Success)
                where = $"Formula of {Name(formula.Groups[1].Value)}: ";
            else if (rule.Success)
                where = $"Score rule {rule.Groups[1].Value}: ";

            var unknown = Regex.Match(message, @"Unknown identifier '(\w+)'");
            if (unknown.Success)
                return $"{where}'{unknown.Groups[1].Value}' is not a known field. Check the spelling or pick the field from the list.";

            var types = Regex.Match(message, @"Operator '([^']+)' incompatible with operand types '(\w+)' and '(\w+)'");
            if (types.Success)
                return $"{where}'{types.Groups[1].Value}' cannot compare {types.Groups[2].Value} with {types.Groups[3].Value}. " +
                       "Compare choice fields with a text in quotes (e.g. LC_BG == \"Yes\") and numbers with numbers.";

            if (message.Contains("divide by zero", StringComparison.OrdinalIgnoreCase) ||
                message.Contains("DivideByZero", StringComparison.OrdinalIgnoreCase))
                return $"{where}division by zero. Use e.g. (B == 0 ? 0 : A / B).";

            var detail = Regex.Replace(message, @"^Error while compiling rule `[^`]+`:\s*", "");
            detail = Regex.Replace(detail, @",?\s*in ScopedParam:\s*\w+", "");
            return where + detail;
        }

        public async Task<ParameterConfigCheckDto> CheckAsync(SaveParameterConfigRequest request, CancellationToken ct = default)
        {
            var source = await _repository.GetAsync(request.IndustryParameterMappingId, ct)
                         ?? throw new InvalidOperationException("Parameter mapping not found.");

            return await CheckAsync(source, request, ct);
        }

        public async Task<ParameterConfigDto> SaveAsync(SaveParameterConfigRequest request, CancellationToken ct = default)
        {
            var source = await _repository.GetAsync(request.IndustryParameterMappingId, ct)
                         ?? throw new InvalidOperationException("Parameter mapping not found.");

            if (IsReadOnly(source.Version))
                throw new InvalidOperationException($"Version V{source.Version.VersionNo} is read-only. Create a Draft before changing its configuration.");

            var check = await CheckAsync(source, request, ct);
            if (!check.IsValid)
                throw new InvalidOperationException(string.Join(Environment.NewLine, check.Errors));

            var fields = request.Fields
                .Select(f => new ParameterFieldDefinition
                {
                    ParameterFieldDefinitionId = f.ParameterFieldDefinitionId,
                    IndustryParameterMappingId = request.IndustryParameterMappingId,
                    DisplayOrder = f.DisplayOrder,
                    FieldCode = f.FieldCode.Trim(),
                    FieldName = f.FieldName?.Trim() ?? string.Empty,
                    FieldType = string.IsNullOrWhiteSpace(f.FieldType) ? "Number" : f.FieldType,
                    SectionName = Clean(f.SectionName),
                    IsYearWise = f.IsYearWise,
                    SourceType = f.SourceType,
                    SpreadRows = f.SourceType == FieldSourceTypes.Spread ? Clean(f.SpreadRows) : null,
                    SpreadByTemplate = f.SourceType == FieldSourceTypes.Spread && f.SpreadByTemplate,
                    SpreadSign = f.SpreadSign < 0 ? (short)-1 : (short)1,
                    SpreadYearOffset = f.SourceType == FieldSourceTypes.Spread ? f.SpreadYearOffset : 0,
                    Formula = f.SourceType == FieldSourceTypes.Formula ? Clean(f.Formula) : null,
                    DefaultValue = Clean(f.DefaultValue),
                    IsOverridable = f.IsOverridable && f.SourceType is FieldSourceTypes.Spread or FieldSourceTypes.Formula,
                    OptionsJson = Clean(f.OptionsJson),
                    IsRequired = f.IsRequired,
                    ChartSign = f.ChartSign,
                    ResultRole = Clean(f.ResultRole),
                    HelpText = Clean(f.HelpText),
                    ShowWhen = Clean(f.ShowWhen),
                    IsActive = true
                })
                .ToList();

            var rules = request.Rules
                .Select(r => new RuleDefinition
                {
                    RuleDefinitionId = r.RuleDefinitionId,
                    WorkflowJsonVersionId = source.Version.WorkflowJsonVersionId,
                    IndustryParameterMappingId = request.IndustryParameterMappingId,
                    DisplayOrder = r.DisplayOrder,
                    RuleName = r.RuleName.Trim(),
                    RuleExpressionType = "LambdaExpression",
                    Expression = Clean(r.Expression),
                    OutputExpression = r.OutputExpression.Trim(),
                    IsActive = r.IsActive
                })
                .ToList();

            await _repository.SaveAsync(
                request.IndustryParameterMappingId,
                Clean(request.DetailsDescription),
                Clean(request.DetailsNote),
                fields,
                rules,
                request.Scores.ToDictionary(x => x.ScaleConfigurationDetailsId, x => Clean(x.ScoreDescription)),
                ct);

            return await GetAsync(request.IndustryParameterMappingId, ct);
        }

        // ---------------------------------------------------------- check

        private async Task<ParameterConfigCheckDto> CheckAsync(
            ParameterConfigSource source,
            SaveParameterConfigRequest request,
            CancellationToken ct)
        {
            var result = new ParameterConfigCheckDto();
            var errors = result.Errors;
            var otherCodes = source.OtherFields
                .Where(f => !string.IsNullOrWhiteSpace(f.FieldCode))
                .Select(f => f.FieldCode!)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            // fields
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var f in request.Fields.OrderBy(x => x.DisplayOrder))
            {
                var label = string.IsNullOrWhiteSpace(f.FieldCode) ? $"Row {f.DisplayOrder}" : f.FieldCode;

                if (string.IsNullOrWhiteSpace(f.FieldCode) || !CodePattern.IsMatch(f.FieldCode))
                    errors.Add($"{label}: code must start with a letter and contain only letters, digits and _.");
                else if (!seen.Add(f.FieldCode))
                    errors.Add($"{label}: code is used twice in this parameter.");
                else if (otherCodes.Contains(f.FieldCode))
                    errors.Add($"{label}: code is already used by another parameter of this version.");

                if (!SourceTypes.Contains(f.SourceType))
                    errors.Add($"{label}: unknown source '{f.SourceType}'.");

                if (FieldSourceTypes.HasValue(f.SourceType) && string.IsNullOrWhiteSpace(f.FieldName))
                    errors.Add($"{label}: label is required.");

                if (f.SourceType == FieldSourceTypes.Spread &&
                    (string.IsNullOrWhiteSpace(f.SpreadRows) ||
                     f.SpreadRows.Split(',', StringSplitOptions.TrimEntries).Any(x => !int.TryParse(x, out _))))
                    errors.Add($"{label}: spread rows must be numbers separated by commas, e.g. 264,265.");

                if (f.SourceType == FieldSourceTypes.Formula && string.IsNullOrWhiteSpace(f.Formula))
                    errors.Add($"{label}: formula is required.");

                if (!string.IsNullOrWhiteSpace(f.ResultRole) && !ResultRoles.Contains(f.ResultRole))
                    errors.Add($"{label}: unknown result role '{f.ResultRole}'.");

                if (!string.IsNullOrWhiteSpace(f.OptionsJson) && !IsStringArray(f.OptionsJson))
                    errors.Add($"{label}: options must look like [\"Yes\",\"No\"].");

                if (!string.IsNullOrWhiteSpace(f.ShowWhen) && !f.ShowWhen.Contains('='))
                    errors.Add($"{label}: 'Show when' must look like CODE=Value.");
            }

            foreach (var role in ResultRoles)
            {
                if (request.Fields.Count(f => f.ResultRole == role) > 1)
                    errors.Add($"Only one field can have result role {role}.");
            }

            if (request.Fields.Any(f => f.IsYearWise) && (source.Mapping.YearColumns ?? 0) < 1)
                errors.Add("Year-wise fields need year columns: set 'Years (from / count)' on the Industry Parameter Mapping page.");

            if (request.Fields.Any(f => f.ResultRole == FieldResultRoles.Score) && !request.Rules.Any(r => r.IsActive))
                errors.Add("A field receives the score (result role Score) but there are no active score rules.");

            // rules
            foreach (var r in request.Rules)
            {
                var label = string.IsNullOrWhiteSpace(r.RuleName) ? $"Rule {r.DisplayOrder}" : r.RuleName;
                if (string.IsNullOrWhiteSpace(r.RuleName))
                    errors.Add($"{label}: name is required.");
                if (string.IsNullOrWhiteSpace(r.OutputExpression))
                    errors.Add($"{label}: score / output is required.");
            }

            if (request.Rules.GroupBy(r => r.RuleName.Trim(), StringComparer.OrdinalIgnoreCase).Any(g => g.Count() > 1))
                errors.Add("Rule names must be unique.");

            if (errors.Count > 0)
                return result;

            // compile with the rule engine: the same two runs as the popup calculation
            var yearRun = await RunCheckAsync(source, request, yearWise: true, ct);
            if (yearRun is not null)
                errors.Add(Friendly(yearRun, request.Fields));

            var singleRun = await RunCheckAsync(source, request, yearWise: false, ct);
            if (singleRun is not null)
                errors.Add(Friendly(singleRun, request.Fields));

            return result;
        }

        // inputs are 1 (numbers) or the first option (text) so that divisions do not fail
        private async Task<string?> RunCheckAsync(
            ParameterConfigSource source,
            SaveParameterConfigRequest request,
            bool yearWise,
            CancellationToken ct)
        {
            var popupFields = request.Fields.Where(f => FieldSourceTypes.HasValue(f.SourceType)).ToList();
            var formulas = popupFields
                .Where(f => f.SourceType == FieldSourceTypes.Formula && f.IsYearWise == yearWise)
                .OrderBy(f => f.DisplayOrder)
                .ToList();

            var rules = yearWise ? request.Rules.Where(r => r.IsActive).OrderBy(r => r.DisplayOrder).ToList() : [];
            if (formulas.Count == 0 && rules.Count == 0)
                return null;

            var inputs = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            foreach (var f in source.OtherFields.Where(f => !string.IsNullOrWhiteSpace(f.FieldCode) && FieldSourceTypes.HasValue(f.SourceType)))
            {
                if (yearWise || !f.IsYearWise)
                    inputs[f.FieldCode!] = SampleValue(f.FieldType, f.OptionsJson);
            }

            foreach (var f in popupFields.Where(f => !formulas.Contains(f)))
            {
                if (yearWise || !f.IsYearWise)
                    inputs[f.FieldCode] = SampleValue(f.FieldType, f.OptionsJson);
            }

            if (!yearWise)
            {
                var years = Math.Max(source.Mapping.YearColumns ?? 1, 1);
                foreach (var f in popupFields.Where(f => f.IsYearWise))
                {
                    for (var i = 1; i <= years; i++)
                        inputs[$"{f.FieldCode}_Y{i}"] = SampleValue(f.FieldType, f.OptionsJson);
                }
            }

            var workflow = new JsonObject
            {
                ["WorkflowName"] = $"Check{source.Mapping.IndustryParameterMappingId}{(yearWise ? "Year" : "Single")}",
                ["GlobalParams"] = new JsonArray(formulas
                    .Select(f => (JsonNode)new JsonObject { ["Name"] = f.FieldCode, ["Expression"] = f.Formula })
                    .ToArray()),
                ["Rules"] = new JsonArray(rules
                    .Select(r => (JsonNode)new JsonObject
                    {
                        ["RuleName"] = r.RuleName,
                        ["Expression"] = string.IsNullOrWhiteSpace(r.Expression) ? "true" : r.Expression,
                        ["OutputExpression"] = r.OutputExpression
                    })
                    .ToArray())
            };

            var run = await _ruleEngine.ExecuteWorkflowAsync(workflow.ToJsonString(), inputs, ct);
            return run.Success ? null : run.Message;
        }

        private static object SampleValue(string? fieldType, string? optionsJson)
        {
            if (fieldType is "Number" or "Decimal" or "Percent" or null or "")
                return 1m;

            return IsStringArray(optionsJson)
                ? JsonSerializer.Deserialize<List<string>>(optionsJson!)!.FirstOrDefault() ?? string.Empty
                : string.Empty;
        }

        private static bool IsStringArray(string? json)
        {
            if (string.IsNullOrWhiteSpace(json))
                return false;

            try
            {
                return JsonSerializer.Deserialize<List<string>>(json) is not null;
            }
            catch (JsonException)
            {
                return false;
            }
        }

        private static bool IsReadOnly(WorkflowJsonVersion version) =>
            version.IsPublished || !string.Equals(version.Status, "Draft", StringComparison.OrdinalIgnoreCase);

        private static string? Clean(string? value) =>
            string.IsNullOrWhiteSpace(value) ? null : value.Trim();

        private static FieldConfigDto ToDto(ParameterFieldDefinition f) => new()
        {
            ParameterFieldDefinitionId = f.ParameterFieldDefinitionId,
            DisplayOrder = f.DisplayOrder,
            FieldCode = f.FieldCode ?? string.Empty,
            FieldName = f.FieldName,
            FieldType = f.FieldType,
            SectionName = f.SectionName,
            IsYearWise = f.IsYearWise,
            SourceType = f.SourceType,
            SpreadRows = f.SpreadRows,
            SpreadByTemplate = f.SpreadByTemplate,
            SpreadSign = f.SpreadSign,
            SpreadYearOffset = f.SpreadYearOffset,
            Formula = f.Formula,
            DefaultValue = f.DefaultValue,
            IsOverridable = f.IsOverridable,
            OptionsJson = f.OptionsJson,
            IsRequired = f.IsRequired,
            ChartSign = f.ChartSign,
            ResultRole = f.ResultRole,
            HelpText = f.HelpText,
            ShowWhen = f.ShowWhen
        };
    }
}