﻿
using System;
using System.Collections.Generic;
using System.Linq;
using CRISP.Domain.Entities;

namespace CRISP.Application.Services.CRF.Framework;

public sealed class RatingMatrixLookup
{
    private static readonly string[] SixPointScale =
    [
        "AAA",
        "AA",
        "A",
        "BBB",
        "BB",
        "B"
    ];

    private readonly Dictionary<
        (string Matrix, string Row, string Col),
        decimal> _cells;

    private readonly List<RatingBand> _bands;

    public RatingMatrixLookup(
        IEnumerable<RatingMatrix> cells,
        IEnumerable<RatingBand> bands)
    {
        _cells = cells.ToDictionary(
            c => (
                c.MatrixCode.ToUpperInvariant(),
                c.RowValue.ToUpperInvariant(),
                c.ColumnValue.ToUpperInvariant()),
            c => c.Value);

        _bands = bands
            .OrderBy(b => b.MinValue)
            .ToList();
    }

    public decimal Cell(
        string matrix,
        string row,
        string col)
    {
        return _cells.TryGetValue(
            (
                matrix.ToUpperInvariant(),
                row.ToUpperInvariant(),
                col.ToUpperInvariant()),
            out var value)
            ? value
            : throw new RatingConfigurationException(
                $"Rating matrix {matrix} has no value for row '{row}', column '{col}'.");
    }

    // MinValue <= value < MaxValue
    public string Band(string bandSet, decimal value)
    {
        return _bands.FirstOrDefault(b =>
            string.Equals(
                b.BandCode,
                bandSet,
                StringComparison.OrdinalIgnoreCase)
            && value >= b.MinValue
            && value < b.MaxValue)?.BandValue
            ?? throw new RatingConfigurationException(
                $"Rating band {bandSet} has no band for {value}.");
    }

    public static int IndustryScore(string rating)
    {
        var index = Array.FindIndex(
            SixPointScale,
            r => string.Equals(
                r,
                rating,
                StringComparison.OrdinalIgnoreCase));

        return index >= 0
            ? index + 1
            : throw new RatingConfigurationException(
                $"'{rating}' is not on the 6-point scale.");
    }

    public static string IndustryRating(int score)
    {
        return score is >= 1 and <= 6
            ? SixPointScale[score - 1]
            : throw new RatingConfigurationException(
                $"Industry score {score} is outside 1-6.");
    }
}

public class RatingConfigurationException(string message)
    : InvalidOperationException(message);
