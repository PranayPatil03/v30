﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Application.Interfaces.IServices.CRF.Framework;
using CRISP.Application.Services.CRF.Framework;
namespace CRISP.Application.Services.CRF.Framework;
// Run Framework checks of every tab at once (legacy GetFrameworkOutput steps 4-7 stopped at the first)
public class FrameworkValidationService : IFrameworkValidationService
{
    private readonly IOutputRepository _output;
    private readonly IOtherRepository _others;
    public FrameworkValidationService(IOutputRepository output, IOtherRepository others)
    {
        _output = output;
        _others = others;
    }
    public async Task<List<TabErrorsDto>> ValidateAsync(int assessmentResponseId, CancellationToken ct = default)
    {
        var assessment = await _output.GetAssessmentAsync(assessmentResponseId, ct)
            ?? throw new InvalidOperationException("Framework not found.");
        var general = await _output.GetGeneralAsync(assessmentResponseId, ct);
        var versionId = assessment.WorkflowJsonVersionId;
        var answered = (await _others.GetScoresAsync(assessmentResponseId, ct))
            .Where(x => x.AnalystScore is not null || !string.IsNullOrWhiteSpace(x.ValueText))
            .Select(x => x.IndustryParameterMappingId)
            .ToHashSet();
        var errors = new List<TabErrorsDto>();
        // General (fixed fields of the General tab)
        var g = new List<string>();
        if (general is null)
        {
            g.Add("Please save the General tab.");
        }
        else
        {
            if (general.NoOfPastYears is null or <= 0) g.Add("Please select 'Number of past financial'.");
            if (general.NoOfProjectedYears is null or <= 0) g.Add("Please select 'Number of projected financial'.");
            if (general.LatestFinancialYear is null or 0) g.Add("Please select 'Financial year'.");
            if (general.IsParentSupported && string.IsNullOrWhiteSpace(general.ParentType))
                g.Add("Please select 'Type of parent/group'.");
            if (general.WorkflowJsonVersionId != versionId)
                g.Add("General details belong to another version. Please save the General tab again.");
        }
        Add(errors, "General Tab", g);
        // Others and Parent/Group: every active answer row of the configuration is answered
        Add(errors, "Other Tab", await MissingAsync(versionId, "Others", answered, ct));
        if (general?.IsParentSupported == true)
            Add(errors, "Parent Group Tab", await MissingAsync(versionId, "ParentGroup", answered, ct));
        return errors;
    }
    private async Task<List<string>> MissingAsync(int versionId, string step, HashSet<int> answered, CancellationToken ct)
=>
        (await _output.GetRowsAsync(versionId, step, ct))
            .Select(r => r.Mapping)
            .Where(NeedsAnswer)
            .Where(r => !answered.Contains(r.IndustryParameterMappingId))
            .Select(r => $"Please select '{r.ParameterDisplayName}'.")
            .ToList();
    // Group rows (score comes from their rows), Calculated rows (system) and popups (feed their Module's score)
    // are not answered by the analyst
    private static bool NeedsAnswer(Domain.Entities.IndustryParameterMapping r) =>
        !ParameterScoring.IsGroup(r.ControlType) &&
        !string.Equals(r.ControlType, "Calculated", StringComparison.OrdinalIgnoreCase) &&
        !string.Equals(r.ControlType, "Popup", StringComparison.OrdinalIgnoreCase);
    private static void Add(List<TabErrorsDto> errors, string tab, List<string> messages)
    {
        if (messages.Count > 0)
            errors.Add(new TabErrorsDto { TabName = tab, Messages = messages });
    }
}