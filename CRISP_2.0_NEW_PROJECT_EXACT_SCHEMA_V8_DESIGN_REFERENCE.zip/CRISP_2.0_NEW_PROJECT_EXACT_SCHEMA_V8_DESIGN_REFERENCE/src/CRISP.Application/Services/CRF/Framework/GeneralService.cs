﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Application.Interfaces.IServices.CRF.Framework;
using CRISP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Services
{
    public sealed class GeneralService
      : IGeneralService
    {
        private readonly IGeneralRepository _repository;

        public GeneralService(
            IGeneralRepository repository)
        {
            _repository = repository;
        }

        public async Task<GeneralDto?> GetAsync(
            int assessmentResponseId,
            CancellationToken ct = default)
        {
            var entity =
                await _repository.GetAsync(
                    assessmentResponseId,
                    ct);

            if (entity == null)
                return null;

            return new GeneralDto
            {
                FrameworkGeneralId =
                    entity.FrameworkGeneralId,

                AssessmentResponseId =
                    entity.AssessmentResponseId,

                EntityId =
                    entity.EntityId,

                WorkflowJsonVersionId =
                    entity.WorkflowJsonVersionId,

                NoOfPastYears =
                    entity.NoOfPastYears,

                NoOfProjectedYears =
                    entity.NoOfProjectedYears,

                LatestFinancialYear =
                    entity.LatestFinancialYear,

                IsListed =
                    entity.IsListed,

                IsParentSupported =
                    entity.IsParentSupported,

                ParentType =
                    entity.ParentType
            };
        }

        public async Task<GeneralDto> SaveAsync(
            GeneralDto request,
            CancellationToken ct = default)
        {
            Validate(request);

            var entity = new FrameworkGeneral
            {
                AssessmentResponseId =
        request.AssessmentResponseId,

                EntityId =
        request.EntityId,

                WorkflowJsonVersionId =
        request.WorkflowJsonVersionId,

                NoOfPastYears =
        request.NoOfPastYears,

                NoOfProjectedYears =
        request.NoOfProjectedYears,

                LatestFinancialYear =
        request.LatestFinancialYear,

                IsListed =
        request.IsListed,

                IsParentSupported =
        request.IsParentSupported,

                ParentType =
        request.ParentType
            };

            var savedEntity =
                await _repository.SaveAsync(
                    entity,
                    ct);

            return new GeneralDto
            {
                FrameworkGeneralId =
                    savedEntity.FrameworkGeneralId,

                AssessmentResponseId =
                    savedEntity.AssessmentResponseId,

                EntityId =
                    savedEntity.EntityId,

                WorkflowJsonVersionId =
                    savedEntity.WorkflowJsonVersionId,

                NoOfPastYears =
                    savedEntity.NoOfPastYears,

                NoOfProjectedYears =
                    savedEntity.NoOfProjectedYears,

                LatestFinancialYear =
                    savedEntity.LatestFinancialYear,

                IsListed =
                    savedEntity.IsListed,

                IsParentSupported =
                    savedEntity.IsParentSupported,

                ParentType =
                    savedEntity.ParentType
            };
        }

        private static void Validate(
            GeneralDto request)
        {
            if (request.AssessmentResponseId <= 0)
            {
                throw new InvalidOperationException(
                    "AssessmentResponseId is required.");
            }

            if (request.EntityId <= 0)
            {
                throw new InvalidOperationException(
                    "EntityId is required.");
            }

            if (request.WorkflowJsonVersionId <= 0)
            {
                throw new InvalidOperationException(
                    "Workflow version is required.");
            }

            if (request.NoOfPastYears < 0)
            {
                throw new InvalidOperationException(
                    "No Of Past Years cannot be negative.");
            }

            if (request.NoOfProjectedYears < 0)
            {
                throw new InvalidOperationException(
                    "No Of Projected Years cannot be negative.");
            }

            if (request.IsParentSupported &&
                string.IsNullOrWhiteSpace(
                    request.ParentType))
            {
                throw new InvalidOperationException(
                    "Parent Type is required when Parent Support is selected.");
            }
        }

    }
}