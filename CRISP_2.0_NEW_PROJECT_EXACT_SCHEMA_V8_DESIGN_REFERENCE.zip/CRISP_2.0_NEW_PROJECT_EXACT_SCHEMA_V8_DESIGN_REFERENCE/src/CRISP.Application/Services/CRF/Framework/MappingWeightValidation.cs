﻿
using CRISP.Application.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CRISP.Application.Services.CRF.Framework
{
    public static class MappingWeightValidation
    {
        public static string? GetError(
            IEnumerable<IndustryParameterMappingDto> mappings)
        {
            var selected = mappings.Where(x => x.IsMapped).ToList();

            if (selected.Any(x => string.IsNullOrWhiteSpace(x.StepName)))
                return "Select a step for every mapped parameter.";

            if (selected.Any(x => x.Weight < 0))
                return "Parameter weight cannot be negative.";

            // Parent/Group validation
            foreach (var group in selected.Where(
                x => ParameterScoring.IsGroup(x.ControlType)))
            {
                if (group.ParentParameterDefinitionMasterId is not null)
                    return $"Group '{group.ParameterDisplayName}' cannot have a Parent.";

                if (!selected.Any(
                    x => x.ParentParameterDefinitionMasterId ==
                         group.ParameterDefinitionMasterId))
                {
                    return $"Group '{group.ParameterDisplayName}' has no rows: choose it as the Parent of its rows.";
                }
            }

            // Rows excluded from weight calculation must have zero weight.
            var weighted = selected
                .Where(x => !CountsInTotal(x, selected) && x.Weight != 0)
                .Select(x =>
                    $"'{x.ParameterDisplayName}' ({NotWeightedReason(x, selected)})")
                .ToList();

            if (weighted.Count > 0)
            {
                return
                    $"These rows are not part of the 100% total, set their weight to 0: {string.Join("; ", weighted)}.";
            }

            // Validate each step independently.
            var invalidSteps = selected
                .Where(x => CountsInTotal(x, selected))
                .GroupBy(
                    x => x.StepName.Trim(),
                    StringComparer.OrdinalIgnoreCase)
                .Select(g => new
                {
                    Step = g.Key,
                    Weight = g.Sum(x => x.Weight)
                })
                .Where(x => Math.Abs(x.Weight - 100m) > 0.01m)
                .Select(x => $"{x.Step}: {x.Weight:0.##}%")
                .ToList();

            return invalidSteps.Count == 0
                ? null
                : $"Each step with mapped parameters must total 100%. Check {string.Join("; ", invalidSteps)}.";
        }

        public static bool CountsInTotal(
            IndustryParameterMappingDto row,
            IReadOnlyList<IndustryParameterMappingDto> mapped)
        {
            var isFinancialStep = string.Equals(
                row.StepName?.Trim(),
                "Financial",
                StringComparison.OrdinalIgnoreCase);

            // Financial Risk is a weighted section.
            // Its SectionName must not exclude its rows from the total.
            var validSection =
                isFinancialStep ||
                string.IsNullOrWhiteSpace(row.SectionName);

            return validSection
                && !ParameterScoring.IsAnswer(row.ControlType)
                && GroupOf(row, mapped) is null;
        }

        private static IndustryParameterMappingDto? GroupOf(
            IndustryParameterMappingDto row,
            IReadOnlyList<IndustryParameterMappingDto> mapped)
        {
            return row.ParentParameterDefinitionMasterId is int parentId
                ? mapped.FirstOrDefault(x =>
                    x.ParameterDefinitionMasterId == parentId &&
                    ParameterScoring.IsGroup(x.ControlType))
                : null;
        }

        private static string NotWeightedReason(
            IndustryParameterMappingDto row,
            IReadOnlyList<IndustryParameterMappingDto> mapped)
        {
            if (GroupOf(row, mapped) is { } group)
                return $"inside group '{group.ParameterDisplayName}'";

            if (ParameterScoring.IsAnswer(row.ControlType))
                return "a question row";

            return $"in section '{row.SectionName}'";
        }
    }
}
