﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Application.Interfaces;
using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Application.Interfaces.IServices.CRF.Framework;
using CRISP.Application.Services.CRF.Framework;
using CRISP.Domain.Entities;
namespace CRISP.Application.Services;
// replaces dbo.GetFrameworkOutput: validate all tabs, calculate, save a snapshot; a submitted framework is only read
public class OutputService : IOutputService
{
    private readonly IOutputRepository _output;
    private readonly IOtherRepository _others;
    private readonly IFrameworkValidationService _validation;
    private readonly IRuleEvaluationService _business;
    private readonly OutputCalculator _calculator;
    public OutputService(
        IOutputRepository output,
        IOtherRepository others,
        IFrameworkValidationService validation,
        IRuleEvaluationService business,
        OutputCalculator calculator)
    {
        _output = output;
        _others = others;
        _validation = validation;
        _business = business;
        _calculator = calculator;
    }
    public async Task<RunOutputResultDto> RunAsync(int assessmentResponseId, RunOutputRequestDto request, string userName,
CancellationToken ct = default)
    {
        var assessment = await _output.GetAssessmentAsync(assessmentResponseId, ct)
            ?? throw new KeyNotFoundException("Framework not found.");
        // Submitted: show the saved result, never recalculate (SP ELSE branch)
        if (IsSubmitted(assessment))
            return new RunOutputResultDto { Output = await GetAsync(assessmentResponseId, ct) };
        // all tabs at once (SP steps 4-7)
        var errors = await _validation.ValidateAsync(assessmentResponseId, ct);
        if (errors.Count > 0)
            return new RunOutputResultDto { Errors = errors };
        // Business tab score, worked out on the server from the analyst's inputs, for the framework's own version only
        var version = assessment.WorkflowJsonVersion;
        if (!string.Equals(request.Business.WorkflowCode, version.WorkflowCode, StringComparison.OrdinalIgnoreCase)
            || request.Business.VersionNo != version.VersionNo)
            return Error("Business Tab", "The business inputs belong to another workflow version. Please reload the framework.");
        var business = await _business.EvaluateAsync(request.Business, ct);
        if (!business.Success)
            return Error("Business Tab", business.Message);
        var general = (await _output.GetGeneralAsync(assessmentResponseId, ct))!;   // checked by the validation
        List<OutputCalculator.OutputValue> values;
        try
        {
            values = await _calculator.CalculateAsync(assessment, general, business.WeightedAverageScore, ct);
        }
        catch (RatingConfigurationException ex)
        {
            return Error("Output Tab", ex.Message);                                 // configuration message, no internals
        }
        var now = DateTime.UtcNow;
        await _output.SaveOutputAsync(assessmentResponseId, values.Select(v => new FrameworkOutputDetails
        {
            AssessmentResponseId = assessmentResponseId,
            IndustryParameterMappingId = v.MappingId,
            ValueNumber = v.Number,
            ValueText = v.Text,
            ValueNumberProj = v.NumberProj,
            ValueTextProj = v.TextProj,
            CalculatedOn = now,
            CalculatedBy = userName
        }).ToList(), ct);
        return new RunOutputResultDto { Output = await GetAsync(assessmentResponseId, ct) };
    }
    // configured Output rows with the saved values, grouped by SectionName
    public async Task<FrameworkOutputDto> GetAsync(int assessmentResponseId, CancellationToken ct = default)
    {
        var assessment = await _output.GetAssessmentAsync(assessmentResponseId, ct)
            ?? throw new KeyNotFoundException("Framework not found.");
        var rows = await _output.GetRowsAsync(assessment.WorkflowJsonVersionId, OutputCalculator.StepName, ct);
        var saved = (await _output.GetOutputAsync(assessmentResponseId, ct)).ToDictionary(x =>
x.IndustryParameterMappingId);
        var answers = (await _others.GetScoresAsync(assessmentResponseId, ct)).ToDictionary(x =>
x.IndustryParameterMappingId);
        var options = (await _others.GetRatingScaleAsync(ct)).Select(r => r.RatingCode).ToList();
        return new FrameworkOutputDto
        {
            AssessmentResponseId = assessmentResponseId,
            Status = assessment.Status,
            CalculatedOn = saved.Values.Select(x => (DateTime?)x.CalculatedOn).Max(),
            Sections = rows
                .GroupBy(r => string.IsNullOrWhiteSpace(r.Mapping.SectionName) ? "Rating" : r.Mapping.SectionName!)
                .Select(g => new OutputSectionDto
                {
                    Title = g.Key,
                    Rows = g.Select(r =>
                    {
                        var isDropdown = IsDropdown(r.Mapping);
                        var id = r.Mapping.IndustryParameterMappingId;
                        return new OutputRowDto
                        {
                            IndustryParameterMappingId = id,
                            Code = r.Code,
                            Name = r.Mapping.ParameterDisplayName,
                            ControlType = r.Mapping.ControlType ?? "Calculated",
                            Value = isDropdown ? answers.GetValueOrDefault(id)?.ValueText :
saved.GetValueOrDefault(id)?.ValueText,
                            Options = isDropdown ? options : []
                        };
                    }).ToList()
                })
                .ToList()
        };
    }
    // Analyst N1 / RC ratings (Dropdown rows of the Output step), saved as FrameworkParameterScore.ValueText
    public async Task SaveRatingsAsync(SaveOutputRatingsRequestDto request, CancellationToken ct = default)
    {
        var assessment = await _output.GetAssessmentAsync(request.AssessmentResponseId, ct)
            ?? throw new KeyNotFoundException("Framework not found.");
        if (IsSubmitted(assessment))
            throw new InvalidOperationException("A submitted framework cannot be changed.");
        var dropdowns = (await _output.GetRowsAsync(assessment.WorkflowJsonVersionId, OutputCalculator.StepName, ct))
            .Where(r => IsDropdown(r.Mapping))
            .Select(r => r.Mapping.IndustryParameterMappingId)
            .ToHashSet();
        var ratings = (await _others.GetRatingScaleAsync(ct))
            .Select(r => r.RatingCode)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        // only this version's Dropdown rows and ratings of the scale (no IDOR / free text)
        var answers = new Dictionary<int, AnalystAnswer>();
        foreach (var (mappingId, rating) in request.Ratings)
        {
            if (!dropdowns.Contains(mappingId))
                throw new InvalidOperationException("Unknown Output row.");
            if (!string.IsNullOrWhiteSpace(rating) && !ratings.Contains(rating))
                throw new InvalidOperationException($"'{rating}' is not a valid rating.");
            answers[mappingId] = new AnalystAnswer(null, string.IsNullOrWhiteSpace(rating) ? null : rating.Trim());
        }
        if (answers.Count > 0)
            await _others.SaveAnalystScoresAsync(request.AssessmentResponseId, answers, ct);
    }
    private static bool IsDropdown(IndustryParameterMapping m) =>
        string.Equals(m.ControlType, "Dropdown", StringComparison.OrdinalIgnoreCase);
    private static bool IsSubmitted(AssessmentResponse a) =>
        string.Equals(a.Status, "Submitted", StringComparison.OrdinalIgnoreCase);
    private static RunOutputResultDto Error(string tab, string message) =>
        new() { Errors = [new TabErrorsDto { TabName = tab, Messages = [message] }] };
}