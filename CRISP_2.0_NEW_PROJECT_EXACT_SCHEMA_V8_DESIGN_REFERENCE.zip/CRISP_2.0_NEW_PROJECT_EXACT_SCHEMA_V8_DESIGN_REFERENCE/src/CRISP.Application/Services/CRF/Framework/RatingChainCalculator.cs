﻿
using System;
using System.Collections.Generic;
using System.Linq;

namespace CRISP.Application.Services.CRF.Framework;

public sealed record RatingPoint(
    string Code,
    int Notch,
    int? PgScore,
    decimal? PgWeight);

public sealed record ChainStep(
    string ParameterCode,
    decimal? Score,
    int? Notch,
    string Rating);

public sealed class RatingChainCalculator(
    RatingMatrixLookup logic,
    IReadOnlyList<RatingPoint> scale)
{
    public List<ChainStep> Run(RatingChainInput i)
    {
        var steps = new List<ChainStep>();

        var industry = RatingMatrixLookup.IndustryScore(i.IndustryRating);
        var business = i.BusinessScore * 6m / 5m;
        var adjBusiness = i.AdjustedBusinessScore ?? business;

        steps.Add(new ChainStep("IndustryRisk", industry, null, i.IndustryRating));
        steps.Add(Score("BusinessRating", business));
        steps.Add(Score("AdjustedBusinessRating", adjBusiness));

        var wOp = logic.Cell(
            "OPERATING_WEIGHT",
            logic.Band("SCORE6", adjBusiness),
            industry.ToString());

        var operating = industry * wOp + adjBusiness * (1 - wOp);
        steps.Add(Score("OverallOperatingRating", operating));
        steps.Add(Score("FinancialRating", i.FinancialScore));

        var wBase = logic.Cell(
            "BASE_WEIGHT",
            logic.Band("SCORE6", operating),
            logic.Band("SCORE6", i.FinancialScore));

        var baseScore = i.FinancialScore * wBase + operating * (1 - wBase);
        var notch = Notch(logic.Band("RATING16", baseScore));

        steps.Add(new ChainStep(
            "BaseRating",
            baseScore,
            notch,
            ByNotch(notch).Code));

        notch -= (int)logic.Cell(
            "DIVERSIFICATION",
            i.Diversification,
            logic.Band("SCORE6", i.WeightedBusinessScore));

        steps.Add(At("DiversificationRating", ref notch));

        var la = logic.Cell(
            "LIQ_ALM",
            i.Liquidity.ToString(),
            i.Alm ?? "Adequate");

        var laff = logic.Cell(
            "LIQ_FINFLEX",
            la.ToString("0"),
            i.FinancialFlexibility);

        notch -= (int)logic.Cell(
            "ADJ_LIQUIDITY",
            laff.ToString("0"),
            Range(notch));

        steps.Add(At(
            "LiquidityALMAndFinancialFlexibilityRating",
            ref notch));

        notch -= (int)logic.Cell(
            "ADJ_FOREX",
            i.ForexRisk,
            Range(notch));

        steps.Add(At("ForeignExchangeRiskRating", ref notch));

        notch -= (int)logic.Cell(
            "ADJ_FINPOLICY",
            i.FinancialPolicy,
            Range(notch));

        steps.Add(At("FinancialPolicyRating", ref notch));

        notch -= (int)logic.Cell(
            "ADJ_MG",
            i.ManagementGovernance,
            Range(notch));

        steps.Add(At("ManagementAndGovernanceRating", ref notch));

        var n1 = ByNotch(notch);

        steps.Add(new ChainStep(
            "FrameworkImpliedRatingN1",
            null,
            n1.Notch,
            n1.Code));

        if (i.Support is { } s)
        {
            steps.Add(Rating(
                "FrameworkImpliedRatingN2",
                SupportUplift(n1, s)));

            if (i.AnalystN1 is { } a)
            {
                steps.Add(Rating(
                    "RatingFactoringInParentGroupSupport",
                    SupportUplift(ByCode(a), s)));
            }
        }

        return steps;
    }

    public RatingPoint SupportUplift(RatingPoint n1, SupportInput s)
    {
        var sp = ByCode(s.ProviderRating);

        if (!s.Acknowledged ||
            n1.PgScore is null ||
            sp.PgScore is null ||
            n1.PgScore >= sp.PgScore)
        {
            return n1;
        }

        decimal w1 = n1.PgWeight!.Value;
        decimal wSp = sp.PgWeight!.Value;
        decimal l = s.Likelihood;
        decimal c = s.Correlation;

        var step2 = (1 - l) * w1 +
                    l * (c * wSp + (1 - c) * w1 * wSp);

        var g = Math.Max(step2, wSp);

        var step3 = scale
            .Where(r => r.PgWeight >= g)
            .MinBy(r => r.PgWeight)
            ?? scale.MaxBy(r => r.PgWeight)!;

        var step4 = ByPgScore(Math.Min(step3.PgScore!.Value + 1, 19));
        var step5 = ByPgScore(step4.PgScore!.Value - 1);

        if (step4.PgScore > sp.PgScore)
            return sp;

        var gap = step2 - step4.PgWeight!.Value;
        var span = step5.PgWeight!.Value - step4.PgWeight.Value;

        if (gap >= 0.75m * span)
            return step5;

        if (gap <= 0.5m * span)
            return step4;

        return step4 with
        {
            Code = $"{step4.Code}/{step5.Code}"
        };
    }

    private string Range(int notch) =>
        logic.Band("ANCHOR_RANGE", notch);

    private ChainStep At(string code, ref int notch)
    {
        notch = Math.Clamp(notch, 1, 20);

        return new ChainStep(
            code,
            null,
            notch,
            ByNotch(notch).Code);
    }

    private ChainStep Score(string code, decimal score) =>
        new(code, score, null, logic.Band("RATING16", score));

    private static ChainStep Rating(string code, RatingPoint r) =>
        new(code, null, r.Notch, r.Code);

    private int Notch(string code) =>
        ByCode(code).Notch;

    private RatingPoint ByCode(string code) =>
        scale.FirstOrDefault(r =>
            string.Equals(
                r.Code,
                code,
                StringComparison.OrdinalIgnoreCase))
        ?? throw new RatingConfigurationException(
            $"Rating '{code}' is not in the rating scale.");

    private RatingPoint ByNotch(int notch) =>
        scale.First(r => r.Notch == notch);

    private RatingPoint ByPgScore(int score) =>
        scale.First(r => r.PgScore == score);
}

public sealed record SupportInput(
    bool Acknowledged,
    string ProviderRating,
    decimal Likelihood,
    decimal Correlation);

public sealed record RatingChainInput(
    string IndustryRating,
    decimal BusinessScore,
    decimal? AdjustedBusinessScore,
    decimal FinancialScore,
    decimal WeightedBusinessScore,
    string Diversification,
    int Liquidity,
    string? Alm,
    string FinancialFlexibility,
    string ForexRisk,
    string FinancialPolicy,
    string ManagementGovernance,
    SupportInput? Support,
    string? AnalystN1);
