﻿using System.Text.Encodings.Web;
using System.Text.Json;
using CRISP.Application.DTOs;

namespace CRISP.Application.Services.CRF.Framework;

// the stored JSON of a workflow version: [ { WorkflowName, Parameters, Weights, Rules, ... } ]
public static class WorkflowDefinitionJson
{
    private static readonly JsonSerializerOptions ReadOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        PropertyNamingPolicy = null,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    private static readonly JsonSerializerOptions WriteOptions = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = null,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    // an empty definition (with the workflow name) when the JSON is missing or invalid
    public static WorkflowDefinitionDto Parse(string? json, string workflowName)
    {
        try
        {
            var root = JsonDocument.Parse(json ?? string.Empty).RootElement;
            if (root.ValueKind == JsonValueKind.Array)
                root = root.EnumerateArray().FirstOrDefault();

            return JsonSerializer.Deserialize<WorkflowDefinitionDto>(root.GetRawText(), ReadOptions)
                   ?? new WorkflowDefinitionDto { WorkflowName = workflowName };
        }
        catch (Exception ex) when (ex is JsonException or InvalidOperationException or ArgumentException or NotSupportedException)
        {
            return new WorkflowDefinitionDto { WorkflowName = workflowName };
        }
    }

    public static string Serialize(WorkflowDefinitionDto definition) =>
        JsonSerializer.Serialize(new[] { definition }, WriteOptions);
}