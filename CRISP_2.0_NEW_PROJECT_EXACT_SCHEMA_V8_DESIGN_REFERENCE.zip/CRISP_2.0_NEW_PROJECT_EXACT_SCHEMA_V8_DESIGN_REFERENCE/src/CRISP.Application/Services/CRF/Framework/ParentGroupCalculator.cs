﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Application.Interfaces;
using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.Json.Nodes;

namespace CRISP.Application.Services.CRF.Framework
{

    /*
     * Parent/Group tab: weighted score and the uplift.
     *
     * Inputs of the rules (by the parameter code of each row of the step):
     *   Score row     CODE = selected score (number, or the letter of a letter score)
     *   Group row     CODE = average score of its rows
     *   Rating list   CODE = "AA", CODE_ORDER = 3 (1 = AAA)
     *   Text / Yes-No CODE = the answer
     *   WEIGHTED_SCORE = weights x scores / weights of the parameters table
     *
     * Every Calculated row is worked out in display order from its own rule steps
     * (RuleDefinition: first IF that is true gives the value); its result is an input of the next ones.
     * A Calculated row with the Ratings list turns a number into the rating of that order (3 -> AA).
     */
    public class ParentGroupCalculator
    {
        public const string StepName = "ParentGroup";
        public const string WeightedScoreCode = "WEIGHTED_SCORE";
        private const string RatingScaleOptions = "RatingScale";

        private readonly IOtherRepository _repository;
        private readonly IRuleEngineExecutor _ruleEngine;

        public ParentGroupCalculator(IOtherRepository repository, IRuleEngineExecutor ruleEngine)
        {
            _repository = repository;
            _ruleEngine = ruleEngine;
        }

        public async Task<ParentGroupResultDto> CalculateAsync(
            int workflowJsonVersionId,
            int assessmentResponseId,
            CancellationToken ct = default)
        {
            if (assessmentResponseId <= 0)
                throw new InvalidOperationException("Please save the framework first.");

            var rows = await LoadRowsAsync(workflowJsonVersionId, ct);
            var result = new ParentGroupResultDto();
            if (rows.Count == 0)
                return result;

            var saved = (await _repository.GetScoresAsync(assessmentResponseId, ct))
                .ToDictionary(x => x.IndustryParameterMappingId);
            var masters = (await _repository.GetMastersAsync(rows.Select(x => x.Mapping.ParameterDefinitionMasterId).Distinct().ToList(), ct))
                .ToDictionary(x => x.ParameterDefinitionMasterId);
            var ratings = (await _repository.GetRatingScaleAsync(ct))
                .ToDictionary(x => x.RatingCode, x => x.DisplayOrder, StringComparer.OrdinalIgnoreCase);

            string Code(IndustryParameterMapping m) =>
                masters.TryGetValue(m.ParameterDefinitionMasterId, out var master) ? master.ParameterCode : $"P{m.IndustryParameterMappingId}";

            decimal? Score(IndustryParameterMapping m) =>
                saved.TryGetValue(m.IndustryParameterMappingId, out var s) ? s.AnalystScore ?? s.CalculatedScore : null;

            string? Text(IndustryParameterMapping m) =>
                saved.TryGetValue(m.IndustryParameterMappingId, out var s) ? s.ValueText : null;

            // ------------------------------------------------ inputs and missing answers
            var inputs = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            var groupScores = new Dictionary<int, decimal?>();

            foreach (var (mapping, level) in rows)
            {
                var code = Code(mapping);

                if (ParameterScoring.IsGroup(mapping.ControlType))
                {
                    var childScores = rows
                        .Where(x => x.Level > 0 && x.Mapping.ParentIndustryParameterMappingId == mapping.IndustryParameterMappingId)
                        .Select(x => Score(x.Mapping))
                        .ToList();

                    var average = childScores.Count > 0 && childScores.All(x => x.HasValue)
                        ? Math.Round(childScores.Average(x => x!.Value), 2)
                        : (decimal?)null;

                    groupScores[mapping.IndustryParameterMappingId] = average;
                    inputs[code] = average ?? 0m;
                    continue;
                }

                if (string.Equals(mapping.ControlType, "Calculated", StringComparison.OrdinalIgnoreCase))
                    continue;

                var text = Text(mapping);
                var score = Score(mapping);

                if (ParameterScoring.IsAnswer(mapping.ControlType))
                {
                    inputs[code] = text ?? string.Empty;

                    if (IsRatingList(mapping))
                        inputs[$"{code}_ORDER"] = text is not null && ratings.TryGetValue(text, out var order) ? (decimal)order : 0m;
                }
                else
                {
                    // a letter score is saved as the text answer
                    inputs[code] = score is decimal number ? number : (object)(text ?? string.Empty);
                }

                if (score is null && string.IsNullOrWhiteSpace(text))
                    result.Missing.Add(mapping.ParameterDisplayName);
            }

            // ------------------------------------------------ weighted score of the parameters table
            var weighted = rows
                .Where(x => x.Level == 0 &&
                            string.IsNullOrWhiteSpace(x.Mapping.SectionName) &&
                            !ParameterScoring.IsAnswer(x.Mapping.ControlType) &&
                            x.Mapping.Weight > 0)
                .Select(x => new
                {
                    x.Mapping.Weight,
                    Score = ParameterScoring.IsGroup(x.Mapping.ControlType)
                        ? groupScores.GetValueOrDefault(x.Mapping.IndustryParameterMappingId)
                        : Score(x.Mapping)
                })
                .ToList();

            var totalWeight = weighted.Where(x => x.Score.HasValue).Sum(x => x.Weight);
            result.WeightedScore = totalWeight > 0
                ? Math.Round(weighted.Where(x => x.Score.HasValue).Sum(x => x.Weight * x.Score!.Value) / totalWeight, 2)
                : null;
            inputs[WeightedScoreCode] = result.WeightedScore ?? 0m;

            // ------------------------------------------------ Calculated rows from their rule steps
            var ratingByOrder = ratings.ToDictionary(x => x.Value, x => x.Key);
            var answers = new Dictionary<int, AnalystAnswer>();

            foreach (var (mapping, _) in rows.Where(x => string.Equals(x.Mapping.ControlType, "Calculated", StringComparison.OrdinalIgnoreCase)))
            {
                var code = Code(mapping);
                var rules = await _repository.GetRulesAsync(mapping.IndustryParameterMappingId, ct);
                if (rules.Count == 0)
                {
                    // no rule steps yet: keep what is saved
                    inputs[code] = Text(mapping) ?? string.Empty;
                    continue;
                }

                // unanswered rows would count as 0 (e.g. 3 notches of uplift): no result until all are answered
                if (result.Missing.Count > 0)
                {
                    answers[mapping.IndustryParameterMappingId] = new AnalystAnswer(null, null);
                    result.Results.Add(new ParentGroupValueDto
                    {
                        IndustryParameterMappingId = mapping.IndustryParameterMappingId,
                        Name = mapping.ParameterDisplayName
                    });
                    continue;
                }

                var output = await RunAsync(mapping, rules, inputs, ct);
                var number = ToNumber(output);

                string? text;
                if (IsRatingList(mapping))
                {
                    // number -> rating of that order; 0 / out of the scale = no rating
                    text = number is decimal order && ratingByOrder.TryGetValue((int)order, out var rating) ? rating : null;
                    inputs[$"{code}_ORDER"] = number ?? 0m;
                    inputs[code] = text ?? string.Empty;
                }
                else
                {
                    text = number is decimal n ? n.ToString("0.##", CultureInfo.InvariantCulture) : Convert.ToString(output, CultureInfo.InvariantCulture);
                    inputs[code] = number ?? (object)(text ?? string.Empty);
                }

                answers[mapping.IndustryParameterMappingId] = new AnalystAnswer(number, string.IsNullOrWhiteSpace(text) ? null : text);
                result.Results.Add(new ParentGroupValueDto
                {
                    IndustryParameterMappingId = mapping.IndustryParameterMappingId,
                    Name = mapping.ParameterDisplayName,
                    Value = text
                });
            }

            if (answers.Count > 0)
                await _repository.SaveAnalystScoresAsync(assessmentResponseId, answers, ct);

            result.Inputs = inputs
                .OrderBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
                .Select(x => $"{x.Key} = {Display(x.Value)}")
                .ToList();

            return result;
        }

        // rows of the step; a Group row is followed by its rows (Level 1)
        private async Task<List<(IndustryParameterMapping Mapping, int Level)>> LoadRowsAsync(int workflowJsonVersionId, CancellationToken ct)
        {
            var rows = new List<(IndustryParameterMapping Mapping, int Level)>();
            foreach (var row in await _repository.GetOthersAsync(workflowJsonVersionId, StepName, ct))
            {
                rows.Add((row, 0));
                if (ParameterScoring.IsGroup(row.ControlType))
                    rows.AddRange((await _repository.GetChildrenAsync(row.IndustryParameterMappingId, ct)).Select(c => (c, 1)));
            }

            return rows;
        }

        private async Task<object?> RunAsync(
            IndustryParameterMapping mapping,
            List<RuleDefinition> rules,
            Dictionary<string, object> inputs,
            CancellationToken ct)
        {
            var engineRules = new JsonArray();
            foreach (var rule in rules)
            {
                engineRules.Add(new JsonObject
                {
                    ["RuleName"] = rule.RuleName,
                    ["Expression"] = string.IsNullOrWhiteSpace(rule.Expression) ? "true" : rule.Expression,
                    ["OutputExpression"] = rule.OutputExpression
                });
            }

            var workflow = new JsonObject
            {
                ["WorkflowName"] = $"ParentGroup{mapping.IndustryParameterMappingId}",
                ["GlobalParams"] = new JsonArray(),
                ["Rules"] = engineRules
            };

            var result = await _ruleEngine.ExecuteWorkflowAsync(workflow.ToJsonString(), inputs, ct);
            if (!result.Success)
                throw new InvalidOperationException($"'{mapping.ParameterDisplayName}' could not be calculated: {result.Message}");

            return result.FirstSuccessOutput;
        }

        private static bool IsRatingList(IndustryParameterMapping mapping) =>
            string.Equals(mapping.OptionsSource?.Trim(), RatingScaleOptions, StringComparison.OrdinalIgnoreCase);

        private static decimal? ToNumber(object? value) => value switch
        {
            null => null,
            decimal d => d,
            int i => i,
            long l => l,
            double d => Convert.ToDecimal(d, CultureInfo.InvariantCulture),
            float f => Convert.ToDecimal(f, CultureInfo.InvariantCulture),
            string s => PopupCalculator.ParseDecimal(s),
            _ => PopupCalculator.ParseDecimal(Convert.ToString(value, CultureInfo.InvariantCulture))
        };

        private static string Display(object value) => value switch
        {
            decimal d => d.ToString("0.##", CultureInfo.InvariantCulture),
            string s => $"\"{s}\"",
            _ => Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty
        };
    }
}

