﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Application.Interfaces;
using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.Json.Nodes;

namespace CRISP.Application.Services.CRF.Framework
{
    /*
    * Calculates one popup of the Others tab (e.g. Update Liquidity Details) with the rule engine.
    * Replaces the stored procedure GetLiquidityDetails; everything comes from configuration:
    *
    *   Input    fields   -> saved answer (or DefaultValue)
    *   Spread   fields   -> sum of spread rows * sign, for year + offset (EF Core / SpreadRepository)
    *   Formula  fields   -> RulesEngine GlobalParams, calculated in DisplayOrder
    *   Rule     field    -> output of the first successful score rule (RuleDefinition rows of the popup)
    *
    * Year-wise fields are calculated once per year column. Single-value formulas run afterwards
    * and can use CODE_Y1, CODE_Y2 ... of the year-wise fields.
    * Every saved answer of the assessment is an input, so popups share data by field code.
    */
    public sealed class PopupCalculator
    {
        private readonly IOtherRepository _repository;
        private readonly IGeneralRepository _generalRepository;
        private readonly ISpreadRepository _spreadRepository;
        private readonly IRuleEngineExecutor _ruleEngine;

        public PopupCalculator(
            IOtherRepository repository,
            IGeneralRepository generalRepository,
            ISpreadRepository spreadRepository,
            IRuleEngineExecutor ruleEngine)
        {
            _repository = repository;
            _generalRepository = generalRepository;
            _spreadRepository = spreadRepository;
            _ruleEngine = ruleEngine;
        }

        public async Task<PopupCalculation> CalculateAsync(
            int industryParameterMappingId,
            int assessmentResponseId,
            IReadOnlyList<PopupValueInputDto>? screenValues,
            CancellationToken ct = default)
        {
            var mapping = await _repository.GetMappingAsync(industryParameterMappingId, ct)
                          ?? throw new InvalidOperationException("Parameter not found.");
            var fields = await _repository.GetFieldsAsync(industryParameterMappingId, ct);
            var versionFields = await _repository.GetVersionFieldsAsync(mapping.WorkflowJsonVersionId, ct);
            var general = await _generalRepository.GetAsync(assessmentResponseId, ct);

            // ------------------------------------------------ year columns
            var years = new List<int>();
            if (fields.Any(f => f.IsYearWise))
            {
                if (general?.LatestFinancialYear is not int latest)
                    throw new InvalidOperationException("Please complete the General tab (latest financial year) first.");

                var first = latest + (mapping.YearFromOffset ?? 0);
                years = Enumerable.Range(first, Math.Max(mapping.YearColumns ?? 1, 1)).ToList();
            }

            // ------------------------------------------------ saved answers of the whole assessment
            var store = new Dictionary<(int FieldId, int? Year), (string? Value, bool Overridden)>();
            foreach (var r in await _repository.GetResponsesAsync(assessmentResponseId, ct))
                store[(r.ParameterFieldDefinitionId, r.FinancialYear)] = (r.FieldValue, r.IsOverridden);

            // values on the screen (Calculate / Save)
            if (screenValues is not null)
            {
                foreach (var input in screenValues)
                {
                    var field = fields.FirstOrDefault(f => f.ParameterFieldDefinitionId == input.FieldId);
                    if (field is null)
                        continue;

                    var key = (field.ParameterFieldDefinitionId, field.IsYearWise ? input.Year : null);

                    if (field.SourceType == FieldSourceTypes.Input)
                        store[key] = (input.Value, false);
                    else if (field.IsOverridable && input.IsOverridden)
                        store[key] = (input.Value, true);
                    else if (field.IsOverridable)
                        store.Remove(key);                         // back to the calculated value
                }
            }

            // ------------------------------------------------ spread
            // missing spread: the popup still opens (values 0) with the message, like the old screen
            var spread = new List<SpreadValue>();
            string? warning = null;
            if (years.Count > 0 && fields.Any(f => f.SourceType == FieldSourceTypes.Spread))
            {
                var customerCode = await _spreadRepository.GetCustomerCodeAsync(assessmentResponseId, ct);
                if (string.IsNullOrWhiteSpace(customerCode))
                {
                    warning = "Customer code is not set for this entity (CustomerMaster.CustomerCode), so the cash flow values cannot be read from the spread.";
                }
                else if (!await _spreadRepository.HasYearAsync(customerCode, years[^1], ct))
                {
                    warning = $"Financial data is not available. Please upload spreads for FY{years[^1]}";
                }
                else
                {
                    var offsets = fields.Where(f => f.SourceType == FieldSourceTypes.Spread).Select(f => f.SpreadYearOffset).ToList();
                    var spreadYears = Enumerable.Range(years[0] + offsets.Min(), years.Count + offsets.Max() - offsets.Min()).ToList();
                    spread = await _spreadRepository.GetValuesAsync(customerCode, spreadYears, ct);
                }
            }

            var calculation = new PopupCalculation(mapping, fields, years, store, general?.LatestFinancialYear)
            {
                Warning = warning
            };
            var withCode = versionFields
                .Where(f => !string.IsNullOrWhiteSpace(f.FieldCode) && FieldSourceTypes.HasValue(f.SourceType))
                .ToList();

            // ------------------------------------------------ one run per year
            var popupIds = fields.Select(f => f.ParameterFieldDefinitionId).ToHashSet();
            var scoreRules = ScoreRules(await _repository.GetRulesAsync(industryParameterMappingId, ct), fields);
            foreach (var year in years)
            {
                var globals = new JsonArray();
                var globalCodes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var field in fields.Where(f => f.IsYearWise && f.SourceType == FieldSourceTypes.Formula && HasCode(f)))
                {
                    if (IsOverridden(store, field, year))
                        continue;

                    globals.Add(new JsonObject { ["Name"] = field.FieldCode, ["Expression"] = field.Formula ?? "0m" });
                    globalCodes.Add(field.FieldCode!);
                }

                var inputs = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                foreach (var field in withCode)
                {
                    if (globalCodes.Contains(field.FieldCode!))
                        continue;

                    string? value;
                    if (popupIds.Contains(field.ParameterFieldDefinitionId) && field.IsYearWise)
                    {
                        value = field.SourceType == FieldSourceTypes.Spread && !IsOverridden(store, field, year)
                            ? Format(SpreadSum(spread, field, year))
                            : store.TryGetValue((field.ParameterFieldDefinitionId, year), out var saved)
                                ? saved.Value
                                : field.DefaultValue;

                        // keep the value shown on the popup
                        if (field.SourceType is FieldSourceTypes.Spread or FieldSourceTypes.Input &&
                            !IsOverridden(store, field, year))
                        {
                            store[(field.ParameterFieldDefinitionId, year)] = (value, false);
                        }
                    }
                    else
                    {
                        // other popups / single values: the saved answer
                        value = store.TryGetValue((field.ParameterFieldDefinitionId, field.IsYearWise ? year : null), out var saved)
                            ? saved.Value
                            : field.DefaultValue;
                    }

                    inputs[field.FieldCode!] = ToInput(field, value);
                }

                var result = await RunAsync($"Popup{mapping.IndustryParameterMappingId}", globals, (JsonArray)scoreRules.DeepClone(), inputs, ct);

                foreach (var field in fields.Where(f => f.IsYearWise && globalCodes.Contains(f.FieldCode ?? "")))
                {
                    store[(field.ParameterFieldDefinitionId, year)] = (Format(result.Values.GetValueOrDefault(field.FieldCode!)), false);
                }

                foreach (var field in fields.Where(f => f.IsYearWise && f.ResultRole == FieldResultRoles.Score))
                {
                    store[(field.ParameterFieldDefinitionId, year)] = (Format(result.FirstSuccessOutput), false);
                }
            }

            // ------------------------------------------------ single-value fields (average score ...)
            var singleFormulas = fields
                .Where(f => !f.IsYearWise && f.SourceType == FieldSourceTypes.Formula && HasCode(f))
                .Where(f => !IsOverridden(store, f, null))
                .ToList();

            if (singleFormulas.Count > 0)
            {
                var globals = new JsonArray();
                foreach (var field in singleFormulas)
                    globals.Add(new JsonObject { ["Name"] = field.FieldCode, ["Expression"] = field.Formula ?? "0m" });

                var singleIds = singleFormulas.Select(f => f.ParameterFieldDefinitionId).ToHashSet();
                var inputs = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                foreach (var field in withCode.Where(f => !f.IsYearWise && !singleIds.Contains(f.ParameterFieldDefinitionId)))
                {
                    var value = store.TryGetValue((field.ParameterFieldDefinitionId, null), out var saved) ? saved.Value : field.DefaultValue;
                    inputs[field.FieldCode!] = ToInput(field, value);
                }

                foreach (var field in fields.Where(f => f.IsYearWise && HasCode(f)))
                {
                    for (var i = 0; i < years.Count; i++)
                    {
                        var value = store.TryGetValue((field.ParameterFieldDefinitionId, years[i]), out var saved) ? saved.Value : field.DefaultValue;
                        inputs[$"{field.FieldCode}_Y{i + 1}"] = ToInput(field, value);
                    }
                }

                var result = await RunAsync($"Popup{mapping.IndustryParameterMappingId}Summary", globals, new JsonArray(), inputs, ct);

                foreach (var field in singleFormulas)
                    store[(field.ParameterFieldDefinitionId, null)] = (Format(result.Values.GetValueOrDefault(field.FieldCode!)), false);
            }

            // single inputs not answered yet show their default
            foreach (var field in fields.Where(f => !f.IsYearWise && f.SourceType == FieldSourceTypes.Input))
            {
                if (!store.ContainsKey((field.ParameterFieldDefinitionId, null)) && field.DefaultValue is not null)
                    store[(field.ParameterFieldDefinitionId, null)] = (field.DefaultValue, false);
            }

            // ------------------------------------------------ score of the parent row (Others tab)
            calculation.CalculatedScore = RoleValue(calculation, FieldResultRoles.ParentScore);
            calculation.MinAllowedScore = RoleValue(calculation, FieldResultRoles.MinScore) ?? calculation.CalculatedScore;

            return calculation;
        }

        private async Task<RuleWorkflowResult> RunAsync(
            string workflowName,
            JsonArray globals,
            JsonArray rules,
            Dictionary<string, object> inputs,
            CancellationToken ct)
        {
            var workflow = new JsonObject
            {
                ["WorkflowName"] = workflowName,
                ["GlobalParams"] = globals,
                ["Rules"] = rules
            };

            var result = await _ruleEngine.ExecuteWorkflowAsync(workflow.ToJsonString(), inputs, ct);
            if (!result.Success)
                throw new InvalidOperationException($"Calculation failed: {result.Message}");

            return result;
        }

        // RuleDefinition rows of the popup, in order (only when a field receives the score)
        private static JsonArray ScoreRules(List<RuleDefinition> rules, List<ParameterFieldDefinition> fields)
        {
            var result = new JsonArray();
            if (!fields.Any(f => f.ResultRole == FieldResultRoles.Score))
                return result;

            foreach (var rule in rules)
            {
                result.Add(new JsonObject
                {
                    ["RuleName"] = rule.RuleName,
                    ["Expression"] = string.IsNullOrWhiteSpace(rule.Expression) ? "true" : rule.Expression,
                    ["OutputExpression"] = rule.OutputExpression
                });
            }

            return result;
        }

        private static decimal SpreadSum(List<SpreadValue> spread, ParameterFieldDefinition field, int year)
        {
            var codes = (field.SpreadRows ?? string.Empty)
                .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(x => int.TryParse(x, out var n) ? n : (int?)null)
                .Where(x => x is not null)
                .Select(x => x!.Value)
                .ToHashSet();

            var target = year + field.SpreadYearOffset;

            // cash flow statement rows (SpreadMainTemplate.SubCategoryCode = 2), or template codes
            var sum = field.SpreadByTemplate
                ? spread.Where(s => s.Year == target && codes.Contains(s.TemplateCode)).Sum(s => s.Value)
                : spread.Where(s => s.Year == target && s.SubCategoryCode == 2 &&
                                    s.RowPosition is int row && codes.Contains(row)).Sum(s => s.Value);

            return sum * field.SpreadSign;
        }

        private static decimal? RoleValue(PopupCalculation calculation, string role)
        {
            var field = calculation.Fields.FirstOrDefault(f => f.ResultRole == role);
            if (field is null)
                return null;

            var key = (field.ParameterFieldDefinitionId, field.IsYearWise ? calculation.Years.LastOrDefault() : (int?)null);
            return calculation.Store.TryGetValue(key, out var saved) ? ParseDecimal(saved.Value) : null;
        }

        private static bool HasCode(ParameterFieldDefinition field) =>
            !string.IsNullOrWhiteSpace(field.FieldCode);

        private static bool IsOverridden(
            Dictionary<(int FieldId, int? Year), (string? Value, bool Overridden)> store,
            ParameterFieldDefinition field,
            int? year) =>
            field.IsOverridable &&
            store.TryGetValue((field.ParameterFieldDefinitionId, field.IsYearWise ? year : null), out var saved) &&
            saved.Overridden;

        // numbers as decimal, everything else as text (the engine compiles per input type)
        private static object ToInput(ParameterFieldDefinition field, string? value) =>
            field.FieldType is "Number" or "Decimal" or "Percent"
                ? ParseDecimal(value) ?? 0m
                : value ?? string.Empty;

        public static decimal? ParseDecimal(string? value) =>
            decimal.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var d) ? d : null;

        private static string? Format(object? value) => value switch
        {
            null => null,
            decimal d => d.ToString(CultureInfo.InvariantCulture),
            double d => Convert.ToDecimal(d, CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture),
            float f => Convert.ToDecimal(f, CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture),
            IFormattable f => f.ToString(null, CultureInfo.InvariantCulture),
            _ => value.ToString()
        };
    }

    public sealed class PopupCalculation
    {
        public PopupCalculation(
            IndustryParameterMapping mapping,
            List<ParameterFieldDefinition> fields,
            List<int> years,
            Dictionary<(int FieldId, int? Year), (string? Value, bool Overridden)> store,
            int? latestFinancialYear)
        {
            Mapping = mapping;
            Fields = fields;
            Years = years;
            Store = store;
            LatestFinancialYear = latestFinancialYear;
        }

        public IndustryParameterMapping Mapping { get; }

        public List<ParameterFieldDefinition> Fields { get; }

        public List<int> Years { get; }

        // (field, year) -> value; year = null for single-value fields
        public Dictionary<(int FieldId, int? Year), (string? Value, bool Overridden)> Store { get; }

        public int? LatestFinancialYear { get; }

        public decimal? CalculatedScore { get; set; }

        public decimal? MinAllowedScore { get; set; }

        // e.g. spread not uploaded
        public string? Warning { get; set; }
    }

}
