﻿using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Application.Interfaces.IServices.CRF.Framework;
using CRISP.Application.Services.CRF.Framework;
using CRISP.Domain.Entities;
using System.Globalization;
namespace CRISP.Application.Services.CRF.Framework;
// Collects the inputs of the Output tab from the other tabs, runs the rating chain (chapter 14B)
// and any extra rule rows of the Output step. Nothing is saved here.
public class OutputCalculator
{
    public const string StepName = "Output";
    // parameter codes of the answers the chain reads (Others and Parent/Group tabs)
    public static class Codes
    {
        public const string Diversification = "DIVERSIFICATION";
        public const string Liquidity = "LIQUIDITY";
        public const string Alm = "ALM";
        public const string FinancialFlexibility = "FIN_FLEXIBILITY";
        public const string ForexRisk = "FOREX_RISK";
        public const string FinancialPolicy = "FIN_POLICY";
        public const string ManagementGovernance = "MGMT_GOVERNANCE";
        public const string SupportAcknowledged = "PG_TRACK_RECORD";
        public const string ProviderRating = "PG_PROVIDER_RATING";
        public const string Likelihood = "PG_LIKELIHOOD";
        // code of the existing Parent/Group row (scripts 12/13); its answer is High / Medium / Low
        public const string Correlation = "Degree of correlation between the entity and the support provider";
        public const string AnalystN1 = "RatingAsAssessedByAnalystN1";
    }
    public sealed record OutputValue(int MappingId, decimal? Number, string? Text, decimal? NumberProj = null, string?
TextProj = null);
    private readonly IOutputRepository _output;
    private readonly IOtherRepository _others;
    private readonly IFinancialRiskService _financial;
    private readonly CalculatedRowRunner _runner;
    public OutputCalculator(IOutputRepository output, IOtherRepository others, IFinancialRiskService financial,
CalculatedRowRunner runner)
    {
        _output = output;
        _others = others;
        _financial = financial;
        _runner = runner;
    }
    public async Task<List<OutputValue>> CalculateAsync(
        AssessmentResponse assessment,
        FrameworkGeneral general,
        decimal businessScore,
        CancellationToken ct = default)
    {
        var versionId = assessment.WorkflowJsonVersionId;
        var logic = new RatingMatrixLookup(
            await _output.GetRatingMatricesAsync(versionId, ct),
            await _output.GetRatingBandsAsync(versionId, ct));
        var ratings = await _others.GetRatingScaleAsync(ct);
        var scale = ratings.Select(r => new RatingPoint(r.RatingCode, r.DisplayOrder, r.PgScore, r.PgWeight)).ToList();
        // answers of the Others, Parent/Group and Output tabs by parameter code
        var saved = (await _others.GetScoresAsync(assessment.AssessmentResponseId, ct))
            .ToDictionary(x => x.IndustryParameterMappingId);
        var answers = new Dictionary<string, FrameworkParameterScore?>(StringComparer.OrdinalIgnoreCase);
        foreach (var step in new[] { "Others", "ParentGroup", StepName })
            foreach (var row in await _output.GetRowsAsync(versionId, step, ct))
                answers[row.Code] = saved.GetValueOrDefault(row.Mapping.IndustryParameterMappingId);
        string Text(string code, bool required = true)
        {
            var s = answers.GetValueOrDefault(code);
            var value = !string.IsNullOrWhiteSpace(s?.ValueText)
    ? s.ValueText.Trim()
    : (s?.AnalystScore ?? s?.CalculatedScore)?.ToString("0.####", CultureInfo.InvariantCulture);
            return value ?? (required
                ? throw new RatingConfigurationException($"'{code}' is not configured or not answered.")
                : string.Empty);
        }
        // industry risk: rating matrix INDUSTRY_RISK, row = industry, column "Score"
        var industryId = await _output.GetIndustryDetailsIdAsync(versionId, ct)
            ?? throw new RatingConfigurationException("The version has no industry.");
        var industryRating = RatingMatrixLookup.IndustryRating(
            (int)logic.Cell("INDUSTRY_RISK", industryId.ToString(CultureInfo.InvariantCulture), "Score"));
        var financial = await _financial.RunAsync(assessment, general, ct)
            ?? throw new RatingConfigurationException("Financial risk is not configured for this version.");
        SupportInput? support = null;
        if (general.IsParentSupported)
        {
            var likelihood = decimal.Parse(Text(Codes.Likelihood), CultureInfo.InvariantCulture);
            support = new SupportInput(
                Acknowledged: string.Equals(Text(Codes.SupportAcknowledged), "Yes", StringComparison.OrdinalIgnoreCase),
                ProviderRating: Text(Codes.ProviderRating),
                Likelihood: likelihood > 1 ? likelihood / 100m : likelihood,          // 85 or 0.85
                Correlation: logic.Cell("PG_CORRELATION", Text(Codes.Correlation), "Value"));
        }
        var analystN1 = Text(Codes.AnalystN1, required: false);
        var chain = new RatingChainCalculator(logic, scale).Run(new RatingChainInput(
            IndustryRating: industryRating,
            BusinessScore: businessScore,
            AdjustedBusinessScore: financial.AdjustedBusinessScore,
            FinancialScore: financial.FinancialScore,
            WeightedBusinessScore: businessScore,                                       // open item 2h
            Diversification: Text(Codes.Diversification),
            Liquidity: int.Parse(Text(Codes.Liquidity), NumberStyles.Integer, CultureInfo.InvariantCulture),
            Alm: Text(Codes.Alm, required: false) is { Length: > 0 } alm ? alm : null,   // default Adequate
            FinancialFlexibility: Text(Codes.FinancialFlexibility),
            ForexRisk: Text(Codes.ForexRisk),
            FinancialPolicy: Text(Codes.FinancialPolicy),
            ManagementGovernance: Text(Codes.ManagementGovernance),
            Support: support,
            AnalystN1: analystN1.Length > 0 ? analystN1 : null));
        // chain results on the configured Output rows (rows an admin removed are skipped)
        var outputRows = await _output.GetRowsAsync(versionId, StepName, ct);
        var byCode = outputRows.ToDictionary(r => r.Code, r => r.Mapping.IndustryParameterMappingId,
StringComparer.OrdinalIgnoreCase);
        var results = new List<OutputValue>();
        var inputs = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        foreach (var step in chain)
        {
            inputs[step.ParameterCode] = step.Rating;
            if (step.Notch is int notch) inputs[$"{step.ParameterCode}_ORDER"] = (decimal)notch;
            if (!byCode.TryGetValue(step.ParameterCode, out var mappingId)) continue;
            results.Add(step.ParameterCode == "FinancialRating" && financial.FinancialScoreProj is decimal proj
                ? new OutputValue(mappingId, step.Score, step.Rating, proj, logic.Band("RATING16", proj))
                : new OutputValue(mappingId, step.Score ?? step.Notch, step.Rating));
        }
        // extra Calculated rows with their own rules, e.g. a cap on N1
        var done = chain.Select(c => c.ParameterCode).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var extra = outputRows
            .Where(r => string.Equals(r.Mapping.ControlType, "Calculated", StringComparison.OrdinalIgnoreCase) &&
!done.Contains(r.Code))
            .ToList();
        var ratingByOrder = ratings.ToDictionary(r => r.DisplayOrder, r => r.RatingCode);
        foreach (var r in await _runner.RunAsync(extra, inputs, ratingByOrder, ct))
            results.Add(new OutputValue(r.MappingId, r.Number, r.Text));
        return results;
    }
}