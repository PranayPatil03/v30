using CRISP.Application.Interfaces.IServices.CRF.Framework;
using CRISP.Domain.Entities;

namespace CRISP.Application.Services.CRF.Framework;

/// <summary>
/// Temporary Output-tab dependency implementation.
/// It allows the API to start while Chapter 14A financial-risk calculation
/// is not yet implemented. It deliberately returns null, so OutputCalculator
/// reports that financial risk is not configured instead of producing a false score.
/// Replace this registration with the completed financial-risk implementation
/// when all calculation rules and version configuration are available.
/// </summary>
public sealed class FinancialRiskNotConfiguredService : IFinancialRiskService
{
    public Task<FinancialRiskResult?> RunAsync(
        AssessmentResponse assessment,
        FrameworkGeneral general,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(assessment);
        ArgumentNullException.ThrowIfNull(general);
        ct.ThrowIfCancellationRequested();

        return Task.FromResult<FinancialRiskResult?>(null);
    }
}
