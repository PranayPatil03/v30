﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Application.Services.CRF.Framework
{
    public static class ParameterScoring
    {
        public static bool IsModule(string? controlType) =>
            string.Equals(controlType, "Module", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(controlType, "LiquidityModule", StringComparison.OrdinalIgnoreCase);

        public static bool UsesPopupCalculation(string? controlType) =>
            IsModule(controlType) ||
            string.Equals(controlType, "Popup", StringComparison.OrdinalIgnoreCase);

        // heading row whose child rows carry the scores (e.g. "Strategic Importance + Business Linkages")
        public static bool IsGroup(string? controlType) =>
            string.Equals(controlType, "Group", StringComparison.OrdinalIgnoreCase);

        // rows the analyst answers with text or a list choice, not a score (Parent/Group questions)
        public static bool IsAnswer(string? controlType) =>
        string.Equals(controlType, "Text", StringComparison.OrdinalIgnoreCase) ||
        string.Equals(controlType, "Dropdown", StringComparison.OrdinalIgnoreCase);

        public static bool RequiresValueRanges(string? valueType, string? controlType) =>
            string.Equals(valueType, "Value", StringComparison.OrdinalIgnoreCase) &&
            !UsesPopupCalculation(controlType) &&
            !IsGroup(controlType) &&
            !IsAnswer(controlType);

        public static bool IsParentGroupQuestion(string? controlType) =>
        string.Equals(controlType, "Text", StringComparison.OrdinalIgnoreCase) ||
        string.Equals(controlType, "Dropdown", StringComparison.OrdinalIgnoreCase) ||
        string.Equals(controlType, "Calculated", StringComparison.OrdinalIgnoreCase);
    }
}
