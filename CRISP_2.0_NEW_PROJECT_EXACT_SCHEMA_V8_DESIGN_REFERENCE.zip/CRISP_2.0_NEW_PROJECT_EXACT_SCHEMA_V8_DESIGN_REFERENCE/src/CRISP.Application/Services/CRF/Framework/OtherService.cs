﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Application.Interfaces.IServices.CRF.Framework;
using CRISP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace CRISP.Application.Services.CRF.Framework
{
    public class OtherService : IOtherService
    {
        private const string HiddenSection = "Hidden";

        // FrameworkParameterScore.ValueText is VARCHAR(256)
        private const int MaxAnswerLength = 256;

        private readonly IOtherRepository _repository;
        private readonly PopupCalculator _calculator;
        private readonly ParentGroupCalculator _parentGroup;

        public OtherService(
            IOtherRepository repository,
            PopupCalculator calculator,
            ParentGroupCalculator parentGroup)
        {
            _repository = repository;
            _calculator = calculator;
            _parentGroup = parentGroup;
        }

        // Parent/Group tab: weighted score, uplift rows (saved) and unanswered rows
        public Task<ParentGroupResultDto> CalculateParentGroupAsync(
            ParentGroupCalculateRequestDto request,
            CancellationToken ct = default) =>
            _parentGroup.CalculateAsync(request.WorkflowJsonVersionId, request.AssessmentResponseId, ct);

        public async Task<List<OtherTabDto>>
            GetOtherTabsAsync(int workflowJsonVersionId,
                int assessmentResponseId,
                string stepName,
                CancellationToken ct = default)
        {
            var topRows = await _repository.GetOthersAsync(
                    workflowJsonVersionId,
                    string.IsNullOrWhiteSpace(stepName) ? "Others" : stepName.Trim(),
                    ct);

            topRows = topRows
            .OrderBy(x => x.DisplayOrder)
            .ToList();

            // a Group row is followed by its child rows (they carry the scores)
            var rows = new List<(IndustryParameterMapping Mapping, int Level)>();
            foreach (var row in topRows)
            {
                rows.Add((row, 0));

                if (ParameterScoring.IsGroup(row.ControlType))
                {
                    var children = await _repository.GetChildrenAsync(row.IndustryParameterMappingId, ct);
                    rows.AddRange(children.Select(c => (c, 1)));
                }
            }

            var mappings = rows.Select(x => x.Mapping).ToList();

            var scales = await _repository.GetScaleDetailsAsync(
                    mappings.Select(x => x.IndustryParameterMappingId).ToList(),
                    ct);

            var ratings = mappings.Any(x => IsOptions(x.OptionsSource, RatingScaleOptions))
                ? (await _repository.GetRatingScaleAsync(ct)).Select(x => x.RatingCode).ToList()
                : [];

            var scores = assessmentResponseId > 0
                ? await _repository.GetScoresAsync(assessmentResponseId, ct)
                : [];

            var masters = await _repository.GetMastersAsync(
                    mappings.Select(x => x.ParameterDefinitionMasterId).Distinct().ToList(),
                    ct);

            var result = new List<OtherTabDto>();

            foreach (var (x, level) in rows)
            {
                var score = scores.FirstOrDefault(s =>
                    s.IndustryParameterMappingId == x.IndustryParameterMappingId);

                var master = masters.FirstOrDefault(m => m.ParameterDefinitionMasterId == x.ParameterDefinitionMasterId);

                var children = ParameterScoring.IsModule(x.ControlType)
                    ? await GetModulesAsync(x.IndustryParameterMappingId, ct)
                    : [];

                result.Add(new OtherTabDto
                {
                    IndustryParameterMappingId =
                        x.IndustryParameterMappingId,

                    ParameterName =
                        x.ParameterDisplayName,

                    ValueType =
                        x.ValueType,

                    ControlType =
                        x.ControlType ?? string.Empty,

                    HasChildren =
                        children.Count > 0,

                    Children =
                        children,

                    ScoreOptions = scales
                        .Where(s => s.IndustryParameterMappingId == x.IndustryParameterMappingId)
                        .Select(s => new ScoreOptionDto
                        {
                            Value = ScoreValues.ToNumber(s.ScoreValue),
                            Code = ScoreValues.Display(s.ScoreValue),
                            Label = string.IsNullOrWhiteSpace(s.Definition)
                                ? ScoreValues.Display(s.ScoreValue)
                                : s.Definition,
                            Description = s.ScoreDescription
                        })
                        .ToList(),

                    // the mapping's text, otherwise the parameter master's "why it matters"
                    Description = string.IsNullOrWhiteSpace(x.DetailsDescription)
                        ? master?.WhyItMatters
                        : x.DetailsDescription,

                    DetailsNote = x.DetailsNote,

                    CalculatedScore =
                        score?.CalculatedScore,

                    MinAllowedScore =
                        score?.MinAllowedScore,

                    // analyst's choice, otherwise the calculated score
                    SelectedScore =
                        score?.AnalystScore ?? score?.CalculatedScore,

                    SectionName = x.SectionName,

                    Weight = x.Weight,
                    DisplayOrder = x.DisplayOrder,

                    Level = level,

                    ParentIndustryParameterMappingId = level > 0
                        ? x.ParentIndustryParameterMappingId
                        : null,

                    Options = Options(x.OptionsSource, ratings),

                    ValueText = score?.ValueText,

                    HelpText = master?.WhyItMatters
                });
            }

            return result;
        }

        private const string RatingScaleOptions = "RatingScale";
        private const string YesNoOptions = "YesNo";

        private static bool IsOptions(string? source, string name) =>
            string.Equals(source?.Trim(), name, StringComparison.OrdinalIgnoreCase);

        // choices of a Dropdown row
        private static List<string> Options(string? source, IReadOnlyList<string> ratings) =>
            IsOptions(source, RatingScaleOptions) ? [.. ratings]
            : IsOptions(source, YesNoOptions) ? ["Yes", "No"]
            : [];

        public async Task<List<OtherModuleDto>>
            GetModulesAsync(int parentIndustryParameterMappingId,
                CancellationToken ct = default)
        {
            var modules = await _repository.GetChildrenAsync(
                    parentIndustryParameterMappingId,
                    ct);

            return modules.Select(x => new OtherModuleDto
            {
                IndustryParameterMappingId =
                        x.IndustryParameterMappingId,

                ParentIndustryParameterMappingId =
                        x.ParentIndustryParameterMappingId ?? 0,

                ModuleName =
                        x.ParameterDisplayName,

                ControlType =
                        x.ControlType ?? string.Empty
            })
                .ToList();
        }

        public async Task<List<OtherFieldDto>>
            GetFieldsAsync(int industryParameterMappingId,
                int assessmentResponseId,
                CancellationToken ct = default)
        {
            var fields = await _repository.GetFieldsAsync(
                    industryParameterMappingId,
                    ct);

            var responses = await _repository.GetResponsesAsync(
                    assessmentResponseId,
                    ct);

            return fields.Select(field =>
            {
                var saved =
                    responses.FirstOrDefault(
                        x =>
                            x.ParameterFieldDefinitionId ==
                            field.ParameterFieldDefinitionId &&
                            x.FinancialYear == null);

                return new OtherFieldDto
                {
                    ParameterFieldDefinitionId =
                        field.ParameterFieldDefinitionId,

                    IndustryParameterMappingId =
                        field.IndustryParameterMappingId,

                    FieldName =
                        field.FieldName,

                    FieldType =
                        field.FieldType,

                    IsRequired =
                        field.IsRequired,

                    Value =
                        saved?.FieldValue
                };
            })
                .ToList();
        }

        public async Task SaveAsync(SaveOtherTabRequestDto request,
            CancellationToken ct = default)
        {
            Validate(request);

            var responses =
                request.Fields
                    .Select(field =>
                        new FrameworkParameterResponse
                        {
                            AssessmentResponseId =
                                request.AssessmentResponseId,

                            IndustryParameterMappingId =
                                field.IndustryParameterMappingId,

                            ParameterFieldDefinitionId =
                                field.ParameterFieldDefinitionId,

                            FieldValue =
                                field.Value,

                            UpdatedOn =
                                DateTime.UtcNow
                        })
                    .ToList();

            await _repository.SaveResponsesAsync(
                responses,
                ct);
        }

        // ---------------------------------------------------------- popups (rule engine)

        public async Task<PopupDto> GetPopupAsync(
            int industryParameterMappingId,
            int assessmentResponseId,
            CancellationToken ct = default)
        {
            var calculation = await _calculator.CalculateAsync(
                industryParameterMappingId,
                assessmentResponseId,
                null,
                ct);

            return ToDto(calculation);
        }

        public async Task<PopupDto> CalculatePopupAsync(
            SavePopupRequestDto request,
            CancellationToken ct = default)
        {
            ValidateIds(request.AssessmentResponseId, request.IndustryParameterMappingId);

            var calculation = await _calculator.CalculateAsync(
                request.IndustryParameterMappingId,
                request.AssessmentResponseId,
                request.Values,
                ct);

            return ToDto(calculation);
        }

        public async Task<PopupDto> SavePopupAsync(
            SavePopupRequestDto request,
            CancellationToken ct = default)
        {
            ValidateIds(request.AssessmentResponseId, request.IndustryParameterMappingId);

            var calculation = await _calculator.CalculateAsync(
                request.IndustryParameterMappingId,
                request.AssessmentResponseId,
                request.Values,
                ct);

            ValidateRequired(calculation);

            await SaveCalculationAsync(request.AssessmentResponseId, calculation, ct);

            // other popups under the same parameter may use these values
            // (e.g. Contingent Liability -> Update Liquidity Details): recalculate and save them too
            if (calculation.Mapping.ParentIndustryParameterMappingId is int parentId)
            {
                foreach (var sibling in await _repository.GetChildrenAsync(parentId, ct))
                {
                    if (sibling.IndustryParameterMappingId == request.IndustryParameterMappingId)
                        continue;

                    try
                    {
                        var siblingCalculation = await _calculator.CalculateAsync(
                            sibling.IndustryParameterMappingId,
                            request.AssessmentResponseId,
                            null,
                            ct);

                        await SaveCalculationAsync(request.AssessmentResponseId, siblingCalculation, ct);
                    }
                    catch (InvalidOperationException)
                    {
                        // not ready yet (no General tab / spread): it is calculated when it is opened
                    }
                }
            }

            return ToDto(calculation);
        }

        public async Task SaveScoresAsync(
            SaveOtherScoresRequestDto request,
            CancellationToken ct = default)
        {
            if (request.AssessmentResponseId <= 0)
            {
                throw new InvalidOperationException(
                    "AssessmentResponseId is required.");
            }

            var saved = await _repository.GetScoresAsync(request.AssessmentResponseId, ct);

            foreach (var score in request.Scores)
            {
                var row = saved.FirstOrDefault(x =>
                    x.IndustryParameterMappingId == score.IndustryParameterMappingId);

                // higher score = weaker: the analyst may keep or worsen the calculated score
                if (score.Score is decimal value &&
                    row?.MinAllowedScore is decimal min &&
                    value < min)
                {
                    throw new InvalidOperationException(
                        "Score can only be the same as or worse than the calculated score.");
                }
            }

            if (request.Scores.Any(x => x.ValueText?.Trim().Length > MaxAnswerLength))
            {
                throw new InvalidOperationException(
                    $"An answer can have at most {MaxAnswerLength} characters.");
            }

            await _repository.SaveAnalystScoresAsync(
                request.AssessmentResponseId,
                request.Scores
                    .GroupBy(x => x.IndustryParameterMappingId)
                    .ToDictionary(
                        x => x.Key,
                        x => new AnalystAnswer(
                            x.Last().Score,
                            string.IsNullOrWhiteSpace(x.Last().ValueText) ? null : x.Last().ValueText!.Trim())),
                ct);
        }

        private async Task SaveCalculationAsync(
            int assessmentResponseId,
            PopupCalculation calculation,
            CancellationToken ct)
        {
            var fieldIds = calculation.Fields
                .Where(f => FieldSourceTypes.HasValue(f.SourceType))
                .Select(f => f.ParameterFieldDefinitionId)
                .ToList();

            var responses = calculation.Store
                .Where(x => fieldIds.Contains(x.Key.FieldId))
                .Select(x => new FrameworkParameterResponse
                {
                    AssessmentResponseId = assessmentResponseId,
                    IndustryParameterMappingId = calculation.Mapping.IndustryParameterMappingId,
                    ParameterFieldDefinitionId = x.Key.FieldId,
                    FinancialYear = x.Key.Year,
                    FieldValue = x.Value.Value,
                    IsOverridden = x.Value.Overridden,
                    UpdatedOn = DateTime.UtcNow
                })
                .ToList();

            // the popup's score belongs to the parent row on the Others tab (e.g. Liquidity)
            var score = calculation.CalculatedScore is not null
                ? new FrameworkParameterScore
                {
                    IndustryParameterMappingId =
                        calculation.Mapping.ParentIndustryParameterMappingId
                        ?? calculation.Mapping.IndustryParameterMappingId,
                    CalculatedScore = calculation.CalculatedScore,
                    MinAllowedScore = calculation.MinAllowedScore
                }
                : null;

            await _repository.SavePopupAsync(assessmentResponseId, fieldIds, responses, score, ct);
        }

        private static PopupDto ToDto(PopupCalculation calculation)
        {
            return new PopupDto
            {
                IndustryParameterMappingId = calculation.Mapping.IndustryParameterMappingId,
                Name = calculation.Mapping.ParameterDisplayName,
                Years = calculation.Years,
                LatestFinancialYear = calculation.LatestFinancialYear,
                CalculatedScore = calculation.CalculatedScore,
                MinAllowedScore = calculation.MinAllowedScore,
                Warning = calculation.Warning,
                Fields = calculation.Fields
                    .Where(f => !string.Equals(f.SectionName, HiddenSection, StringComparison.OrdinalIgnoreCase))
                    .Select(f => new PopupFieldDto
                    {
                        FieldId = f.ParameterFieldDefinitionId,
                        FieldCode = f.FieldCode ?? string.Empty,
                        FieldName = f.FieldName,
                        FieldType = f.FieldType,
                        SectionName = f.SectionName,
                        IsYearWise = f.IsYearWise,
                        SourceType = f.SourceType,
                        IsEditable = f.SourceType == FieldSourceTypes.Input || f.IsOverridable,
                        IsOverridable = f.IsOverridable,
                        IsRequired = f.IsRequired,
                        ChartSign = f.ChartSign,
                        HelpText = f.HelpText,
                        ShowWhen = f.ShowWhen,
                        Options = ParseOptions(f.OptionsJson),
                        Values = !FieldSourceTypes.HasValue(f.SourceType)
                            ? []
                            : (f.IsYearWise ? calculation.Years.Select(y => (int?)y) : [null])
                                .Select(y =>
                                {
                                    calculation.Store.TryGetValue((f.ParameterFieldDefinitionId, y), out var saved);
                                    return new PopupValueDto { Year = y, Value = saved.Value, IsOverridden = saved.Overridden };
                                })
                                .ToList()
                    })
                    .ToList()
            };
        }

        private static List<string> ParseOptions(string? json)
        {
            if (string.IsNullOrWhiteSpace(json))
                return [];

            try
            {
                return JsonSerializer.Deserialize<List<string>>(json) ?? [];
            }
            catch (JsonException)
            {
                return [];
            }
        }

        private static void ValidateIds(int assessmentResponseId, int industryParameterMappingId)
        {
            if (assessmentResponseId <= 0)
                throw new InvalidOperationException("Please save the framework first.");

            if (industryParameterMappingId <= 0)
                throw new InvalidOperationException("IndustryParameterMappingId is required.");
        }

        private static void ValidateRequired(PopupCalculation calculation)
        {
            foreach (var field in calculation.Fields.Where(f => f.IsRequired && f.SourceType == FieldSourceTypes.Input))
            {
                var years = field.IsYearWise ? calculation.Years.Select(y => (int?)y) : [null];
                foreach (var year in years)
                {
                    if (!calculation.Store.TryGetValue((field.ParameterFieldDefinitionId, year), out var saved) ||
                        string.IsNullOrWhiteSpace(saved.Value))
                    {
                        throw new InvalidOperationException(
                            year is null ? $"{field.FieldName} is required." : $"{field.FieldName} (FY{year}) is required.");
                    }
                }
            }
        }

        private static void Validate(
            SaveOtherTabRequestDto request)
        {
            if (request.AssessmentResponseId <= 0)
            {
                throw new InvalidOperationException(
                    "AssessmentResponseId is required.");
            }

            foreach (var field in request.Fields)
            {
                if (field.IsRequired &&
                    string.IsNullOrWhiteSpace(
                        field.Value))
                {
                    throw new InvalidOperationException(
                        $"{field.FieldName} is required.");
                }
            }
        }

    }


}
