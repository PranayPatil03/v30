using CRISP.Application.DTOs;
using CRISP.Application.Interfaces;
using CRISP.Application.Mappings;
using CRISP.Application.Services.CRF.Framework;
using CRISP.Domain.Entities;
using System.Text.Encodings.Web;
using System.Text.Json;
namespace CRISP.Application.Services;

public class FrameworkService(
IFrameworkRepository repository,
IWorkflowJsonProvider jsonProvider) : IFrameworkService
{
    public Task<IReadOnlyList<WorkflowDto>> GetWorkflowsAsync(CancellationToken ct = default) => repository.GetWorkflowsAsync(ct);
    public async Task<WorkflowDto> CreateWorkflowAsync(CreateWorkflowRequest request, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(request.WorkflowCode))
            throw new InvalidOperationException("Workflow code is required.");
        if (string.IsNullOrWhiteSpace(request.WorkflowName))
            throw new InvalidOperationException("Workflow name is required.");
        var definition = new WorkflowDefinitionDto
        {
            WorkflowName = request.WorkflowName.Trim()
        };
        var jsonOptions = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = null,
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        };
        var skeletonJson = JsonSerializer.Serialize(new[] { definition }, jsonOptions);
        var workflow = await repository.CreateWorkflowAsync(request, skeletonJson, ct);
        jsonProvider.SetDefinitionJson(
        request.WorkflowCode.Trim(),
        1,
        skeletonJson);
        return workflow;
    }
    public Task<WorkflowContextDto?> GetWorkflowContextAsync(string workflowCode, CancellationToken ct = default) => repository.GetWorkflowContextAsync(workflowCode, ct);
    public Task<IReadOnlyList<EntityDto>> SearchEntitiesAsync(string? search, CancellationToken ct = default) => repository.SearchEntitiesAsync(search, ct);
    public Task<IReadOnlyList<FrameworkLookupDto>>
        GetFrameworkOptionsAsync(
            int entityId,
            CancellationToken ct = default)
    {
        return repository.GetFrameworkOptionsAsync(
            entityId,
            ct);
    }
    public Task<IReadOnlyList<IndustrySegmentDto>> GetIndustrySegmentsAsync(string workflowCode, CancellationToken ct = default) => repository.GetIndustrySegmentsAsync(workflowCode, ct);
    public Task<IReadOnlyList<FrameworkStepDto>> GetStepsAsync(string workflowCode, CancellationToken ct = default) => repository.GetStepsAsync(workflowCode, ct);
    public Task<IReadOnlyList<FrameworkListDto>> GetFrameworksAsync(CancellationToken ct = default) => repository.GetFrameworksAsync(ct);
    public Task<IReadOnlyList<ParameterDto>> GetParametersAsync(string workflowCode, CancellationToken ct = default) => repository.GetParametersAsync(workflowCode, ct);
    public Task<ParameterDto?> GetParameterAsync(int parameterId, CancellationToken ct = default) => repository.GetParameterAsync(parameterId, ct);


    // ------------------------------------------------------------ parameter master
    // rules, messages and mapping live here; the repository only reads / writes entities

    public async Task<IReadOnlyList<ParameterDto>> GetParameterMastersAsync(
        CancellationToken ct = default)
    {
        // active first, inactive ones too so they can be switched on again
        return (await repository.GetParameterMastersAsync(ct))
            .OrderByDescending(x => x.IsActive)
            .ThenBy(x => x.ParameterName)
            .Select(x => x.ToDto())
            .ToList();
    }

    public async Task<ParameterDto> SaveParameterMasterAsync(
        ParameterDto request,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(request.ParameterCode))
            throw new InvalidOperationException("Parameter code is required.");

        if (string.IsNullOrWhiteSpace(request.ParameterName))
            throw new InvalidOperationException("Parameter name is required.");

        var parameterCode = request.ParameterCode.Trim();
        if (await repository.ParameterCodeExistsAsync(parameterCode, request.Id, ct))
            throw new InvalidOperationException($"Parameter code '{parameterCode}' already exists.");

        var master = new ParameterDefinitionMaster();
        if (request.Id > 0)
        {
            master = await repository.GetParameterMasterAsync(request.Id, ct)
                     ?? throw new InvalidOperationException($"Parameter master {request.Id} was not found.");
        }

        request.Apply(master);
        await repository.SaveParameterMasterAsync(master, ct);

        return master.ToDto();
    }

    public async Task DeleteParameterMasterAsync(
        int parameterDefinitionMasterId,
        CancellationToken ct = default)
    {
        var master = await repository.GetParameterMasterAsync(parameterDefinitionMasterId, ct)
                     ?? throw new InvalidOperationException($"Parameter master {parameterDefinitionMasterId} was not found.");

        // mapped in a version (also an old or published one): its assessments still need it
        var usedIn = (await repository.GetParameterMasterUsageAsync(parameterDefinitionMasterId, ct))
            .Select(x => $"{x.WorkflowCode} V{x.VersionNo}")
            .ToList();

        if (usedIn.Count > 0)
        {
            throw new InvalidOperationException(
                $"'{master.ParameterName}' cannot be deleted because it is mapped in {string.Join(", ", usedIn.Take(5))}" +
                (usedIn.Count > 5 ? $" and {usedIn.Count - 5} more" : "") +
                ". Untick it on Industry Parameter Mapping, or untick Active here to hide it.");
        }

        await repository.DeleteParameterMasterAsync(parameterDefinitionMasterId, ct);
    }
    // ------------------------------------------------------------ versions / workflow definition

    public async Task<IReadOnlyList<VersionDto>> GetVersionsAsync(string workflowCode, CancellationToken ct = default) =>
        (await repository.GetWorkflowVersionsAsync(workflowCode, ct))
            .OrderByDescending(x => x.VersionNo)
            .Select(x => x.ToDto())
            .ToList();

    public async Task<VersionDto?> GetVersionAsync(
        string workflowCode,
        int versionNo,
        CancellationToken ct = default) =>
        (await repository.GetWorkflowVersionAsync(workflowCode, versionNo, ct))?.ToDto();
    public async Task<FrameworkDto?> GetFrameworkAsync(
    int id,
    int? versionNo = null,
    CancellationToken ct = default)
    {
        var framework =
            await repository.GetFrameworkAsync(
                id,
                versionNo,
                ct);

        if (framework is null)
            return null;

        framework.JsonStatus = "Valid";
        framework.ValueSource =
        versionNo.HasValue
        ? $"Version Snapshot V{versionNo}"
        : "Framework Snapshot";

        return framework;
    }
    private static void ApplyVersionParameters(FrameworkDto framework, string? definitionJson)
    {
        if (string.IsNullOrWhiteSpace(definitionJson)) return;
        try
        {
            using var doc = JsonDocument.Parse(definitionJson);
            var root = doc.RootElement.ValueKind == JsonValueKind.Array
            ? doc.RootElement.EnumerateArray().FirstOrDefault()
            : doc.RootElement;
            if (root.ValueKind != JsonValueKind.Object || !root.TryGetProperty("Parameters", out var parameters) || parameters.ValueKind != JsonValueKind.Array) return;
            var definitions = JsonSerializer.Deserialize<List<WorkflowJsonParameterDto>>(parameters.GetRawText()) ?? [];
            var current = framework.Parameters.ToDictionary(x => x.ParameterCode, StringComparer.OrdinalIgnoreCase);
            var versionParameters = new List<ParameterDto>();
            foreach (var definition in definitions)
            {
                if (!current.TryGetValue(definition.ParameterCode, out var master)) continue;
                var scores = definition.Scores.Select(x => new ScoreDto(x.Score, x.Definition, x.ThresholdValue, x.Unit, x.MinValue, x.MaxValue, x.MinInclusive, x.MaxInclusive)).ToList();
                versionParameters.Add(new ParameterDto(master.Id, definition.ParameterCode, definition.ParameterName, definition.WhyItMatters, definition.HowDoWeMeasure, definition.Weight, definition.DisplayOrder, definition.IsValueDriven, scores));
            }
            framework.Parameters = versionParameters;
        }
        catch (JsonException)
        {
            /* Keep the existing parameter list if an old JSON schema cannot be parsed. */
        }
    }
    public async Task<CalculateScoreResponse?> CalculateScoreAsync(int parameterId, decimal? value, CancellationToken ct = default)
    {
        var parameter = await repository.GetParameterAsync(parameterId, ct);
        if (parameter is null) return null;
        if (!parameter.IsValueDriven || value is null)
        {
            var first = parameter.Scores.OrderByScore(x => x.Score).FirstOrDefault();
            return first is null ? null : new CalculateScoreResponse(parameter.Id, (int)ScoreValues.ToNumber(first.Score), first.Definition);
        }
        var match = parameter.Scores
        .Where(x => (!x.MinValue.HasValue || (x.MinInclusive ? value.Value >= x.MinValue.Value : value.Value > x.MinValue.Value))
        && (!x.MaxValue.HasValue || (x.MaxInclusive ? value.Value <= x.MaxValue.Value : value.Value < x.MaxValue.Value)))
        .OrderByScore(x => x.Score)
        .FirstOrDefault();
        return match is null ? null : new CalculateScoreResponse(parameter.Id, (int)ScoreValues.ToNumber(match.Score), match.Definition);
    }
    public async Task<FrameworkDto> SaveFrameworkAsync(FrameworkDto framework, CancellationToken ct = default)
    {
        // Score using the selected version's score definitions, not the latest master scores.
        var parameterMap = framework.Parameters.ToDictionary(x => x.Id);
        var updatedValues = new List<FrameworkParameterDto>();

        foreach (var item in framework.ParameterValues)
        {
            if (!parameterMap.TryGetValue(item.ParameterId, out var definition)
                || !definition.IsValueDriven
                || !item.Value.HasValue)
            {
                updatedValues.Add(item);
                continue;
            }

            var validations =
                await GetValidationsAsync(
                    item.ParameterId,
                    ct);

            foreach (var validation in validations)
            {
                switch (validation.ValidationType)
                {
                    case "Required":

                        if (!item.Value.HasValue)
                        {
                            throw new InvalidOperationException(
                                validation.ErrorMessage);
                        }

                        break;

                    case "PositiveNumber":

                        if (item.Value < 0)
                        {
                            throw new InvalidOperationException(
                                validation.ErrorMessage);
                        }

                        break;

                    case "Percentage":

                        if (item.Value < 0 ||
                            item.Value > 100)
                        {
                            throw new InvalidOperationException(
                                validation.ErrorMessage);
                        }

                        break;
                }
            }

            var match = definition.Scores
                .Where(x =>
                    (!x.MinValue.HasValue ||
                     (x.MinInclusive
                         ? item.Value.Value >= x.MinValue.Value
                         : item.Value.Value > x.MinValue.Value))
                    &&
                    (!x.MaxValue.HasValue ||
                     (x.MaxInclusive
                         ? item.Value.Value <= x.MaxValue.Value
                         : item.Value.Value < x.MaxValue.Value)))
                .OrderByScore(x => x.Score)
                .FirstOrDefault();

            updatedValues.Add(
                match is null
                    ? new FrameworkParameterDto(
                        item.ParameterId,
                        item.ParameterName,
                        item.Weight,
                        item.Value,
                        0)
                    : new FrameworkParameterDto(
                        item.ParameterId,
                        item.ParameterName,
                        item.Weight,
                        item.Value,
                        (int)ScoreValues.ToNumber(match.Score)));
        }

        framework.ParameterValues = updatedValues;

        var saved = await repository.SaveFrameworkAsync(framework, ct);
        // Repository relational rows represent the framework's default version. Preserve the
        // user's selected-version payload here so the version-specific JSON snapshot gets the
        // values they just saved, even when an older version was selected.
        saved.WorkflowVersionNo = framework.WorkflowVersionNo;
        saved.ParameterValues = framework.ParameterValues.ToList();
        saved.Parameters = framework.Parameters.ToList();
        var hasValues = saved.ParameterValues.Any(x => x.Value.HasValue || x.Score != 0);
        // Save even an all-blank value set. Otherwise a previous snapshot for this version could
        // reappear when the user retrieves it later.
        var valueJson = BuildValueJson(saved);
        await repository.SaveFrameworkValueJsonAsync(saved.Id, saved.WorkflowVersionNo, valueJson, ct);
        jsonProvider.InvalidateValue(saved.Id);
        saved.ValueSource = hasValues ? "Versioned JSON Snapshot" : "Versioned JSON Snapshot (blank values)";
        saved.JsonStatus = "Valid";
        return saved;
    }
    public async Task<VersionDto> SaveVersionAsync(SaveVersionRequest request, CancellationToken ct = default)
    {
        var versions = await repository.GetWorkflowVersionsAsync(request.WorkflowCode, ct);
        var latest = versions.MaxBy(x => x.VersionNo)
                     ?? throw new InvalidOperationException("Workflow not found.");

        var version = new WorkflowJsonVersion
        {
            IndustryDetailsId = latest.IndustryDetailsId,
            WorkflowCode = request.WorkflowCode,
            WorkflowName = latest.WorkflowName,
            VersionNo = request.VersionNo > 0 ? request.VersionNo : latest.VersionNo + 1,
            VersionName = request.VersionName,
            Status = request.Status,
            JsonContent = request.JsonContent,
            IsPublished = request.IsPublished
        };

        await repository.AddWorkflowVersionAsync(version, ct);
        jsonProvider.InvalidateDefinition(request.WorkflowCode, version.VersionNo);
        return version.ToDto();
    }

    // the latest version's definition, with the framework rules stored in the database
    public async Task<WorkflowDefinitionDto?> GetWorkflowDefinitionAsync(string workflowCode, CancellationToken ct = default)
    {
        var version = (await repository.GetWorkflowVersionsAsync(workflowCode, ct)).MaxBy(x => x.VersionNo);
        if (version is null)
            return null;

        var definition = WorkflowDefinitionJson.Parse(version.JsonContent, version.WorkflowName);
        definition.WorkflowName = version.WorkflowName;

        var databaseRules = await repository.GetFrameworkRulesAsync(version.WorkflowJsonVersionId, ct);
        foreach (var definitionRule in definition.Rules)
        {
            var databaseRule = databaseRules.FirstOrDefault(x => x.RuleName == definitionRule.RuleName);
            if (databaseRule is null)
                continue;

            definitionRule.RuleExpressionType = databaseRule.RuleExpressionType;
            definitionRule.OutputExpression = databaseRule.OutputExpression;
        }

        return definition;
    }

    // new version of a workflow: copies the newest configured version, then applies the definition
    public async Task<VersionDto> SaveWorkflowDefinitionAsync(SaveWorkflowDefinitionRequest request, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(request.WorkflowCode))
            throw new InvalidOperationException("Workflow code is required.");

        var weight = request.Definition.Parameters.Sum(x => x.Weight);
        if (request.Definition.Parameters.Count > 0 && weight <= 0)
            throw new InvalidOperationException("Parameter weights must be greater than zero.");

        request.VersionName = string.IsNullOrWhiteSpace(request.VersionName)
            ? $"{DateTime.Today:dd-MMM-yyyy} - Draft"
            : request.VersionName.Trim();

        await using var transaction = await repository.BeginTransactionAsync(ct);

        var versions = (await repository.GetWorkflowVersionsAsync(request.WorkflowCode, ct))
            .OrderByDescending(x => x.VersionNo)
            .ToList();
        var latest = versions.FirstOrDefault()
                     ?? throw new InvalidOperationException("Workflow not found.");

        // Do not blindly copy the highest version: a newer Draft may be empty. Use the newest
        // version that has parameters or active mappings.
        var sourceVersion = latest;
        WorkflowDefinitionDto? sourceDefinition = null;
        foreach (var candidate in versions)
        {
            var candidateDefinition = WorkflowDefinitionJson.Parse(candidate.JsonContent, candidate.WorkflowName);
            var hasMappings = (await repository.GetIndustryParameterMappingsAsync(
                    candidate.WorkflowJsonVersionId, candidate.IndustryDetailsId, ct))
                .Any(x => x.IsActive);

            if (candidateDefinition.Parameters.Count > 0 || hasMappings)
            {
                sourceVersion = candidate;
                sourceDefinition = candidateDefinition;
                break;
            }
        }

        sourceDefinition ??= WorkflowDefinitionJson.Parse(sourceVersion.JsonContent, sourceVersion.WorkflowName);

        // a blank definition copies the newest configured one (that version is never changed)
        if (request.Definition.Parameters.Count == 0 &&
            request.Definition.Rules.Count == 0 &&
            request.Definition.Validations.Count == 0)
        {
            request.Definition = sourceDefinition;
        }

        var json = WorkflowDefinitionJson.Serialize(request.Definition);

        // archive the published versions when this one is published
        if (request.IsPublished ||
            string.Equals(request.Status, "Published", StringComparison.OrdinalIgnoreCase))
        {
            var published = versions.Where(x => x.IsPublished || x.Status == "Published").ToList();
            foreach (var oldVersion in published)
            {
                oldVersion.Status = "Archieve";
                oldVersion.IsPublished = false;
            }

            await repository.UpdateWorkflowVersionsAsync(published, ct);
        }

        var version = new WorkflowJsonVersion
        {
            IndustryDetailsId = latest.IndustryDetailsId,
            WorkflowCode = latest.WorkflowCode,
            WorkflowName = string.IsNullOrWhiteSpace(request.Definition.WorkflowName)
                ? latest.WorkflowName
                : request.Definition.WorkflowName,
            VersionNo = latest.VersionNo + 1,
            VersionName = request.VersionName,
            Status = request.IsPublished ? "Published" : "Draft",
            JsonContent = json,
            IsPublished = request.IsPublished
        };
        await repository.AddWorkflowVersionAsync(version, ct);

        // mappings, score rows, popup fields and popup rules of the source version
        await repository.CopyVersionConfigurationAsync(
            sourceVersion.WorkflowJsonVersionId, version.WorkflowJsonVersionId, version.IndustryDetailsId, ct);

        await ApplyDefinitionParametersAsync(version, request.Definition, ct);

        // framework rules of the definition
        await repository.AddRuleDefinitionsAsync(
            request.Definition.Rules
                .Select(r => new RuleDefinition
                {
                    WorkflowJsonVersionId = version.WorkflowJsonVersionId,
                    RuleName = r.RuleName,
                    RuleExpressionType = r.RuleExpressionType,
                    OutputExpression = r.OutputExpression,
                    IsActive = true
                })
                .ToList(),
            ct);

        // validations of the definition are kept on the first mapping of the version
        var firstMapping = (await repository.GetIndustryParameterMappingsAsync(
            version.WorkflowJsonVersionId, version.IndustryDetailsId, ct)).FirstOrDefault();
        if (firstMapping is not null && request.Definition.Validations.Count > 0)
        {
            var existing = await repository.GetValidationsAsync(firstMapping.IndustryParameterMappingId, ct);
            var added = request.Definition.Validations.Select(x => new ValidationDefinition
            {
                ValidationName = x.ValidationName,
                Expression = x.Expression,
                ErrorMessage = x.ErrorMessage,
                IsActive = true
            });

            await repository.ReplaceValidationsAsync(firstMapping.IndustryParameterMappingId, existing.Concat(added).ToList(), ct);
        }

        // the Draft's JSON follows the final mapping / score / rule state
        await SyncDraftJsonFromMappingsAsync(version.WorkflowJsonVersionId, version.IndustryDetailsId, ct);

        await transaction.CommitAsync(ct);

        jsonProvider.SetDefinitionJson(request.WorkflowCode, version.VersionNo, json);
        return version.ToDto();
    }

    // parameters of a definition: master, mapping and (when it has none yet) scores
    private async Task ApplyDefinitionParametersAsync(
        WorkflowJsonVersion version,
        WorkflowDefinitionDto definition,
        CancellationToken ct)
    {
        foreach (var p in definition.Parameters)
        {
            var parameterCode = p.ParameterCode?.Trim() ?? string.Empty;
            if (string.IsNullOrWhiteSpace(parameterCode))
                continue;

            var master = await repository.GetParameterMasterByCodeAsync(parameterCode, ct);
            if (master is null)
            {
                master = new ParameterDefinitionMaster
                {
                    ParameterCode = parameterCode,
                    ParameterName = p.ParameterName,
                    WhyItMatters = p.WhyItMatters,
                    IsActive = true
                };
                await repository.SaveParameterMasterAsync(master, ct);
            }

            var map = (await repository.GetIndustryParameterMappingsAsync(
                    version.WorkflowJsonVersionId, version.IndustryDetailsId, ct))
                .FirstOrDefault(x => x.ParameterDefinitionMasterId == master.ParameterDefinitionMasterId)
                ?? new IndustryParameterMapping
                {
                    WorkflowJsonVersionId = version.WorkflowJsonVersionId,
                    IndustryDetailsId = version.IndustryDetailsId,
                    ParameterDefinitionMasterId = master.ParameterDefinitionMasterId,
                    DisplayOrder = p.DisplayOrder > 0 ? p.DisplayOrder : 99
                };

            map.ParameterDisplayName = p.ParameterName;
            map.ValueType = p.IsValueDriven ? "Value" : "ManualScore";
            map.Weight = p.Weight;
            map.IsActive = true;

            // no parent changes: the links copied from the source version stay
            await repository.SaveIndustryParameterMappingsAsync([map], new Dictionary<int, int?>(), ct);

            if (p.Scores.Count == 0 || (await repository.GetScaleDetailsAsync(map.IndustryParameterMappingId, ct)).Count > 0)
                continue;

            var scaleCode = $"{p.ParameterCode}_SCALE";
            var scale = await repository.GetScaleByCodeAsync(scaleCode, ct)
                        ?? new ScaleConfiguration
                        {
                            ScaleCode = scaleCode,
                            ScaleName = $"{p.ParameterName} scale",
                            MinValue = p.Scores.Min(x => x.MinValue ?? 0),
                            MaxValue = p.Scores.Max(x => x.MaxValue ?? 5),
                            IsActive = true
                        };

            var details = p.Scores
                .Select(s => new ScaleConfigurationDetails
                {
                    IndustryParameterMappingId = map.IndustryParameterMappingId,
                    ScoreValue = ScoreValues.Display(s.Score),
                    Definition = s.Definition,
                    MinValue = s.MinValue ?? scale.MinValue,
                    MaxValue = s.MaxValue ?? scale.MaxValue
                })
                .ToList();

            await repository.SaveScoreConfigurationAsync(map.IndustryParameterMappingId, scale, details, ct);
        }
    }

    // the stored definition of one version (JSON-only parts such as GlobalParams / Steps included)
    private async Task<WorkflowDefinitionDto?> BuildWorkflowDefinitionAsync(
        string workflowCode,
        int versionNo,
        CancellationToken ct)
    {
        var version = await repository.GetWorkflowVersionAsync(workflowCode, versionNo, ct);
        if (version is null)
            return null;

        var definition = WorkflowDefinitionJson.Parse(version.JsonContent, version.WorkflowName);
        definition.WorkflowName = version.WorkflowName;
        return definition;
    }

    // rewrites the Draft's JSON from its active mappings: parameters, weights, scores, rules, validations
    private async Task SyncDraftJsonFromMappingsAsync(
        int workflowJsonVersionId,
        int industryId,
        CancellationToken ct)
    {
        var version = await repository.GetWorkflowVersionByIdAsync(workflowJsonVersionId, ct)
                      ?? throw new InvalidOperationException("Workflow version not found.");

        if (version.IndustryDetailsId != industryId)
            throw new InvalidOperationException("The selected industry does not match this workflow version.");

        if (version.IsPublished ||
            !version.Status.Equals("Draft", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"Version V{version.VersionNo} is read-only. Create a Draft before changing its configuration.");

        var definition = WorkflowDefinitionJson.Parse(version.JsonContent, version.WorkflowName);

        var mappings = (await repository.GetIndustryParameterMappingsAsync(workflowJsonVersionId, industryId, ct))
            .Where(x => x.IsActive)
            .OrderBy(x => x.DisplayOrder)
            .ToList();
        var mappingIds = mappings.Select(x => x.IndustryParameterMappingId).ToList();

        var masters = (await repository.GetParameterMastersAsync(ct))
            .Where(x => x.IsActive)
            .ToDictionary(x => x.ParameterDefinitionMasterId);

        var scaleDetails = await repository.GetScaleDetailsForMappingsAsync(mappingIds, ct);

        var existingByCode = definition.Parameters
            .Where(x => !string.IsNullOrWhiteSpace(x.ParameterCode))
            .GroupBy(x => x.ParameterCode, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(x => x.Key, x => x.First(), StringComparer.OrdinalIgnoreCase);

        var syncedParameters = new List<WorkflowJsonParameterDto>();
        foreach (var mapping in mappings)
        {
            if (!masters.TryGetValue(mapping.ParameterDefinitionMasterId, out var master))
                continue;

            existingByCode.TryGetValue(master.ParameterCode, out var parameter);
            parameter ??= new WorkflowJsonParameterDto
            {
                ParameterCode = master.ParameterCode,
                ParameterName = master.ParameterName,
                WhyItMatters = master.WhyItMatters,
                Scores = []
            };

            parameter.ParameterCode = master.ParameterCode;
            parameter.ParameterName = string.IsNullOrWhiteSpace(mapping.ParameterDisplayName)
                ? master.ParameterName : mapping.ParameterDisplayName;
            parameter.WhyItMatters = master.WhyItMatters;
            parameter.Weight = mapping.Weight;
            parameter.DisplayOrder = mapping.DisplayOrder > 0 ? mapping.DisplayOrder : 99;
            parameter.IsValueDriven = ParameterScoring.RequiresValueRanges(mapping.ValueType, mapping.ControlType);
            parameter.StepName = mapping.StepName;
            parameter.ControlType = mapping.ControlType;

            var scores = scaleDetails
                .Where(x => x.IndustryParameterMappingId == mapping.IndustryParameterMappingId)
                .OrderByScore();
            if (scores.Count > 0)
            {
                parameter.Scores = scores.Select(x => new WorkflowJsonScoreDto
                {
                    Score = ScoreValues.Display(x.ScoreValue),
                    Definition = x.Definition,
                    MinValue = x.MinValue,
                    MaxValue = x.MaxValue,
                    MinInclusive = true,
                    MaxInclusive = true
                }).ToList();
            }

            syncedParameters.Add(parameter);
        }

        definition.Parameters = syncedParameters;

        // weights of this version's active mappings
        definition.Weights = syncedParameters
            .Where(x => !string.IsNullOrWhiteSpace(x.ParameterCode))
            .GroupBy(x => x.ParameterCode, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First().Weight, StringComparer.OrdinalIgnoreCase);

        // framework rules only: popup score rules (e.g. Liquidity) are run by the popup calculation
        foreach (var rule in await repository.GetFrameworkRulesAsync(workflowJsonVersionId, ct))
        {
            var existingRule = definition.Rules.FirstOrDefault(x =>
                x.RuleName.Equals(rule.RuleName, StringComparison.OrdinalIgnoreCase));
            if (existingRule is null)
            {
                definition.Rules.Add(new WorkflowJsonRuleDto
                {
                    RuleName = rule.RuleName,
                    RuleExpressionType = rule.RuleExpressionType,
                    OutputExpression = rule.OutputExpression
                });
            }
            else
            {
                existingRule.RuleExpressionType = rule.RuleExpressionType;
                existingRule.OutputExpression = rule.OutputExpression;
            }
        }

        foreach (var validation in (await repository.GetValidationsForMappingsAsync(mappingIds, ct)).Where(x => x.IsActive))
        {
            if (!definition.Validations.Any(x => x.ValidationName.Equals(validation.ValidationName, StringComparison.OrdinalIgnoreCase)))
            {
                definition.Validations.Add(new WorkflowJsonValidationDto
                {
                    ValidationName = validation.ValidationName,
                    Expression = validation.Expression,
                    ErrorMessage = validation.ErrorMessage
                });
            }
        }

        version.JsonContent = WorkflowDefinitionJson.Serialize(definition);
        await repository.UpdateWorkflowVersionsAsync([version], ct);
    }
    private static string BuildValueJson(FrameworkDto framework)
    {
        var snapshot =
    new FrameworkValueSnapshotJson
    {
        FrameworkId =
            framework.Id,

        WorkflowCode =
            framework.WorkflowCode,

        WorkflowVersionNo =
            framework.WorkflowVersionNo,

        EntityId =
            framework.EntityId,

        EntityName =
            framework.EntityName,

        IndustrySegments =
            framework.IndustrySegments,

        Values =
            framework.ParameterValues
            .Select(x =>
                new FrameworkValueJsonItem
                {
                    ParameterId = x.ParameterId,

                    ParameterCode =
                        framework.Parameters
                            .FirstOrDefault(
                                p => p.Id ==
                                     x.ParameterId)
                            ?.ParameterCode ?? "",

                    ParameterName =
                        x.ParameterName,

                    Weight =
                        x.Weight,

                    Value =
                        x.Value,

                    Score =
                        x.Score
                })
            .ToList()
    };
        return JsonSerializer.Serialize(
            snapshot,
            new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            });

    }
    private static bool TryBuildValuesFromJson(
        FrameworkDto framework,
        string? definitionJson,
        string? valueJson,
        out List<FrameworkParameterDto> values,
        out string error)
    {
        values = [];
        error = string.Empty;
        if (string.IsNullOrWhiteSpace(definitionJson))
        {
            error = "definition JSON not found";
            return false;
        }
        if (string.IsNullOrWhiteSpace(valueJson))
        {
            error = "value JSON not found";
            return false;
        }
        try
        {
            var definitions = ParseDefinition(definitionJson);
            var snapshot = JsonSerializer.Deserialize<FrameworkValueSnapshotJson>(valueJson);
            if (snapshot is null)
            {
                error = "value JSON could not be parsed";
                return false;
            }
            if (!string.Equals(snapshot.WorkflowCode, framework.WorkflowCode, StringComparison.OrdinalIgnoreCase)
            || snapshot.FrameworkId != framework.Id
            || snapshot.WorkflowVersionNo != framework.WorkflowVersionNo)
            {
                error = "value JSON does not match the selected framework/version";
                return false;
            }
            var snapshotValues = snapshot.Values
            .Where(x => !string.IsNullOrWhiteSpace(x.ParameterCode)
            || !string.IsNullOrWhiteSpace(x.ParameterName)
            || x.ParameterId > 0)
            .ToList();
            // The parameter set may differ between versions. Match by stable code first,
            // then by legacy name/ID, and initialize newly introduced parameters as blank.
            foreach (var definition in definitions.Parameters)
            {
                var savedParameter = framework.Parameters.FirstOrDefault(p =>
                (!string.IsNullOrWhiteSpace(definition.ParameterCode)
                && p.ParameterCode.Equals(definition.ParameterCode, StringComparison.OrdinalIgnoreCase))
                || p.ParameterName.Equals(definition.ParameterName, StringComparison.OrdinalIgnoreCase));
                // Match by stable parameter code first. Names and database IDs are legacy
                // fallbacks only; OR-ing all keys together can select a different parameter
                // when definitions were reordered or renamed between versions.
                var item = snapshotValues.FirstOrDefault(x =>
                !string.IsNullOrWhiteSpace(definition.ParameterCode)
                && !string.IsNullOrWhiteSpace(x.ParameterCode)
                && x.ParameterCode.Equals(definition.ParameterCode, StringComparison.OrdinalIgnoreCase));
                item ??= snapshotValues.FirstOrDefault(x =>
                !string.IsNullOrWhiteSpace(x.ParameterName)
                && x.ParameterName.Equals(definition.ParameterName, StringComparison.OrdinalIgnoreCase));
                item ??= savedParameter is null
                ? null
                : snapshotValues.FirstOrDefault(x => x.ParameterId == savedParameter.Id);
                values.Add(new FrameworkParameterDto(
                savedParameter?.Id ?? definition.ParameterId,
                definition.ParameterName,
                definition.Weight,
                item?.Value,
                item?.Score ?? 0));
            }
            return true;
        }
        catch (JsonException ex)
        {
            values.Clear();
            error = ex.Message;
            return false;
        }
    }
    private static WorkflowDefinitionForCompare ParseDefinition(string json)
    {
        using var document = JsonDocument.Parse(json);
        var root = document.RootElement.ValueKind == JsonValueKind.Array
        ? document.RootElement.EnumerateArray().FirstOrDefault()
        : document.RootElement;
        var parameters = root.TryGetProperty("Parameters", out var parameterElement)
        ? parameterElement.Deserialize<List<ParameterForCompare>>() ?? []
        : [];
        return new WorkflowDefinitionForCompare(parameters);
    }

    // ------------------------------------------------------------ industry parameter mapping

    // one row per active parameter master, filled with its mapping in this version when there is one
    public async Task<IReadOnlyList<IndustryParameterMappingDto>>
    GetIndustryParameterMappingsAsync(
        string workflowCode,
        int versionNo,
        int industryId,
        CancellationToken ct = default)
    {
        var version = await repository.GetWorkflowVersionAsync(workflowCode, versionNo, ct);
        if (version is null)
            return [];

        var masters = (await repository.GetParameterMastersAsync(ct))
            .Where(x => x.IsActive)
            .OrderBy(x => x.ParameterName)
            .ToList();

        var mappings = await repository.GetIndustryParameterMappingsAsync(version.WorkflowJsonVersionId, industryId, ct);

        var scaleIds = await repository.GetScaleIdsAsync(
            mappings.Where(x => x.IsActive).Select(x => x.IndustryParameterMappingId).ToList(), ct);

        // order of the version JSON for masters without a saved order
        var definition = await BuildWorkflowDefinitionAsync(workflowCode, versionNo, ct);
        var jsonOrder = (definition?.Parameters ?? [])
            .Select((parameter, index) => new { parameter.ParameterCode, Order = parameter.DisplayOrder > 0 ? parameter.DisplayOrder : index + 1 })
            .GroupBy(x => x.ParameterCode, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First().Order, StringComparer.OrdinalIgnoreCase);

        return masters
            .Select(master =>
            {
                var mapping = mappings.FirstOrDefault(x => x.ParameterDefinitionMasterId == master.ParameterDefinitionMasterId);
                int? scaleId = mapping is not null && scaleIds.TryGetValue(mapping.IndustryParameterMappingId, out var id) ? id : null;
                int? order = jsonOrder.TryGetValue(master.ParameterCode, out var o) ? o : null;

                return master.ToDto(mapping, mappings, scaleId, order);
            })
            .ToList();
    }

    public async Task<bool> SaveIndustryParameterMappingsAsync(
    SaveIndustryParameterMappingsRequest request,
    CancellationToken ct = default)
    {
        // 1. Validate workflow
        if (string.IsNullOrWhiteSpace(request.WorkflowCode))
        {
            throw new InvalidOperationException(
                "Workflow code is required.");
        }

        // 2. Validate version
        if (request.VersionNo <= 0)
        {
            throw new InvalidOperationException(
                "Version number is required.");
        }

        // 3. Validate industry
        if (request.IndustryDetailsId <= 0)
        {
            throw new InvalidOperationException(
                "Industry is required.");
        }

        // 4. Validate mappings
        if (request.Mappings is null)
        {
            throw new InvalidOperationException(
                "Mappings are required.");
        }

        // 5. Get exact selected version
        var version = await repository.GetWorkflowVersionAsync(
            request.WorkflowCode,
            request.VersionNo,
            ct);

        if (version is null)
        {
            throw new InvalidOperationException(
                $"Workflow '{request.WorkflowCode}' " +
                $"V{request.VersionNo} was not found.");
        }

        // 6. The version must belong to the selected industry
        if (version.IndustryDetailsId != request.IndustryDetailsId)
        {
            throw new InvalidOperationException(
                "The selected industry does not match this workflow version.");
        }

        // 7. Only a Draft can be changed (published / archived versions are read-only)
        if (version.IsPublished ||
            !version.Status.Equals("Draft", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                $"Version V{request.VersionNo} is read-only. Create a Draft before changing its configuration.");
        }

        var selectedMappings = request.Mappings
            .Where(x => x.IsMapped)
            .ToList();

        // 8. At least one parameter
        if (selectedMappings.Count == 0)
        {
            throw new InvalidOperationException(
                "At least one parameter must be mapped.");
        }

        // 9. Check duplicate parameters
        var duplicateIds = selectedMappings
            .GroupBy(x => x.ParameterDefinitionMasterId)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();

        if (duplicateIds.Count > 0)
        {
            throw new InvalidOperationException(
                "The same parameter cannot be mapped more than once.");
        }

        // 10. Negative weights not allowed
        if (selectedMappings.Any(x => x.Weight < 0))
        {
            throw new InvalidOperationException(
                "Parameter weight cannot be negative.");
        }

        // 10b. Popups under a Module row (e.g. Liquidity -> Update Liquidity Details)
        foreach (var child in selectedMappings.Where(x => x.ParentParameterDefinitionMasterId is not null))
        {
            var parent = selectedMappings.FirstOrDefault(x =>
                x.ParameterDefinitionMasterId == child.ParentParameterDefinitionMasterId);

            if (parent is null || parent.ParentParameterDefinitionMasterId is not null)
            {
                throw new InvalidOperationException(
                    $"{child.ParameterDisplayName}: the parent must be a mapped parameter that has no parent itself.");
            }

            if (child.Weight != 0)
            {
                throw new InvalidOperationException(
                    $"{child.ParameterDisplayName} is a popup under {parent.ParameterDisplayName}: its weight must be 0 (the parent carries the weight).");
            }
        }

        var weightError = MappingWeightValidation.GetError(selectedMappings);
        if (weightError is not null)
        {
            throw new InvalidOperationException(weightError);
        }

        // 12. Fix missing display order
        var order = 1;

        foreach (var mapping in selectedMappings)
        {
            mapping.StepName = mapping.StepName.Trim();
            if (mapping.DisplayOrder <= 0)
            {
                mapping.DisplayOrder = order;
            }

            order++;
        }

        // 13. Grid rows -> mapping entities (existing ones updated, new ones added, unticked ones switched off)
        var existing = await repository.GetIndustryParameterMappingsAsync(
            version.WorkflowJsonVersionId, request.IndustryDetailsId, ct);

        var entities = new List<IndustryParameterMapping>();
        foreach (var row in request.Mappings)
        {
            var entity = existing.FirstOrDefault(x => x.ParameterDefinitionMasterId == row.ParameterDefinitionMasterId);

            if (!row.IsMapped)
            {
                if (entity is not null)
                {
                    entity.IsActive = false;
                    entities.Add(entity);
                }

                continue;
            }

            entity ??= new IndustryParameterMapping
            {
                WorkflowJsonVersionId = version.WorkflowJsonVersionId,
                IndustryDetailsId = request.IndustryDetailsId,
                ParameterDefinitionMasterId = row.ParameterDefinitionMasterId
            };

            row.ApplyTo(entity);
            entities.Add(entity);
        }

        // popup -> its module, by parameter master (a row cannot be its own parent)
        var parentMasterIds = selectedMappings.ToDictionary(
            x => x.ParameterDefinitionMasterId,
            x => x.ParentParameterDefinitionMasterId == x.ParameterDefinitionMasterId ? null : x.ParentParameterDefinitionMasterId);

        // 14. Persistence, then the Draft's JSON follows the mappings
        await repository.SaveIndustryParameterMappingsAsync(entities, parentMasterIds, ct);
        await SyncDraftJsonFromMappingsAsync(version.WorkflowJsonVersionId, request.IndustryDetailsId, ct);

        return true;
    }

    public async Task<VersionDto> PublishVersionAsync(
    string workflowCode,
    int versionNo,
    CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(workflowCode))
        {
            throw new InvalidOperationException(
                "Workflow code is required.");
        }

        if (versionNo <= 0)
        {
            throw new InvalidOperationException(
                "Version number is required.");
        }

        var version = await repository.GetWorkflowVersionAsync(
            workflowCode,
            versionNo,
            ct);

        if (version is null)
        {
            throw new InvalidOperationException(
                $"Workflow '{workflowCode}' V{versionNo} was not found.");
        }

        if (version.IsPublished ||
            version.Status.Equals(
                "Published",
                StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                $"Version V{versionNo} is already published.");
        }

        if (version.Status.Equals(
            "Archieve",
            StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                $"Archieve version V{versionNo} cannot be published.");
        }

        var mappings =
            await GetIndustryParameterMappingsAsync(
                workflowCode,
                versionNo,
                version.IndustryDetailsId,
                ct);

        var selectedMappings = mappings
            .Where(x => x.IsMapped)
            .ToList();

        if (selectedMappings.Count == 0)
        {
            throw new InvalidOperationException(
                "Cannot publish this version because " +
                "no parameters are mapped.");
        }

        var weightError = MappingWeightValidation.GetError(selectedMappings);
        if (weightError is not null)
        {
            throw new InvalidOperationException(
                $"Cannot publish V{versionNo}. {weightError}");
        }

        foreach (var mapping in selectedMappings.Where(x =>
                     ParameterScoring.RequiresValueRanges(x.ValueType, x.ControlType) ||
                     ParameterScoring.IsModule(x.ControlType)))
        {
            var scoreConfiguration = await GetScoreConfigurationAsync(
                mapping.IndustryParameterMappingId, ct);
            if (ParameterScoring.IsModule(mapping.ControlType))
            {
                if (scoreConfiguration is null || scoreConfiguration.Scores.Count == 0)
                {
                    throw new InvalidOperationException(
                        $"Configure analyst score options for '{mapping.ParameterDisplayName}' in Score Configuration before publishing. " +
                        "Module scores come from popup formulas/rules; minimum/maximum value bands are not required.");
                }

                continue;
            }

            if (scoreConfiguration is null || scoreConfiguration.Scores.Count == 0 ||
                scoreConfiguration.Scores.Any(x => !x.MinValue.HasValue || !x.MaxValue.HasValue))
            {
                throw new InvalidOperationException(
                    $"Configure minimum/maximum value conditions and scores for '{mapping.ParameterDisplayName}' before publishing.");
            }
        }

        // ============================================================
        // FINAL DEFINITION -> JSON, PUBLISH, ARCHIVE THE OTHERS
        // ============================================================

        var definition = await BuildWorkflowDefinitionAsync(workflowCode, versionNo, ct)
                         ?? throw new InvalidOperationException(
                             $"Workflow definition for '{workflowCode}' V{versionNo} could not be generated.");

        var jsonContent = WorkflowDefinitionJson.Serialize(definition);

        // archive every other published version (old data may use Status and/or IsPublished)
        var others = (await repository.GetWorkflowVersionsAsync(workflowCode, ct))
            .Where(x => x.WorkflowJsonVersionId != version.WorkflowJsonVersionId &&
                        (x.IsPublished || x.Status == "Published"))
            .ToList();
        foreach (var oldVersion in others)
        {
            oldVersion.Status = "Archieve";
            oldVersion.IsPublished = false;
        }

        version.JsonContent = jsonContent;
        version.Status = "Published";
        version.IsPublished = true;

        // one save: the published version and the archived ones together
        await repository.UpdateWorkflowVersionsAsync([.. others, version], ct);

        // Keep JSON provider/cache synchronized.
        jsonProvider.SetDefinitionJson(workflowCode, versionNo, jsonContent);

        return version.ToDto();
    }

    public Task<IReadOnlyList<IndustrySegmentDto>>
    GetAllIndustriesAsync(
        CancellationToken ct = default)
    {
        return repository.GetAllIndustriesAsync(ct);
    }

    // ------------------------------------------------------------ score configuration

    public async Task<ScoreConfigurationDto?> GetScoreConfigurationAsync(
        int industryParameterMappingId,
        CancellationToken ct = default)
    {
        if (await repository.GetIndustryParameterMappingAsync(industryParameterMappingId, ct) is null)
            return null;

        var details = await repository.GetScaleDetailsAsync(industryParameterMappingId, ct);

        // all rows of a mapping belong to one scale
        var scale = details.Count > 0
            ? await repository.GetScaleAsync(details[0].ScaleConfigurationId, ct)
            : null;

        return ScoreConfigurationMappings.ToDto(industryParameterMappingId, scale, details);
    }

    public async Task SaveScoreConfigurationAsync(
        ScoreConfigurationDto request,
        CancellationToken ct = default)
    {
        var mapping = await repository.GetIndustryParameterMappingAsync(request.IndustryParameterMappingId, ct)
                      ?? throw new InvalidOperationException("Industry parameter mapping was not found.");

        var version = await repository.GetWorkflowVersionByIdAsync(mapping.WorkflowJsonVersionId, ct)
                      ?? throw new InvalidOperationException("Workflow version was not found.");

        // Published / Archived versions are immutable
        if (version.IsPublished ||
            version.Status.Equals("Published", StringComparison.OrdinalIgnoreCase) ||
            version.Status.Equals("Archived", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException($"Version V{version.VersionNo} is read-only.");
        }

        if (request.Scores is null || request.Scores.Count == 0)
            throw new InvalidOperationException("At least one score must be configured.");

        var requiresValueRanges = ParameterScoring.RequiresValueRanges(mapping.ValueType, mapping.ControlType);

        if (requiresValueRanges && request.Scores.Any(x => !x.MinValue.HasValue || !x.MaxValue.HasValue))
            throw new InvalidOperationException("Minimum and maximum values are required.");

        if (requiresValueRanges && request.Scores.Any(x => x.MinValue!.Value > x.MaxValue!.Value))
            throw new InvalidOperationException("Minimum value cannot be greater than maximum value.");

        if (request.Scores.Any(x => string.IsNullOrWhiteSpace(x.Score)))
            throw new InvalidOperationException("Enter a score (a number or a letter) for every row.");

        if (request.Scores.GroupBy(x => ScoreValues.Display(x.Score).ToUpperInvariant()).Any(x => x.Count() > 1))
            throw new InvalidOperationException("Duplicate score values are not allowed.");

        // the scale: the one of the request, else by code (unique), else a new one
        var scale = request.ScaleConfigurationId is int scaleId
            ? await repository.GetScaleAsync(scaleId, ct)
            : null;

        if (scale is null)
        {
            var scaleCode = request.ScaleCode.Trim();
            if (string.IsNullOrWhiteSpace(scaleCode))
                throw new InvalidOperationException("Scale code is required.");

            scale = await repository.GetScaleByCodeAsync(scaleCode, ct)
                    ?? new ScaleConfiguration { ScaleCode = scaleCode };
        }

        scale.ScaleName = request.ScaleName.Trim();
        scale.IsActive = true;
        if (requiresValueRanges)
        {
            scale.MinValue = request.Scores.Min(x => x.MinValue!.Value);
            scale.MaxValue = request.Scores.Max(x => x.MaxValue!.Value);
        }

        // the score editor has no description field: keep the Show Details texts
        var existing = await repository.GetScaleDetailsAsync(mapping.IndustryParameterMappingId, ct);
        var details = request.Scores
            .OrderByScore(x => x.Score)
            .Select(x => x.ToEntity(
                mapping.IndustryParameterMappingId,
                existing.FirstOrDefault(e => ScoreValues.Same(e.ScoreValue, x.Score))?.ScoreDescription))
            .ToList();

        await repository.SaveScoreConfigurationAsync(mapping.IndustryParameterMappingId, scale, details, ct);
        await SyncDraftJsonFromMappingsAsync(mapping.WorkflowJsonVersionId, mapping.IndustryDetailsId, ct);
    }

    // ------------------------------------------------------------ validations

    public async Task<List<ValidationDefinitionDto>> GetValidationsAsync(
        int industryParameterMappingId,
        CancellationToken ct = default)
    {
        return (await repository.GetValidationsAsync(industryParameterMappingId, ct))
            .Where(x => x.IsActive)
            .OrderBy(x => x.DisplayOrder)
            .Select(x => x.ToDto())
            .ToList();
    }

    public Task SaveValidationsAsync(
        int industryParameterMappingId,
        List<ValidationDefinitionDto> validations,
        CancellationToken ct = default)
    {
        var entities = validations
            .Select(x => x.ToEntity(industryParameterMappingId))
            .ToList();

        return repository.ReplaceValidationsAsync(industryParameterMappingId, entities, ct);
    }

    private record WorkflowDefinitionForCompare(List<ParameterForCompare> Parameters);
    private class ParameterForCompare
    {
        public int ParameterId { get; set; }
        public string ParameterCode { get; set; } = string.Empty;
        public string ParameterName { get; set; } = string.Empty;
        public decimal Weight { get; set; }
    }
    private class FrameworkValueSnapshotJson
    {
        public int FrameworkId { get; set; }

        public string WorkflowCode { get; set; } = string.Empty;

        public int WorkflowVersionNo { get; set; }

        public int EntityId { get; set; }

        public string EntityName { get; set; } = string.Empty;

        public List<BusinessParameterDetailsDto> IndustrySegments { get; set; } = [];

        public List<FrameworkValueJsonItem> Values { get; set; } = [];
    }

    private class FrameworkValueJsonItem
    {
        public int ParameterId { get; set; }
        public string ParameterCode { get; set; } = string.Empty;
        public string ParameterName { get; set; } = string.Empty;
        public decimal Weight { get; set; }
        public decimal? Value { get; set; }
        public int Score { get; set; }
    }

}