﻿namespace CRISP.Domain.Entities;
// one calculated value of the Output tab for one assessment (kept as it was when submitted)
public class FrameworkOutputDetails
{
    public int FrameworkOutputDetailsId { get; set; }
    public int AssessmentResponseId { get; set; }
    public int IndustryParameterMappingId { get; set; }
    // score, notches or rating order
    public decimal? ValueNumber { get; set; }
    // rating code, e.g. "AA-"
    public string? ValueText { get; set; }
    // second scenario: only projected years (financial risk rows)
    public decimal? ValueNumberProj { get; set; }
    public string? ValueTextProj { get; set; }
    public DateTime CalculatedOn { get; set; }
    public string CalculatedBy { get; set; } = string.Empty;
}
// CRISP.Domain/Entities/RatingMatrix.cs (chapter 14B)
// one cell of a rating matrix (OPERATING_WEIGHT, BASE_WEIGHT, DIVERSIFICATION, ...) of a version
public class RatingMatrix
{
    public int RatingMatrixId { get; set; }
    public int WorkflowJsonVersionId { get; set; }
    public string MatrixCode { get; set; } = string.Empty;
    public string RowValue { get; set; } = string.Empty;
    public string ColumnValue { get; set; } = string.Empty;
    public decimal Value { get; set; }
}
// one band of a rating band set (SCORE6, RATING16, ANCHOR_RANGE): MinValue <= value < MaxValue
public class RatingBand
{
    public int RatingBandId { get; set; }
    public int WorkflowJsonVersionId { get; set; }
    public string BandCode { get; set; } = string.Empty;
    public string BandValue { get; set; } = string.Empty;
    public decimal MinValue { get; set; }
    public decimal MaxValue { get; set; }
}
// CRISP.Domain/Entities/RatingScale.cs: add
   