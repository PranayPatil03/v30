﻿namespace CRISP.Domain.Entities;

// years of a framework as the old screen names them: Past2, Past1, Current, Proj1, Proj2 ...
public static class FinancialPastProjYearsTypes
{
    public sealed record Year(string YearType, int FiscalYear);

    // noOfPastYears includes the latest audited year (Current)
    public static List<Year> Build(int latestFinancialYear, int noOfPastYears, int noOfProjectedYears)
    {
        var years = new List<Year>();

        for (var past = noOfPastYears - 1; past >= 0; past--)
            years.Add(past == 0
                ? new Year("Current", latestFinancialYear)
                : new Year($"Past{past}", latestFinancialYear - past));

        for (var proj = 1; proj <= noOfProjectedYears; proj++)
            years.Add(new Year($"Proj{proj}", latestFinancialYear + proj));

        return years;
    }
}