﻿namespace CRISP.Domain.Entities;

public sealed class ParameterFieldDefinition
{
    public int ParameterFieldDefinitionId { get; set; }

    public int IndustryParameterMappingId { get; set; }

    public string FieldName { get; set; } = string.Empty;

    public string FieldType { get; set; } = string.Empty;

    public int DisplayOrder { get; set; }

    public bool IsRequired { get; set; }

    public bool IsActive { get; set; }

    // name used in formulas and rules, e.g. CFO
    public string? FieldCode { get; set; }

    // table on the popup; "Hidden" = calculated but not shown
    public string? SectionName { get; set; }

    public bool IsYearWise { get; set; }

    // Input | Spread | Formula | Rule | Heading
    public string SourceType { get; set; } = FieldSourceTypes.Input;

    // Spread: row positions (or template codes) to sum, sign and year offset
    public string? SpreadRows { get; set; }
    public bool SpreadByTemplate { get; set; }
    public short SpreadSign { get; set; } = 1;
    public int SpreadYearOffset { get; set; }

    // Formula: RulesEngine expression over other field codes
    public string? Formula { get; set; }

    public string? DefaultValue { get; set; }

    // analyst may replace the calculated value
    public bool IsOverridable { get; set; }

    public string? OptionsJson { get; set; }

    // waterfall chart: 1 add, -1 subtract, 0 total
    public short? ChartSign { get; set; }

    // Score | ParentScore | MinScore
    public string? ResultRole { get; set; }

    // (i) icon tooltip next to the label
    public string? HelpText { get; set; }

    // show the field only when another field has a value, e.g. CL_EXISTS=Yes
    public string? ShowWhen { get; set; }

    public IndustryParameterMapping? IndustryParameterMapping { get; set; }
}

public static class FieldSourceTypes
{
    public const string Input = "Input";
    public const string Spread = "Spread";
    public const string Formula = "Formula";
    public const string Rule = "Rule";

    // rows without a value
    public const string Heading = "Heading";   // group heading inside a table
    public const string Note = "Note";         // text under a table (FieldName = the text)
    public const string Spacer = "Spacer";     // empty row

    public static bool HasValue(string? sourceType) =>
        sourceType is not (Heading or Note or Spacer);
}

public static class FieldResultRoles
{
    public const string Score = "Score";
    public const string ParentScore = "ParentScore";
    public const string MinScore = "MinScore";
}