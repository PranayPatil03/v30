namespace CRISP.Domain.Entities;

public class ScaleConfigurationDetails
{
    public int ScaleConfigurationDetailsId
    {
        get;
        set;
    }
    public int IndustryParameterMappingId
    {
        get;
        set;
    }
    public int ScaleConfigurationId
    {
        get;
        set;
    }
    // VARCHAR(256); read it as a number with ScoreValues.ToNumber
    public string ScoreValue
    {
        get;
        set;
    }
    = "";
    public string Definition
    {
        get;
        set;
    }
    = "";
    // long text of the score in the "Show Details" assessment table (HTML)
    public string? ScoreDescription
    {
        get;
        set;
    }
    public decimal MinValue
    {
        get;
        set;
    }
    public decimal MaxValue
    {
        get;
        set;
    }
}