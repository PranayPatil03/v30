﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Domain.Entities
{
    public sealed class FrameworkParameterResponse
    {
        public int FrameworkParameterResponseId { get; set; }
        public int AssessmentResponseId { get; set; }
        public int IndustryParameterMappingId { get; set; }
        public int ParameterFieldDefinitionId { get; set; }
        public string? FieldValue { get; set; }
        // null for single-value fields
        public int? FinancialYear { get; set; }
        // analyst replaced the calculated value
        public bool IsOverridden { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public AssessmentResponse? AssessmentResponse { get; set; }
        public IndustryParameterMapping? IndustryParameterMapping { get; set; }
        public ParameterFieldDefinition? ParameterFieldDefinition { get; set; }
    }
}
