﻿using System.Globalization;

namespace CRISP.Domain.Entities;

// ScaleConfigurationDetails.ScoreValue is stored as text (VARCHAR); scores are numbers everywhere else
public static class ScoreValues
{
    public static decimal ToNumber(string? value) =>
        decimal.TryParse(value?.Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out var number)
            ? number
            : 0m;

    public static string ToText(decimal value) =>
        value.ToString("0.##", CultureInfo.InvariantCulture);

    // "5.00" -> "5"; text that is not a number is shown as it is
    public static string Display(string? value) =>
        decimal.TryParse(value?.Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out var number)
            ? ToText(number)
            : value?.Trim() ?? string.Empty;

    public static bool SameScore(string? value, decimal score) =>
        ToNumber(value) == score;

    // the same score, ignoring case, spaces and "5" vs "5.00"
    public static bool Same(string? left, string? right) =>
        string.Equals(Display(left), Display(right), StringComparison.OrdinalIgnoreCase);

    // numbers first in numeric order ("10" after "9"), then letters A-Z; a VARCHAR ORDER BY does not give this
    public static IOrderedEnumerable<T> OrderByScore<T>(this IEnumerable<T> items, Func<T, string?> score) =>
        items
            .OrderBy(x => IsNumber(score(x)) ? 0 : 1)
            .ThenBy(x => ToNumber(score(x)))
            .ThenBy(x => score(x)?.Trim(), StringComparer.OrdinalIgnoreCase);

    public static List<ScaleConfigurationDetails> OrderByScore(this IEnumerable<ScaleConfigurationDetails> details) =>
        details.OrderByScore(x => x.ScoreValue).ToList();

    public static bool IsNumber(string? value) =>
        decimal.TryParse(value?.Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out _);
}