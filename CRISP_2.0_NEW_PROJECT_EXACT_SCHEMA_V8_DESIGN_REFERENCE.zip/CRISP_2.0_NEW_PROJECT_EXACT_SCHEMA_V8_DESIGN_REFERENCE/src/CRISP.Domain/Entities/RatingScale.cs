﻿namespace CRISP.Domain.Entities;

// ratings for the "Select rating" drop-downs (Parent/Group tab)
public class RatingScale
{
    public int RatingScaleId { get; set; }

    public string RatingCode { get; set; } = string.Empty;

    // 1 = strongest (AAA); used to count notches
    public int DisplayOrder { get; set; }

    public bool IsActive { get; set; } = true;

    public int? PgScore { get; set; }          // 19 = AAA ... 1 = C-; null for D
    public decimal? PgWeight { get; set; }
    public decimal? Year1Weight { get; set; }
}