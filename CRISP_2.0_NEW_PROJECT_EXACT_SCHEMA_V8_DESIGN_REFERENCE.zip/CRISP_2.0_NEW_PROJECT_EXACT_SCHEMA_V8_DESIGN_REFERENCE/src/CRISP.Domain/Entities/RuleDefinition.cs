namespace CRISP.Domain.Entities;

public sealed class RuleDefinition
{
    public int RuleDefinitionId
    {
        get;
        set;
    }
    public int WorkflowJsonVersionId
    {
        get;
        set;
    }
    // null = framework rule (version JSON); set = score rule of that popup (e.g. Liquidity)
    public int? IndustryParameterMappingId
    {
        get;
        set;
    }
    public string RuleName
    {
        get;
        set;
    }
    = "";
    public string RuleExpressionType
    {
        get;
        set;
    }
    = "LambdaExpression";
    // condition of the rule; null = always true
    public string? Expression
    {
        get;
        set;
    }
    public string OutputExpression
    {
        get;
        set;
    }
    = "0";
    // popup score rules: the first matching rule (lowest order) wins
    public int DisplayOrder
    {
        get;
        set;
    }
    public bool IsActive
    {
        get;
        set;
    }
    = true;
}