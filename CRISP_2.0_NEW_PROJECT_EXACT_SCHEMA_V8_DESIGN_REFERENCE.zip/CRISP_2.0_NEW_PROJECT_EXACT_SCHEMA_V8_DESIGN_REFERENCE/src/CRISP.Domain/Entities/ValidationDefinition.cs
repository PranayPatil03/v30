namespace CRISP.Domain.Entities;

public sealed class ValidationDefinition
{
    public int ValidationDefinitionId { get; set; }

    public int IndustryParameterMappingId { get; set; }

    public string ValidationName { get; set; } = "";

    public string Expression { get; set; } = "";

    public string ErrorMessage { get; set; } = "";

    public int DisplayOrder { get; set; }

    public bool IsActive { get; set; } = true;
}
