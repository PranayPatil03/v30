namespace CRISP.Domain.Entities;

public class IndustryParameterMapping
{
    public int IndustryParameterMappingId { get; set; }
    public int IndustryDetailsId { get; set; }
    public int WorkflowJsonVersionId { get; set; }
    public int ParameterDefinitionMasterId { get; set; }
    public int? ParentIndustryParameterMappingId { get; set; }
    public string ParameterDisplayName { get; set; } = "";
    public string ValueType { get; set; } = "ManualScore";
    public int DisplayOrder { get; set; } = 99;
    public decimal Weight { get; set; }
    public bool IsActive { get; set; } = true;

    public string? StepName { get; set; }
    public string? ControlType { get; set; }

    // popup year columns: first year = LatestFinancialYear + YearFromOffset
    public int? YearFromOffset { get; set; }
    public int? YearColumns { get; set; }

    // "Show Details" panel (HTML): description column and notes under the assessment table
    public string? DetailsDescription { get; set; }
    public string? DetailsNote { get; set; }

    // block of the tab the row is shown in, e.g. "Likelihood of Support" (Parent/Group tab)
    public string? SectionName { get; set; }

    // list of a Dropdown row: "RatingScale" or "YesNo"
    public string? OptionsSource { get; set; }

    public ICollection<ParameterFieldDefinition> ParameterFieldDefinitions { get; set; } = new List<ParameterFieldDefinition>();

}