﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Domain.Entities
{
    public class FrameworkGeneral
    {
        public int FrameworkGeneralId { get; set; }

        public int AssessmentResponseId { get; set; }

        public int EntityId { get; set; }

        public int WorkflowJsonVersionId { get; set; }

        public int? NoOfPastYears { get; set; }

        public int? NoOfProjectedYears { get; set; }

        public int? LatestFinancialYear { get; set; }

        public bool IsListed { get; set; }

        public bool IsParentSupported { get; set; }

        public string? ParentType { get; set; }

        public DateTime CreatedOn { get; set; }

        public DateTime? UpdatedOn { get; set; }

        public virtual AssessmentResponse? AssessmentResponse { get; set; }

        public virtual CustomerMaster? CustomerMaster { get; set; }

        public virtual WorkflowJsonVersion? WorkflowJsonVersion { get; set; }
    }
}
