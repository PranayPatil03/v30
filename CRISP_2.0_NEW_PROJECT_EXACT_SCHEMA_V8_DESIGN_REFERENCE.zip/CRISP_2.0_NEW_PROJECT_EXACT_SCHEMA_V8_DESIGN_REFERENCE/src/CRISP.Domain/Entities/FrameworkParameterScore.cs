﻿namespace CRISP.Domain.Entities;

// score of one parameter for one assessment (Others tab)
public class FrameworkParameterScore
{
    public int FrameworkParameterScoreId { get; set; }
    public int AssessmentResponseId { get; set; }
    public int IndustryParameterMappingId { get; set; }

    // from the rule engine, e.g. average liquidity score
    public decimal? CalculatedScore { get; set; }

    // analyst may choose this score or worse
    public decimal? MinAllowedScore { get; set; }

    // score selected on the Others tab
    public decimal? AnalystScore { get; set; }

    // text answer: provider name, selected rating, Yes/No (Parent/Group tab)
    public string? ValueText { get; set; }

    public DateTime UpdatedOn { get; set; }
}