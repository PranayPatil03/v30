﻿using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Domain.Entities;
using CRISP.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
namespace CRISP.Infrastructure.Repositories.CRF.Framework
{
    public class OutputRepository : IOutputRepository
    {
        private readonly CrispDbContext _db;
        public OutputRepository(CrispDbContext db) => _db = db;
        public Task<AssessmentResponse?> GetAssessmentAsync(int assessmentResponseId, CancellationToken ct = default) =>
            _db.AssessmentResponses.AsNoTracking()
               .Include(x => x.WorkflowJsonVersion)
               .FirstOrDefaultAsync(x => x.AssessmentResponseId == assessmentResponseId, ct);
        public Task<FrameworkGeneral?> GetGeneralAsync(int assessmentResponseId, CancellationToken ct = default) =>
            _db.FrameworkGenerals.AsNoTracking()
               .FirstOrDefaultAsync(x => x.AssessmentResponseId == assessmentResponseId, ct);
        public Task<int?> GetIndustryDetailsIdAsync(int workflowJsonVersionId, CancellationToken ct = default) =>
            _db.WorkflowJsonVersions.AsNoTracking()
               .Where(x => x.WorkflowJsonVersionId == workflowJsonVersionId)
               .Select(x => (int?)x.IndustryDetailsId)
               .FirstOrDefaultAsync(ct);
        public async Task<List<CodedRow>> GetRowsAsync(int workflowJsonVersionId, string stepName, CancellationToken ct =
default) =>
            (await (from m in _db.IndustryParameterMappings.AsNoTracking()
                    join p in _db.ParameterDefinitionMasters.AsNoTracking()
                        on m.ParameterDefinitionMasterId equals p.ParameterDefinitionMasterId
                    where m.WorkflowJsonVersionId == workflowJsonVersionId && m.StepName == stepName && m.IsActive
                    orderby m.DisplayOrder
                    select new { m, p.ParameterCode })
                .ToListAsync(ct))
            .Select(x => new CodedRow(x.m, x.ParameterCode))
            .ToList();
        public Task<List<FrameworkOutputDetails>> GetOutputAsync(int assessmentResponseId, CancellationToken ct = default)
=>
            _db.FrameworkOutputDetails.AsNoTracking()
               .Where(x => x.AssessmentResponseId == assessmentResponseId)
               .ToListAsync(ct);
        public async Task SaveOutputAsync(int assessmentResponseId, IReadOnlyList<FrameworkOutputDetails> rows,
CancellationToken ct = default)
        {
            await using var tx = await _db.Database.BeginTransactionAsync(ct);
            await _db.FrameworkOutputDetails
                .Where(x => x.AssessmentResponseId == assessmentResponseId)
                .ExecuteDeleteAsync(ct);
            _db.FrameworkOutputDetails.AddRange(rows);
            await _db.SaveChangesAsync(ct);
            await tx.CommitAsync(ct);
        }
        public Task<List<RatingMatrix>> GetRatingMatricesAsync(int workflowJsonVersionId, CancellationToken ct = default) =>
            _db.RatingMatrices.AsNoTracking()
               .Where(x => x.WorkflowJsonVersionId == workflowJsonVersionId)
               .ToListAsync(ct);
        public Task<List<RatingBand>> GetRatingBandsAsync(int workflowJsonVersionId, CancellationToken ct = default) =>
            _db.RatingBands.AsNoTracking()
               .Where(x => x.WorkflowJsonVersionId == workflowJsonVersionId)
               .ToListAsync(ct);
    }
}