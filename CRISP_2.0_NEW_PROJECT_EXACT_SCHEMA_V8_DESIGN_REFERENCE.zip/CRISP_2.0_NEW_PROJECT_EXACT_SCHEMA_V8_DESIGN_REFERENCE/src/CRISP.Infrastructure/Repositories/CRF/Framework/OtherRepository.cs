﻿using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Domain.Entities;
using CRISP.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Infrastructure.Repositories.CRF.Framework
{

    public class OtherRepository : IOtherRepository
    {
        private readonly CrispDbContext _db;
        public OtherRepository(CrispDbContext db)
        {
            _db = db;
        }

        public async Task<List<IndustryParameterMapping>> GetOthersAsync(int workflowJsonVersionId, string stepName, CancellationToken ct = default)
        {
            return await _db.IndustryParameterMappings
                .AsNoTracking()
                .Where(x => x.WorkflowJsonVersionId == workflowJsonVersionId
                && x.StepName == stepName && x.ParentIndustryParameterMappingId == null && x.IsActive)
                .OrderBy(x =>
                    x.DisplayOrder)
                .ToListAsync(ct);
        }

        public async Task<List<IndustryParameterMapping>> GetChildrenAsync(
                int parentIndustryParameterMappingId,
                CancellationToken ct = default)
        {
            return await _db.IndustryParameterMappings
                .AsNoTracking()
                .Where(x => x.ParentIndustryParameterMappingId == parentIndustryParameterMappingId &&
                    x.IsActive).OrderBy(x =>
                    x.DisplayOrder)
                .ToListAsync(ct);
        }

        public async Task<List<ParameterFieldDefinition>> GetFieldsAsync(int industryParameterMappingId, CancellationToken ct = default)
        {
            return await _db.ParameterFieldDefinitions
                .AsNoTracking()
                .Where(x => x.IndustryParameterMappingId == industryParameterMappingId && x.IsActive)
                .OrderBy(x => x.DisplayOrder)
                .ToListAsync(ct);
        }

        public async Task<List<FrameworkParameterResponse>>
            GetResponsesAsync(int assessmentResponseId, CancellationToken ct = default)
        {
            return await _db.FrameworkParameterResponses
                .AsNoTracking()
                .Where(x => x.AssessmentResponseId == assessmentResponseId)
                .ToListAsync(ct);
        }

        public async Task SaveResponsesAsync(
            List<FrameworkParameterResponse> responses, CancellationToken ct = default)
        {
            foreach (var response in responses)
            {
                var existing = await _db
                        .FrameworkParameterResponses
                        .FirstOrDefaultAsync(x => x.AssessmentResponseId == response.AssessmentResponseId
                            && x.ParameterFieldDefinitionId == response.ParameterFieldDefinitionId
                            && x.FinancialYear == response.FinancialYear, ct);

                if (existing == null)
                {
                    _db.FrameworkParameterResponses.Add(response);
                }
                else
                {
                    existing.FieldValue = response.FieldValue;

                    existing.IsOverridden = response.IsOverridden;

                    existing.UpdatedOn = DateTime.UtcNow;
                }
            }

            await _db.SaveChangesAsync(ct);
        }

        public async Task<IndustryParameterMapping?> GetMappingAsync(int industryParameterMappingId, CancellationToken ct = default)
        {
            return await _db.IndustryParameterMappings
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.IndustryParameterMappingId == industryParameterMappingId, ct);
        }

        public async Task<List<ParameterFieldDefinition>> GetVersionFieldsAsync(int workflowJsonVersionId, CancellationToken ct = default)
        {
            return await _db.ParameterFieldDefinitions
                .AsNoTracking()
                .Where(x => x.IsActive &&
                    x.IndustryParameterMapping != null &&
                    x.IndustryParameterMapping.WorkflowJsonVersionId == workflowJsonVersionId &&
                    x.IndustryParameterMapping.IsActive)
                .OrderBy(x => x.IndustryParameterMappingId)
                .ThenBy(x => x.DisplayOrder)
                .ToListAsync(ct);
        }

        public async Task<List<RuleDefinition>> GetRulesAsync(int industryParameterMappingId, CancellationToken ct = default)
        {
            return await _db.RuleDefinitions
                .AsNoTracking()
                .Where(x => x.IndustryParameterMappingId == industryParameterMappingId && x.IsActive)
                .OrderBy(x => x.DisplayOrder)
                .ThenBy(x => x.RuleDefinitionId)
                .ToListAsync(ct);
        }

        public async Task<List<ParameterDefinitionMaster>> GetMastersAsync(
            IReadOnlyCollection<int> parameterDefinitionMasterIds,
            CancellationToken ct = default)
        {
            return await _db.ParameterDefinitionMasters
                .AsNoTracking()
                .Where(x => parameterDefinitionMasterIds.Contains(x.ParameterDefinitionMasterId))
                .ToListAsync(ct);
        }

        public async Task<List<ScaleConfigurationDetails>> GetScaleDetailsAsync(
            IReadOnlyCollection<int> industryParameterMappingIds,
            CancellationToken ct = default)
        {
            var details = await _db.ScaleConfigurationDetails
                .AsNoTracking()
                .Where(x => industryParameterMappingIds.Contains(x.IndustryParameterMappingId))
                .ToListAsync(ct);

            return details.OrderByScore();
        }

        public async Task<List<FrameworkParameterScore>> GetScoresAsync(int assessmentResponseId, CancellationToken ct = default)
        {
            return await _db.FrameworkParameterScores
                .AsNoTracking()
                .Where(x => x.AssessmentResponseId == assessmentResponseId)
                .ToListAsync(ct);
        }

        public async Task SavePopupAsync(
            int assessmentResponseId,
            IReadOnlyCollection<int> fieldIds,
            List<FrameworkParameterResponse> responses,
            FrameworkParameterScore? calculatedScore,
            CancellationToken ct = default)
        {
            var existing = await _db.FrameworkParameterResponses
                .Where(x => x.AssessmentResponseId == assessmentResponseId &&
                    fieldIds.Contains(x.ParameterFieldDefinitionId))
                .ToListAsync(ct);

            foreach (var response in responses)
            {
                var row = existing.FirstOrDefault(x =>
                    x.ParameterFieldDefinitionId == response.ParameterFieldDefinitionId &&
                    x.FinancialYear == response.FinancialYear);

                if (row is null)
                {
                    response.CreatedOn = DateTime.UtcNow;
                    _db.FrameworkParameterResponses.Add(response);
                    continue;
                }

                row.FieldValue = response.FieldValue;
                row.IsOverridden = response.IsOverridden;
                row.UpdatedOn = DateTime.UtcNow;
                existing.Remove(row);
            }

            // years / fields no longer on the popup
            _db.FrameworkParameterResponses.RemoveRange(existing);

            if (calculatedScore is not null)
            {
                var score = await _db.FrameworkParameterScores
                    .FirstOrDefaultAsync(x => x.AssessmentResponseId == assessmentResponseId &&
                        x.IndustryParameterMappingId == calculatedScore.IndustryParameterMappingId, ct);

                if (score is null)
                {
                    calculatedScore.AssessmentResponseId = assessmentResponseId;
                    calculatedScore.UpdatedOn = DateTime.UtcNow;
                    _db.FrameworkParameterScores.Add(calculatedScore);
                }
                else
                {
                    score.CalculatedScore = calculatedScore.CalculatedScore;
                    score.MinAllowedScore = calculatedScore.MinAllowedScore;

                    // the analyst's score may not be better than the new calculated score
                    if (score.AnalystScore is decimal analyst &&
                        calculatedScore.MinAllowedScore is decimal min &&
                        analyst < min)
                    {
                        score.AnalystScore = null;
                    }

                    score.UpdatedOn = DateTime.UtcNow;
                }
            }

            // one transaction
            await _db.SaveChangesAsync(ct);
        }

        public async Task SaveAnalystScoresAsync(
            int assessmentResponseId,
            IReadOnlyDictionary<int, AnalystAnswer> answersByMappingId,
            CancellationToken ct = default)
        {
            var mappingIds = answersByMappingId.Keys.ToList();

            var existing = await _db.FrameworkParameterScores
                .Where(x => x.AssessmentResponseId == assessmentResponseId &&
                    mappingIds.Contains(x.IndustryParameterMappingId))
                .ToListAsync(ct);

            foreach (var (mappingId, answer) in answersByMappingId)
            {
                var row = existing.FirstOrDefault(x => x.IndustryParameterMappingId == mappingId);

                if (row is null)
                {
                    _db.FrameworkParameterScores.Add(new FrameworkParameterScore
                    {
                        AssessmentResponseId = assessmentResponseId,
                        IndustryParameterMappingId = mappingId,
                        AnalystScore = answer.Score,
                        ValueText = answer.ValueText,
                        UpdatedOn = DateTime.UtcNow
                    });
                    continue;
                }

                row.AnalystScore = answer.Score;
                row.ValueText = answer.ValueText;
                row.UpdatedOn = DateTime.UtcNow;
            }

            await _db.SaveChangesAsync(ct);
        }

        public async Task<List<RatingScale>> GetRatingScaleAsync(CancellationToken ct = default)
        {
            return await _db.RatingScales
                .AsNoTracking()
                .Where(x => x.IsActive)
                .OrderBy(x => x.DisplayOrder)
                .ToListAsync(ct);
        }

    }
}