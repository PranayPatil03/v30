﻿using System.Data;
using System.Data.Common;
using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Infrastructure.Persistence;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace CRISP.Infrastructure.Repositories.CRF.Framework
{
    /*
     * Reads the customer's spread (replaces the data part of GetLiquidityDetails).
     *
     * The spread is stored in one table per year: CustomerToSpreadRecordsYYYY.
     * For an audited year (SpreadRecordsVersion.SubType = 'Past') ACTUALVALUE is used,
     * otherwise ProjectedVALUE - same rule as the stored procedure.
     * The year is an int, so the table name is safe; the customer code is a parameter.
     *
     * The spread tables may live in another database on the same server
     * (appsettings "SpreadDatabase", e.g. "CRISP-DEV"); empty = the CRISP 2.0 database.
     */
    public sealed class SpreadRepository : ISpreadRepository
    {
        private readonly CrispDbContext _db;
        private readonly string _schema;

        public SpreadRepository(CrispDbContext db, IConfiguration configuration)
        {
            _db = db;

            var database = configuration["SpreadDatabase"];
            if (!string.IsNullOrWhiteSpace(database) &&
                !database.All(c => char.IsLetterOrDigit(c) || c is '_' or '-' or '.'))
            {
                throw new InvalidOperationException("SpreadDatabase setting contains invalid characters.");
            }

            _schema = string.IsNullOrWhiteSpace(database) ? "dbo." : $"[{database}].dbo.";
        }

        public async Task<string?> GetCustomerCodeAsync(int assessmentResponseId, CancellationToken ct = default)
        {
            return await (from a in _db.AssessmentResponses.AsNoTracking()
                          join c in _db.CustomerMasters.AsNoTracking() on a.EntityId equals c.EntityId
                          where a.AssessmentResponseId == assessmentResponseId
                          select c.CustomerCode)
                .FirstOrDefaultAsync(ct);
        }

        public async Task<bool> HasYearAsync(string customerCode, int year, CancellationToken ct = default)
        {
            var sql = $"""
                IF OBJECT_ID(N'{_schema}SpreadRecordsVersion', N'U') IS NULL
                    SELECT 0;
                ELSE
                    SELECT CASE WHEN EXISTS (SELECT 1 FROM {_schema}SpreadRecordsVersion
                                             WHERE CustomerCode = @code AND FiscalYear = @year)
                                THEN 1 ELSE 0 END;
                """;

            return await ExecuteAsync(sql, cmd =>
            {
                cmd.Parameters.Add(new SqlParameter("@code", customerCode));
                cmd.Parameters.Add(new SqlParameter("@year", year));
            }, async reader => await reader.ReadAsync(ct) && reader.GetInt32(0) == 1, ct);
        }

        public async Task<List<SpreadValue>> GetValuesAsync(
            string customerCode,
            IReadOnlyCollection<int> years,
            CancellationToken ct = default)
        {
            var result = new List<SpreadValue>();

            foreach (var year in years.Distinct())
            {
                var table = $"{_schema}CustomerToSpreadRecords{year}";

                var sql = $"""
                    IF OBJECT_ID(N'{table}', N'U') IS NULL RETURN;

                    DECLARE @past BIT = 0;
                    IF OBJECT_ID(N'{_schema}SpreadRecordsVersion', N'U') IS NOT NULL
                       AND EXISTS (SELECT 1 FROM {_schema}SpreadRecordsVersion
                                   WHERE CustomerCode = @code AND FiscalYear = @year AND SubType = 'Past')
                        SET @past = 1;

                    SELECT CAST(s.TemplateCode AS INT),
                           CAST(t.RowPosition AS INT),
                           CAST(t.SubCategoryCode AS INT),
                           CAST(COALESCE(TRY_CONVERT(DECIMAL(35, 4),
                                CASE WHEN @past = 1 THEN s.ACTUALVALUE ELSE s.ProjectedVALUE END), 0) AS DECIMAL(35, 4))
                    FROM {table} s
                    LEFT JOIN {_schema}SpreadMainTemplate t ON t.TemplateCode = s.TemplateCode
                    WHERE s.CustomerCode = @code;
                    """;

                var rows = await ExecuteAsync(sql, cmd =>
                {
                    cmd.Parameters.Add(new SqlParameter("@code", customerCode));
                    cmd.Parameters.Add(new SqlParameter("@year", year));
                }, async reader =>
                {
                    var list = new List<SpreadValue>();
                    while (await reader.ReadAsync(ct))
                    {
                        list.Add(new SpreadValue(
                            year,
                            reader.GetInt32(0),
                            reader.IsDBNull(1) ? null : reader.GetInt32(1),
                            reader.IsDBNull(2) ? null : reader.GetInt32(2),
                            reader.GetDecimal(3)));
                    }
                    return list;
                }, ct);

                result.AddRange(rows);
            }

            return result;
        }

        private async Task<T> ExecuteAsync<T>(
            string sql,
            Action<DbCommand> addParameters,
            Func<DbDataReader, Task<T>> read,
            CancellationToken ct)
        {
            var connection = _db.Database.GetDbConnection();
            var opened = false;

            if (connection.State != ConnectionState.Open)
            {
                await connection.OpenAsync(ct);
                opened = true;
            }

            try
            {
                await using var cmd = connection.CreateCommand();
                cmd.CommandText = sql;
                addParameters(cmd);

                await using var reader = await cmd.ExecuteReaderAsync(ct);
                return await read(reader);
            }
            finally
            {
                if (opened)
                    await connection.CloseAsync();
            }
        }
    }
}