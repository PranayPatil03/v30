﻿using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Domain.Entities;
using CRISP.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace CRISP.Infrastructure.Repositories.CRF.Framework
{
    public class ParameterConfigRepository : IParameterConfigRepository
    {
        private readonly CrispDbContext _db;
        public ParameterConfigRepository(CrispDbContext db)
        {
            _db = db;
        }

        public async Task<ParameterConfigSource?> GetAsync(int industryParameterMappingId, CancellationToken ct = default)
        {
            var mapping = await _db.IndustryParameterMappings
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.IndustryParameterMappingId == industryParameterMappingId, ct);

            if (mapping is null)
                return null;

            var version = await _db.WorkflowJsonVersions
                .AsNoTracking()
                .FirstAsync(x => x.WorkflowJsonVersionId == mapping.WorkflowJsonVersionId, ct);

            var parameterCode = await _db.ParameterDefinitionMasters
                .AsNoTracking()
                .Where(x => x.ParameterDefinitionMasterId == mapping.ParameterDefinitionMasterId)
                .Select(x => x.ParameterCode)
                .FirstOrDefaultAsync(ct) ?? string.Empty;

            var parentName = mapping.ParentIndustryParameterMappingId is int parentId
                ? await _db.IndustryParameterMappings
                    .AsNoTracking()
                    .Where(x => x.IndustryParameterMappingId == parentId)
                    .Select(x => x.ParameterDisplayName)
                    .FirstOrDefaultAsync(ct)
                : null;

            var fields = await _db.ParameterFieldDefinitions
                .AsNoTracking()
                .Where(x => x.IndustryParameterMappingId == industryParameterMappingId && x.IsActive)
                .OrderBy(x => x.DisplayOrder)
                .ToListAsync(ct);

            var rules = await _db.RuleDefinitions
                .AsNoTracking()
                .Where(x => x.IndustryParameterMappingId == industryParameterMappingId)
                .OrderBy(x => x.DisplayOrder)
                .ThenBy(x => x.RuleDefinitionId)
                .ToListAsync(ct);

            var scores = (await _db.ScaleConfigurationDetails
                .AsNoTracking()
                .Where(x => x.IndustryParameterMappingId == industryParameterMappingId)
                .ToListAsync(ct))
                .OrderByScore();

            var otherFields = await _db.ParameterFieldDefinitions
                .AsNoTracking()
                .Where(x => x.IsActive &&
                    x.IndustryParameterMappingId != industryParameterMappingId &&
                    x.IndustryParameterMapping != null &&
                    x.IndustryParameterMapping.IsActive &&
                    x.IndustryParameterMapping.WorkflowJsonVersionId == mapping.WorkflowJsonVersionId &&
                    x.IndustryParameterMapping.IndustryDetailsId == mapping.IndustryDetailsId)
                .ToListAsync(ct);

            var parent = mapping.ParentIndustryParameterMappingId is int pid
                ? await _db.IndustryParameterMappings.AsNoTracking().FirstOrDefaultAsync(x => x.IndustryParameterMappingId == pid, ct)
                : null;

            var parentScores = parent is null
                ? []
                : (await _db.ScaleConfigurationDetails
                    .AsNoTracking()
                    .Where(x => x.IndustryParameterMappingId == parent.IndustryParameterMappingId)
                    .ToListAsync(ct))
                    .OrderByScore();

            var children = await _db.IndustryParameterMappings
                .AsNoTracking()
                .Where(x => x.ParentIndustryParameterMappingId == industryParameterMappingId && x.IsActive)
                .OrderBy(x => x.DisplayOrder)
                .Select(x => new RelatedMapping(
                    x.IndustryParameterMappingId,
                    x.ParameterDisplayName,
                    x.ControlType,
                    _db.ParameterFieldDefinitions.Count(f => f.IndustryParameterMappingId == x.IndustryParameterMappingId && f.IsActive),
                    null))
                .ToListAsync(ct);

            return new ParameterConfigSource(mapping, version, parameterCode, parentName, fields, rules, scores, otherFields)
            {
                Parent = parent,
                ParentScores = parentScores,
                Children = children
            };
        }

        public async Task<List<RelatedMapping>> GetCopySourcesAsync(int industryParameterMappingId, CancellationToken ct = default)
        {
            var withRows = _db.ParameterFieldDefinitions
                .Where(f => f.IsActive && f.IndustryParameterMappingId != industryParameterMappingId)
                .GroupBy(f => f.IndustryParameterMappingId)
                .Select(g => new { MappingId = g.Key, Rows = g.Count() });

            var list = await (
                    from c in withRows
                    join m in _db.IndustryParameterMappings on c.MappingId equals m.IndustryParameterMappingId
                    join v in _db.WorkflowJsonVersions on m.WorkflowJsonVersionId equals v.WorkflowJsonVersionId
                    orderby m.ParameterDisplayName, v.WorkflowCode, v.VersionNo descending
                    select new { m.IndustryParameterMappingId, m.ParameterDisplayName, m.ControlType, c.Rows, v.WorkflowCode, v.VersionNo })
                .AsNoTracking()
                .ToListAsync(ct);

            return list
                .Select(x => new RelatedMapping(
                    x.IndustryParameterMappingId,
                    x.ParameterDisplayName,
                    x.ControlType,
                    x.Rows,
                    $"{x.ParameterDisplayName} – {x.WorkflowCode} V{x.VersionNo} ({x.Rows} rows)"))
                .ToList();
        }

        public async Task SaveAsync(
            int industryParameterMappingId,
            string? detailsDescription,
            string? detailsNote,
            List<ParameterFieldDefinition> fields,
            List<RuleDefinition> rules,
            IReadOnlyDictionary<int, string?> scoreDescriptions,
            CancellationToken ct = default)
        {
            var mapping = await _db.IndustryParameterMappings
                .FirstAsync(x => x.IndustryParameterMappingId == industryParameterMappingId, ct);

            mapping.DetailsDescription = detailsDescription;
            mapping.DetailsNote = detailsNote;

            // ------------------------------------------------ fields
            var existingFields = await _db.ParameterFieldDefinitions
                .Where(x => x.IndustryParameterMappingId == industryParameterMappingId)
                .ToListAsync(ct);

            foreach (var field in fields)
            {
                var row = existingFields.FirstOrDefault(x =>
                    (field.ParameterFieldDefinitionId > 0 && x.ParameterFieldDefinitionId == field.ParameterFieldDefinitionId) ||
                    (field.ParameterFieldDefinitionId == 0 && string.Equals(x.FieldCode, field.FieldCode, StringComparison.OrdinalIgnoreCase)));

                if (row is null)
                {
                    field.ParameterFieldDefinitionId = 0;
                    _db.ParameterFieldDefinitions.Add(field);
                    continue;
                }

                // keep the key of the existing row (a new row may match an old one by code)
                field.ParameterFieldDefinitionId = row.ParameterFieldDefinitionId;
                _db.Entry(row).CurrentValues.SetValues(field);
                row.IsActive = true;
                existingFields.Remove(row);
            }

            // removed fields: deleted, or switched off when an assessment already has answers for them
            var removedIds = existingFields.Select(x => x.ParameterFieldDefinitionId).ToList();
            var answered = await _db.FrameworkParameterResponses
                .Where(x => removedIds.Contains(x.ParameterFieldDefinitionId))
                .Select(x => x.ParameterFieldDefinitionId)
                .Distinct()
                .ToListAsync(ct);

            foreach (var row in existingFields)
            {
                if (answered.Contains(row.ParameterFieldDefinitionId))
                    row.IsActive = false;
                else
                    _db.ParameterFieldDefinitions.Remove(row);
            }

            // ------------------------------------------------ score rules
            var existingRules = await _db.RuleDefinitions
                .Where(x => x.IndustryParameterMappingId == industryParameterMappingId)
                .ToListAsync(ct);

            foreach (var rule in rules)
            {
                var row = existingRules.FirstOrDefault(x => rule.RuleDefinitionId > 0 && x.RuleDefinitionId == rule.RuleDefinitionId);

                if (row is null)
                {
                    rule.RuleDefinitionId = 0;
                    _db.RuleDefinitions.Add(rule);
                    continue;
                }

                row.DisplayOrder = rule.DisplayOrder;
                row.RuleName = rule.RuleName;
                row.RuleExpressionType = rule.RuleExpressionType;
                row.Expression = rule.Expression;
                row.OutputExpression = rule.OutputExpression;
                row.IsActive = rule.IsActive;
                existingRules.Remove(row);
            }

            _db.RuleDefinitions.RemoveRange(existingRules);

            // ------------------------------------------------ score texts
            var scoreRows = await _db.ScaleConfigurationDetails
                .Where(x => x.IndustryParameterMappingId == industryParameterMappingId)
                .ToListAsync(ct);

            foreach (var row in scoreRows)
            {
                if (scoreDescriptions.TryGetValue(row.ScaleConfigurationDetailsId, out var text))
                    row.ScoreDescription = text;
            }

            // one transaction
            await _db.SaveChangesAsync(ct);
        }
    }
}