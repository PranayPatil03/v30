﻿using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Domain.Entities;
using CRISP.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRISP.Infrastructure.Repositories.CRF.Framework
{
    public sealed class GeneralRepository : IGeneralRepository
    {
        private readonly CrispDbContext _db;

        public GeneralRepository(
            CrispDbContext db)
        {
            _db = db;
        }

        public async Task<FrameworkGeneral?> GetAsync(
            int assessmentResponseId,
            CancellationToken ct = default)
        {
            return await _db.FrameworkGenerals
                .AsNoTracking()
                .Include(x => x.AssessmentResponse)
                .Include(x => x.CustomerMaster)
                .Include(x => x.WorkflowJsonVersion)
                .FirstOrDefaultAsync(
                    x => x.AssessmentResponseId == assessmentResponseId,
                    ct);
        }

        public async Task<FrameworkGeneral> SaveAsync(
            FrameworkGeneral entity,
            CancellationToken ct = default)
        {
            var existing =
                await _db.FrameworkGenerals
                    .FirstOrDefaultAsync(
                        x => x.AssessmentResponseId ==
                             entity.AssessmentResponseId,
                        ct);

            if (existing == null)
            {
                entity.FrameworkGeneralId = 0;
                entity.CreatedOn = DateTime.UtcNow;
                entity.UpdatedOn = DateTime.UtcNow;

                _db.FrameworkGenerals.Add(entity);

                await _db.SaveChangesAsync(ct);

                return entity;
            }

            existing.EntityId =
                entity.EntityId;

            existing.WorkflowJsonVersionId =
                entity.WorkflowJsonVersionId;

            existing.NoOfPastYears =
                entity.NoOfPastYears;

            existing.NoOfProjectedYears =
                entity.NoOfProjectedYears;

            existing.LatestFinancialYear =
                entity.LatestFinancialYear;

            existing.IsListed =
                entity.IsListed;

            existing.IsParentSupported =
                entity.IsParentSupported;

            existing.ParentType =
                entity.ParentType;

            existing.UpdatedOn =
                DateTime.UtcNow;

            await _db.SaveChangesAsync(ct);

            return existing;
        }
    }
}