using CRISP.Application.DTOs;
using CRISP.Application.Interfaces;
using CRISP.Application.Services;
using CRISP.Application.Services.CRF.Framework;
using CRISP.Domain.Entities;
using CRISP.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System.Text.Encodings.Web;
using System.Text.Json;
namespace CRISP.Infrastructure.Repositories;

public class FrameworkRepository(CrispDbContext db) : IFrameworkRepository
{
    private IQueryable<WorkflowJsonVersion> Versions(string code) => db.WorkflowJsonVersions.Where(v => v.WorkflowCode == code);
    private async Task<WorkflowJsonVersion?> Latest(string code, CancellationToken ct = default) => await Versions(code).OrderByDescending(v => v.VersionNo).FirstOrDefaultAsync(ct);
    private static WorkflowDto ToWorkflow(WorkflowJsonVersion v) => new(v.WorkflowJsonVersionId, v.WorkflowCode, v.WorkflowName, true);
    // adds a new entity, or updates an existing one; when this context already tracks a row with
    // the same key (read earlier in the same request), its values are updated instead
    // returns the instance EF Core tracks
    private T AddOrUpdate<T>(T entity, bool isNew, Func<T, bool> sameKey) where T : class
    {
        var set = db.Set<T>();
        if (isNew)
        {
            set.Add(entity);
            return entity;
        }

        var tracked = set.Local.FirstOrDefault(sameKey);
        if (tracked is null)
        {
            set.Update(entity);
            return entity;
        }

        if (!ReferenceEquals(tracked, entity))
            db.Entry(tracked).CurrentValues.SetValues(entity);

        return tracked;
    }

    // the version JSON, read by the shared parser of the Application layer
    private static Task<WorkflowDefinitionDto> Definition(WorkflowJsonVersion v, CancellationToken ct) =>
        Task.FromResult(WorkflowDefinitionJson.Parse(v.JsonContent, v.WorkflowName));


    private static List<FrameworkStepDto> BuildSteps(
    WorkflowDefinitionDto definition)
    {
        // If workflow JSON already contains configured steps,
        // always use those.
        if (definition.Steps is not null &&
            definition.Steps.Count > 0)
        {
            return definition.Steps
                .OrderBy(x => x.DisplayOrder)
                .Select((x, index) =>
                    new FrameworkStepDto(
                        index + 1,
                        x.StepName,
                        x.DisplayOrder > 0
                            ? x.DisplayOrder
                            : index + 1,
                        true))
                .ToList();
        }

        // Compatibility for old CRISP workflow JSON
        // that was created before Steps existed.
        return
        [
            new FrameworkStepDto(1, "Business", 1, true),

                new FrameworkStepDto(2, "General", 2, true),

                new FrameworkStepDto(3, "Others", 3, true),

                new FrameworkStepDto(4, "Parent/Group", 4, true),

                new FrameworkStepDto(5, "Output", 5, true),

                new FrameworkStepDto(6, "Sensitivity", 6, true),

                new FrameworkStepDto(7, "Summary", 7, true),

            new FrameworkStepDto(8, "Benchmarks", 8, true)
        ];
    }


    private async Task<List<ParameterDto>> Params(WorkflowJsonVersion v, CancellationToken ct, int? industryId = null)
    {
        var def = await Definition(v, ct);
        var maps = await db.IndustryParameterMappings.Where(m => m.WorkflowJsonVersionId == v.WorkflowJsonVersionId && m.IndustryDetailsId == (industryId ?? v.IndustryDetailsId) && m.IsActive).ToListAsync(ct);
        var masters = await db.ParameterDefinitionMasters.Where(p => p.IsActive).ToDictionaryAsync(p => p.ParameterDefinitionMasterId, ct);
        var result = new List<ParameterDto>();
        foreach (var d in def.Parameters)
        {
            var map = maps.FirstOrDefault(m => masters.TryGetValue(m.ParameterDefinitionMasterId, out var p) && p.ParameterCode == d.ParameterCode);
            if (map == null) continue;
            var master = masters[map.ParameterDefinitionMasterId];
            var scales = (await db.ScaleConfigurationDetails.Where(s => s.IndustryParameterMappingId == map.IndustryParameterMappingId).ToListAsync(ct)).OrderByScore();
            var scores = scales.Select(s => new ScoreDto(ScoreValues.Display(s.ScoreValue), s.Definition, null, null, s.MinValue, s.MaxValue, true, true)).ToList();
            if (scores.Count == 0) scores = d.Scores.Select(x => new ScoreDto(x.Score, x.Definition, x.ThresholdValue, x.Unit, x.MinValue, x.MaxValue, x.MinInclusive, x.MaxInclusive)).ToList();
            var dto =
new ParameterDto(
    map.IndustryParameterMappingId,
    d.ParameterCode,
    map.ParameterDisplayName.Length > 0
        ? map.ParameterDisplayName
        : master.ParameterName,
    master.WhyItMatters,
    d.HowDoWeMeasure,
    map.Weight,
    d.DisplayOrder,
    !ParameterScoring.UsesPopupCalculation(map.ControlType) &&
        (ParameterScoring.RequiresValueRanges(map.ValueType, map.ControlType) || d.IsValueDriven),
    scores);

            dto.StepName =
                map.StepName;

            dto.ControlType =
                map.ControlType;

            result.Add(dto);
        }
        return result;
    }
    public async Task<IReadOnlyList<WorkflowDto>> GetWorkflowsAsync(CancellationToken ct = default)
    {
        var query = db.WorkflowJsonVersions
            .AsNoTracking()
            .Where(v => !db.WorkflowJsonVersions.Any(other =>
                other.WorkflowCode == v.WorkflowCode && other.VersionNo > v.VersionNo))
            .Join(db.IndustryDetails.AsNoTracking(),
                v => v.IndustryDetailsId,
                i => i.IndustryDetailId,
                (v, i) => new { Version = v, Industry = i })
            .OrderBy(x => x.Industry.IndustryName)
            .ThenBy(x => x.Version.WorkflowName)
            .Select(x => new WorkflowDto(
                x.Version.WorkflowJsonVersionId,
                x.Version.WorkflowCode,
                x.Version.WorkflowName,
                true)
            {
                IndustryDetailsId = x.Industry.IndustryDetailId,
                IndustryName = x.Industry.IndustryName
            });

        return await query.ToListAsync(ct);
    }
    public async Task<WorkflowDto> CreateWorkflowAsync(CreateWorkflowRequest request, string skeletonJson, CancellationToken ct = default)
    {
        var code = request.WorkflowCode.Trim();
        if (await db.WorkflowJsonVersions.AnyAsync(v => v.WorkflowCode == code, ct)) throw new InvalidOperationException($"Workflow code '{code}' already exists.");
        if (request.IndustryDetailsId <= 0)
            throw new InvalidOperationException("Select an industry before creating a workflow.");
        var industry = await db.IndustryDetails.FirstOrDefaultAsync(
            x => x.IndustryDetailId == request.IndustryDetailsId && x.IsActive, ct);
        if (industry is null)
            throw new InvalidOperationException("The selected industry does not exist or is inactive.");
        var v = new WorkflowJsonVersion
        {
            IndustryDetailsId = industry.IndustryDetailId,
            WorkflowCode = code,
            WorkflowName = request.WorkflowName.Trim(),
            VersionNo = 1,
            VersionName = $"{DateTime.Today:dd-MMM-yyyy} - Draft",
            Status = "Draft",
            JsonContent = skeletonJson,
            IsPublished = false
        };
        db.WorkflowJsonVersions.Add(v);
        await db.SaveChangesAsync(ct);
        return new WorkflowDto(v.WorkflowJsonVersionId, v.WorkflowCode, v.WorkflowName, true)
        {
            IndustryDetailsId = industry.IndustryDetailId,
            IndustryName = industry.IndustryName
        };
    }
    public async Task<WorkflowContextDto?> GetWorkflowContextAsync(
    string code,
    CancellationToken ct = default)
    {
        var version = await Latest(
            code,
            ct);

        if (version is null)
            return null;

        var definition = await Definition(
            version,
            ct);

        var steps = BuildSteps(definition);

        return new WorkflowContextDto
        {
            Workflow = ToWorkflow(version),
            Steps = steps
        };
    }
    public async Task<IReadOnlyList<EntityDto>> SearchEntitiesAsync(string? search, CancellationToken ct = default) => await db.CustomerMasters.AsNoTracking().Where(e => e.IsActive && (string.IsNullOrWhiteSpace(search) || e.EntityName.Contains(search))).OrderBy(e => e.EntityName).Select(e => new EntityDto(e.EntityId, e.EntityName)).Take(50).ToListAsync(ct);
    public async Task<IReadOnlyList<FrameworkLookupDto>>
 GetFrameworkOptionsAsync(
     int entityId,
     CancellationToken ct = default)
    {
        if (entityId <= 0)
            return [];

        var responses = await db.AssessmentResponses
            .AsNoTracking()
            .Include(x => x.WorkflowJsonVersion)
            .Where(x => x.EntityId == entityId)
            .OrderByDescending(x => x.UpdatedOn)
            .ThenByDescending(x => x.AssessmentResponseId)
            .ToListAsync(ct);

        var industryIds = responses
            .Select(x => x.WorkflowJsonVersion.IndustryDetailsId)
            .Distinct()
            .ToList();

        var industries = await db.IndustryDetails
            .AsNoTracking()
            .Where(x => industryIds.Contains(x.IndustryDetailId))
            .ToDictionaryAsync(
                x => x.IndustryDetailId,
                x => x.IndustryName,
                ct);

        return responses
            .Select(x =>
            {
                industries.TryGetValue(
                    x.WorkflowJsonVersion.IndustryDetailsId,
                    out var industryName);

                return new FrameworkLookupDto(
                    x.AssessmentResponseId,
                    $"{x.WorkflowJsonVersion.WorkflowName} - V{x.WorkflowJsonVersion.VersionNo}",
                    x.Status,
                    x.UpdatedOn,
                    x.WorkflowJsonVersion.VersionNo,
                    industryName ?? string.Empty,
                    x.WorkflowJsonVersion.WorkflowCode);
            })
            .ToList();
    }

    public async Task<IReadOnlyList<IndustrySegmentDto>>
    GetIndustrySegmentsAsync(
        string code,
        CancellationToken ct = default)
    {
        return await db.WorkflowJsonVersions
            .AsNoTracking()
            .Where(x => x.WorkflowCode == code)
            .Join(
                db.IndustryDetails.AsNoTracking()
                    .Where(x => x.IsActive),
                version => version.IndustryDetailsId,
                industry => industry.IndustryDetailId,
                (version, industry) => new
                {
                    industry.IndustryDetailId,
                    industry.IndustryName
                })
            .Distinct()
            .OrderBy(x => x.IndustryName)
            .Select(x => new IndustrySegmentDto(
                x.IndustryDetailId,
                x.IndustryName))
            .ToListAsync(ct);
    }
    public async Task<IReadOnlyList<FrameworkStepDto>>
GetStepsAsync(
    string code,
    CancellationToken ct = default)
    {
        var version = await Latest(
            code,
            ct);

        if (version is null)
            return [];

        var definition = await Definition(
            version,
            ct);

        return BuildSteps(definition);
    }

    public async Task<IReadOnlyList<FrameworkListDto>> GetFrameworksAsync(CancellationToken ct = default)
    {
        var rs = await db.AssessmentResponses.Include(r => r.CustomerMaster).Include(r => r.WorkflowJsonVersion).OrderByDescending(r => r.UpdatedOn).ToListAsync(ct);
        return rs.Select(r => new FrameworkListDto(r.AssessmentResponseId, r.CustomerMaster.EntityName, "", r.WorkflowJsonVersion.WorkflowName, r.Status, r.WorkflowJsonVersion.VersionNo, r.UpdatedOn)).ToList();
    }

    public async Task<ParameterDto?> GetParameterAsync(
        int id,
        CancellationToken ct = default)
    {
        var mapping = await db.IndustryParameterMappings
            .AsNoTracking()
            .FirstOrDefaultAsync(
                x => x.IndustryParameterMappingId == id
                     && x.IsActive,
                ct);

        if (mapping is null)
            return null;

        var version = await db.WorkflowJsonVersions
            .AsNoTracking()
            .FirstOrDefaultAsync(
                x => x.WorkflowJsonVersionId == mapping.WorkflowJsonVersionId,
                ct);

        if (version is null)
            return null;

        var master = await db.ParameterDefinitionMasters
            .AsNoTracking()
            .FirstOrDefaultAsync(
                x => x.ParameterDefinitionMasterId ==
                     mapping.ParameterDefinitionMasterId,
                ct);

        if (master is null)
            return null;

        var definition = await Definition(version, ct);

        var jsonParameter = definition.Parameters
            .FirstOrDefault(x =>
                string.Equals(
                    x.ParameterCode,
                    master.ParameterCode,
                    StringComparison.OrdinalIgnoreCase));

        var scaleDetails = await db.ScaleConfigurationDetails
            .AsNoTracking()
            .Where(x =>
                x.IndustryParameterMappingId ==
                mapping.IndustryParameterMappingId)
            .ToListAsync(ct);

        var scores = scaleDetails
            .OrderByScore()
            .Select(x => new ScoreDto(
                ScoreValues.Display(x.ScoreValue),
                x.Definition,
                null,
                null,
                x.MinValue,
                x.MaxValue,
                true,
                true))
            .ToList();

        // If no database scale rows exist, use the selected version's JSON.
        if (scores.Count == 0 && jsonParameter is not null)
        {
            scores = jsonParameter.Scores
                .Select(x => new ScoreDto(
                    x.Score,
                    x.Definition,
                    x.ThresholdValue,
                    x.Unit,
                    x.MinValue,
                    x.MaxValue,
                    x.MinInclusive,
                    x.MaxInclusive))
                .ToList();
        }

        return new ParameterDto(
    mapping.IndustryParameterMappingId,
    master.ParameterCode,
    string.IsNullOrWhiteSpace(mapping.ParameterDisplayName)
        ? master.ParameterName
        : mapping.ParameterDisplayName,
    master.WhyItMatters,
    !string.IsNullOrWhiteSpace(master.HowDoWeMeasure)
        ? master.HowDoWeMeasure
        : jsonParameter?.HowDoWeMeasure ?? string.Empty,
    mapping.Weight,
    mapping.DisplayOrder,
    ParameterScoring.RequiresValueRanges(mapping.ValueType, mapping.ControlType),
    scores)
        {
            StepName = string.IsNullOrWhiteSpace(mapping.StepName)
        ? "Business"
        : mapping.StepName,

            ControlType = mapping.ParentIndustryParameterMappingId is not null
        ? "Popup"
        : string.IsNullOrWhiteSpace(mapping.ControlType)
            ? "Score"
            : mapping.ControlType
        };

    }

    public async Task<IReadOnlyList<ParameterDto>> GetParametersAsync(string code, CancellationToken ct = default)
    {
        var v = await Latest(code, ct);
        return v == null ? [] : await Params(v, ct);
    }


    // ------------------------------------------------------------ parameter master (EF Core only)

    public Task<List<ParameterDefinitionMaster>> GetParameterMastersAsync(
        CancellationToken ct = default) =>
        db.ParameterDefinitionMasters
            .AsNoTracking()
            .ToListAsync(ct);

    public Task<ParameterDefinitionMaster?> GetParameterMasterAsync(
        int parameterDefinitionMasterId,
        CancellationToken ct = default) =>
        db.ParameterDefinitionMasters
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.ParameterDefinitionMasterId == parameterDefinitionMasterId, ct);

    public Task<bool> ParameterCodeExistsAsync(
        string parameterCode,
        int exceptParameterDefinitionMasterId,
        CancellationToken ct = default) =>
        db.ParameterDefinitionMasters
            .AnyAsync(x =>
                x.ParameterCode == parameterCode &&
                x.ParameterDefinitionMasterId != exceptParameterDefinitionMasterId,
                ct);

    public async Task SaveParameterMasterAsync(
        ParameterDefinitionMaster master,
        CancellationToken ct = default)
    {
        AddOrUpdate(
            master,
            master.ParameterDefinitionMasterId == 0,
            x => x.ParameterDefinitionMasterId == master.ParameterDefinitionMasterId);

        await db.SaveChangesAsync(ct);
    }

    public Task<List<ParameterMasterUsage>> GetParameterMasterUsageAsync(
        int parameterDefinitionMasterId,
        CancellationToken ct = default) =>
        (from m in db.IndustryParameterMappings
         join v in db.WorkflowJsonVersions on m.WorkflowJsonVersionId equals v.WorkflowJsonVersionId
         where m.ParameterDefinitionMasterId == parameterDefinitionMasterId
         select new { v.WorkflowCode, v.VersionNo })
            .Distinct()
            .OrderBy(x => x.WorkflowCode)
            .ThenBy(x => x.VersionNo)
            .Select(x => new ParameterMasterUsage(x.WorkflowCode, x.VersionNo))
            .ToListAsync(ct);

    public async Task DeleteParameterMasterAsync(
        int parameterDefinitionMasterId,
        CancellationToken ct = default)
    {
        await db.ParameterDefinitionMasters
            .Where(x => x.ParameterDefinitionMasterId == parameterDefinitionMasterId)
            .ExecuteDeleteAsync(ct);
    }

    private async Task<AssessmentResponse?> Response(int id, CancellationToken ct) => await db.AssessmentResponses.Include(r => r.CustomerMaster).Include(r => r.WorkflowJsonVersion).FirstOrDefaultAsync(r => r.AssessmentResponseId == id, ct);
    public async Task<FrameworkDto?> GetFrameworkShellAsync(
    int id,
    CancellationToken ct = default)
    {
        var r = await Response(id, ct);

        if (r == null)
            return null;

        var v = r.WorkflowJsonVersion;

        var ind = await db.IndustryDetails
            .FindAsync(
                [v.IndustryDetailsId],
                ct);

        var segments =
            ReadIndustrySegments(
                r.ResponseJson);

        var availableVersions =
    await Versions(v.WorkflowCode)
        .AsNoTracking()
        .OrderByDescending(x => x.VersionNo)
        .Select(x => new VersionDto(
            x.WorkflowJsonVersionId,
            x.VersionNo,
            x.VersionName,
            x.Status,
            x.IsPublished,
            DateTime.UtcNow,
            "Admin"))
        .ToListAsync(ct);

        foreach (var segment in segments)
        {
            segment.AvailableVersions = availableVersions;
        }


        var parameters =
                new List<ParameterDto>();

        foreach (var segment in segments)
        {
            var version =
                await db.WorkflowJsonVersions
                    .FirstOrDefaultAsync(x =>
                        x.WorkflowCode ==
                            segment.WorkflowCode
                        &&
                        x.VersionNo ==
                            segment.WorkflowVersionNo,
                        ct);

            if (version is null)
                continue;

            parameters.AddRange(
                await Params(
                    version,
                    ct,
                    segment.IndustrySegmentId));
        }

        parameters = parameters
            .GroupBy(x => x.Id)
            .Select(x => x.First())
            .OrderBy(x => x.DisplayOrder)
            .ToList();

        var definition =
            await Definition(v, ct);

        return new FrameworkDto
        {
            Id =
                r.AssessmentResponseId,

            EntityId =
                r.EntityId,

            EntityName =
                r.CustomerMaster.EntityName,

            WorkflowCode =
                v.WorkflowCode,

            IndustryName =
                ind?.IndustryName ?? string.Empty,

            FrameworkName =
                v.WorkflowName,

            Status =
                r.Status,

            WorkflowVersionNo =
                v.VersionNo,

            WorkflowJsonVersionId =
v.WorkflowJsonVersionId,

            FrameworkDate =
                r.UpdatedOn,

            Parameters =
                parameters,

            Steps =
                BuildSteps(definition),

            IndustrySegments =
                segments,

            Workflow =
                new WorkflowSummaryDto
                {
                    Id =
                        v.WorkflowJsonVersionId,

                    WorkflowCode =
                        v.WorkflowCode,

                    WorkflowName =
                        v.WorkflowName,

                    IsActive =
                        true
                }
        };
    }
    public async Task<IReadOnlyList<FrameworkParameterDto>> GetFrameworkParameterValuesAsync(int id, CancellationToken ct = default)
    {
        var r = await Response(id, ct);
        if (r == null) return [];
        return ReadValues(r.ResponseJson);
    }
    private static List<BusinessParameterDetailsDto> ReadIndustrySegments(string json)
    {
        try
        {
            using var document = JsonDocument.Parse(json);
            if (!document.RootElement.TryGetProperty("IndustrySegments", out var items) || items.ValueKind != JsonValueKind.Array)
                return [];
            return items.EnumerateArray().Select(x =>
     new BusinessParameterDetailsDto(
         x.TryGetProperty("Id", out var id)
             ? id.GetInt32()
             : 0,

         x.TryGetProperty("IndustrySegmentId", out var industryId)
             ? industryId.GetInt32()
             : 0,

         x.TryGetProperty("IndustryName", out var name)
             ? name.GetString() ?? string.Empty
             : string.Empty,

         x.TryGetProperty("Weight", out var weight)
             ? weight.GetDecimal()
             : 0m,

         x.TryGetProperty("Status", out var status)
             ? status.GetString() ?? string.Empty
             : string.Empty,

         x.TryGetProperty("WorkflowCode", out var workflowCode)
             ? workflowCode.GetString() ?? string.Empty
             : string.Empty,

         x.TryGetProperty("WorkflowVersionNo", out var versionNo)
             ? versionNo.GetInt32()
             : 0))
                 .Where(x => x.IndustrySegmentId > 0)
                .ToList();
        }
        catch (JsonException) { return []; }
    }

    private static List<FrameworkParameterDto> ReadValues(string json)
    {
        try
        {
            using var d = JsonDocument.Parse(json);
            var root = d.RootElement;
            if (root.TryGetProperty("Values", out var values) && values.ValueKind == JsonValueKind.Array) return values.EnumerateArray().Select(x => new FrameworkParameterDto(x.TryGetProperty("ParameterId", out var id) ? id.GetInt32() : 0, x.TryGetProperty("ParameterName", out var n) ? n.GetString() ?? "" : "", x.TryGetProperty("Weight", out var w) ? w.GetDecimal() : 0, x.TryGetProperty("Value", out var v) && v.ValueKind == JsonValueKind.Number ? v.GetDecimal() : null, x.TryGetProperty("Score", out var s) ? s.GetInt32() : 0)).ToList();
        }
        catch
        {
        }
        return [];
    }
    public async Task<string?> GetFrameworkValueJsonAsync(int id, CancellationToken ct = default) => (await Response(id, ct))?.ResponseJson;
    public async Task<string?> GetFrameworkValueJsonAsync(
    int id,
    int versionNo,
    CancellationToken ct = default)
    {
        var baseResponse =
            await Response(id, ct);

        if (baseResponse is null)
            return null;

        var target =
            await Versions(
                    baseResponse.WorkflowJsonVersion.WorkflowCode)
                .AsNoTracking()
                .FirstOrDefaultAsync(
                    v => v.VersionNo == versionNo,
                    ct);

        if (target is null)
            return null;

        // Exact current assessment
        if (target.WorkflowJsonVersionId ==
            baseResponse.WorkflowJsonVersionId)
        {
            return baseResponse.ResponseJson;
        }

        // Version-specific snapshot
        return await db.AssessmentResponses
            .AsNoTracking()
            .Where(x =>
                x.EntityId ==
                    baseResponse.EntityId &&
                x.WorkflowJsonVersionId ==
                    target.WorkflowJsonVersionId)
            .OrderByDescending(x => x.UpdatedOn)
            .Select(x => x.ResponseJson)
            .FirstOrDefaultAsync(ct);
    }
    public async Task SaveFrameworkValueJsonAsync(
     int id,
     int versionNo,
     string json,
     CancellationToken ct = default)
    {
        var baseResponse =
            await Response(id, ct)
            ?? throw new InvalidOperationException(
                "Assessment response not found.");

        var target =
            await Versions(
                    baseResponse.WorkflowJsonVersion.WorkflowCode)
                .FirstOrDefaultAsync(
                    v => v.VersionNo == versionNo,
                    ct)
            ?? throw new InvalidOperationException(
                "Workflow version not found.");

        AssessmentResponse? response;

        /*
         * Same version:
         * update the EXACT selected framework.
         */
        if (baseResponse.WorkflowJsonVersionId ==
            target.WorkflowJsonVersionId)
        {
            response = await db.AssessmentResponses
                .FirstOrDefaultAsync(
                    x => x.AssessmentResponseId == id,
                    ct);
        }
        else
        {
            /*
             * Different version snapshot.
             *
             * Your current schema does not have a parent/framework-instance
             * identifier connecting version snapshots, so this remains
             * version/entity based for now.
             */
            response = await db.AssessmentResponses
                .FirstOrDefaultAsync(
                    x =>
                        x.EntityId == baseResponse.EntityId &&
                        x.WorkflowJsonVersionId ==
                            target.WorkflowJsonVersionId,
                    ct);
        }

        if (response is null)
        {
            response = new AssessmentResponse
            {
                EntityId =
                    baseResponse.EntityId,

                WorkflowJsonVersionId =
                    target.WorkflowJsonVersionId,

                ResponseJson =
                    json,

                Status =
                    "Draft",

                CreatedOn =
                    DateTime.UtcNow,

                UpdatedOn =
                    DateTime.UtcNow
            };

            db.AssessmentResponses.Add(response);
        }
        else
        {
            response.ResponseJson =
                json;

            response.UpdatedOn =
                DateTime.UtcNow;
        }

        await db.SaveChangesAsync(ct);
    }
    public async Task ClearFrameworkValueJsonAsync(int id, CancellationToken ct = default)
    {
        var r = await Response(id, ct);
        if (r != null)
        {
            r.ResponseJson = "{}";
            r.UpdatedOn = DateTime.UtcNow;
            await db.SaveChangesAsync(ct);
        }
    }
    public async Task<FrameworkDto?> GetFrameworkAsync(
    int id,
    int? frameworkVersionNo = null,
    CancellationToken ct = default)
    {
        var framework =
            await GetFrameworkShellAsync(id, ct);

        if (framework is null)
            return null;
        var selectedVersionNo =
            frameworkVersionNo ??
            framework.WorkflowVersionNo;

        framework.WorkflowVersionNo =
            selectedVersionNo;

        var version =
            await Versions(framework.WorkflowCode)
                .FirstOrDefaultAsync(
                    x => x.VersionNo ==
                         selectedVersionNo,
                    ct);

        if (version != null)
        {
            framework.Parameters =
                await Params(
                    version,
                    ct,
                    version.IndustryDetailsId);
        }

        var json =
            await GetFrameworkValueJsonAsync(
                id,
                selectedVersionNo,
                ct);

        if (!string.IsNullOrWhiteSpace(json))
        {
            framework.ParameterValues =
                ReadValues(json);

            var loadedSegments =
                ReadIndustrySegments(json);
            if (loadedSegments.Count > 0)
            {
                foreach (var segment in loadedSegments)
                {
                    segment.AvailableVersions =
                        framework.IndustrySegments
                                 .FirstOrDefault()?
                                 .AvailableVersions
                        ?? [];
                }

                foreach (var existingSegment in framework.IndustrySegments)
                {
                    var match =
                        loadedSegments.FirstOrDefault(x =>
                            x.IndustrySegmentId ==
                            existingSegment.IndustrySegmentId);

                    if (match is not null)
                    {
                        existingSegment.WorkflowVersionNo =
                            match.WorkflowVersionNo;

                        existingSegment.Weight =
                            match.Weight;

                        existingSegment.Status =
                            match.Status;
                    }
                }
            }
        }

        return framework;
    }
    public async Task<FrameworkDto> SaveFrameworkAsync(FrameworkDto f, CancellationToken ct = default)
    {
        var primarySegment =
     f.IndustrySegments.FirstOrDefault()
     ?? throw new InvalidOperationException(
         "At least one industry segment is required.");

        var v =
            await db.WorkflowJsonVersions
                .FirstOrDefaultAsync(
                    x =>
                        x.WorkflowCode ==
                            primarySegment.WorkflowCode
                        &&
                        x.VersionNo ==
                            primarySegment.WorkflowVersionNo,
                    ct)
            ?? throw new InvalidOperationException(
                "Workflow version not found.");
        var entity = await db.CustomerMasters.FirstOrDefaultAsync(e => e.EntityId == f.EntityId, ct);
        if (entity == null)
        {
            entity = new CustomerMaster
            {
                EntityName = f.EntityName.Trim(),
                IsActive = true
            };
            db.CustomerMasters.Add(entity);
            await db.SaveChangesAsync(ct);
        }
        var r = f.Id > 0 ? await db.AssessmentResponses.FirstOrDefaultAsync(x => x.AssessmentResponseId == f.Id, ct) : null;
        if (r == null) r = await db.AssessmentResponses.FirstOrDefaultAsync(x => x.EntityId == entity.EntityId && x.WorkflowJsonVersionId == v.WorkflowJsonVersionId, ct);
        if (r == null)
        {
            r = new AssessmentResponse
            {
                EntityId = entity.EntityId,
                WorkflowJsonVersionId = v.WorkflowJsonVersionId,
                Status = f.Status,
                ResponseJson = "{}"
            };
            db.AssessmentResponses.Add(r);
        }
        r.EntityId = entity.EntityId;
        r.WorkflowJsonVersionId = v.WorkflowJsonVersionId;
        r.Status = f.Status;
        r.UpdatedOn = DateTime.UtcNow;
        r.ResponseJson = JsonSerializer.Serialize(new
        {
            FrameworkId = r.AssessmentResponseId,
            WorkflowCode = f.WorkflowCode,
            WorkflowVersionNo = v.VersionNo,
            EntityId = entity.EntityId,
            EntityName = entity.EntityName,
            IndustrySegments = f.IndustrySegments,
            Values = f.ParameterValues.Select(x => new {
                ParameterId = x.ParameterId,
                ParameterCode = f.Parameters.FirstOrDefault(p => p.Id == x.ParameterId)?.ParameterCode ?? "",
                ParameterName = x.ParameterName,
                Weight = x.Weight,
                Value = x.Value,
                Score = x.Score
            })
        });
        await db.SaveChangesAsync(ct);
        return await GetFrameworkShellAsync(r.AssessmentResponseId, ct) ?? f;
    }
    public async Task<WorkflowJsonVersion?> GetWorkflowVersionAsync(
    string workflowCode,
    int versionNo,
    CancellationToken ct = default)
    {
        return await db.WorkflowJsonVersions
            .FirstOrDefaultAsync(
                x =>
                    x.WorkflowCode == workflowCode &&
                    x.VersionNo == versionNo,
                ct);
    }


    // ------------------------------------------------------------ industry parameter mapping (EF Core only)

    public Task<List<IndustryParameterMapping>> GetIndustryParameterMappingsAsync(
        int workflowJsonVersionId,
        int industryId,
        CancellationToken ct = default) =>
        db.IndustryParameterMappings
            .AsNoTracking()
            .Where(x =>
                x.WorkflowJsonVersionId == workflowJsonVersionId &&
                x.IndustryDetailsId == industryId)
            .ToListAsync(ct);

    public async Task<Dictionary<int, int>> GetScaleIdsAsync(
        IReadOnlyCollection<int> industryParameterMappingIds,
        CancellationToken ct = default)
    {
        var rows = await db.ScaleConfigurationDetails
            .AsNoTracking()
            .Where(x => industryParameterMappingIds.Contains(x.IndustryParameterMappingId))
            .Select(x => new { x.IndustryParameterMappingId, x.ScaleConfigurationId })
            .Distinct()
            .ToListAsync(ct);

        return rows
            .GroupBy(x => x.IndustryParameterMappingId)
            .ToDictionary(g => g.Key, g => g.First().ScaleConfigurationId);
    }

    public async Task SaveIndustryParameterMappingsAsync(
        IReadOnlyList<IndustryParameterMapping> mappings,
        IReadOnlyDictionary<int, int?> parentMasterIds,
        CancellationToken ct = default)
    {
        await using var transaction = await BeginOwnTransactionAsync(ct);

        var saved = mappings
            .Select(mapping => AddOrUpdate(
                mapping,
                mapping.IndustryParameterMappingId == 0,
                x => x.IndustryParameterMappingId == mapping.IndustryParameterMappingId))
            .ToList();

        // new mappings get their keys here
        await db.SaveChangesAsync(ct);

        // parent links by parameter master, now that every mapping has a key
        var byMaster = saved
            .Where(x => x.IsActive)
            .GroupBy(x => x.ParameterDefinitionMasterId)
            .ToDictionary(g => g.Key, g => g.First());

        foreach (var (childMasterId, parentMasterId) in parentMasterIds)
        {
            if (!byMaster.TryGetValue(childMasterId, out var child))
                continue;

            child.ParentIndustryParameterMappingId =
                parentMasterId is int id && byMaster.TryGetValue(id, out var parent)
                    ? parent.IndustryParameterMappingId
                    : null;
        }

        await db.SaveChangesAsync(ct);
        if (transaction is not null)
            await transaction.CommitAsync(ct);
    }

    // ------------------------------------------------------------ versions / workflow definition (EF Core only)

    public async Task<IUnitOfWorkTransaction> BeginTransactionAsync(CancellationToken ct = default) =>
        new EfTransaction(await BeginOwnTransactionAsync(ct));


    private async Task<IDbContextTransaction?> BeginOwnTransactionAsync(CancellationToken ct) =>
        db.Database.CurrentTransaction is null
            ? await db.Database.BeginTransactionAsync(ct)
            : null;

    private class EfTransaction(IDbContextTransaction? transaction) : IUnitOfWorkTransaction
    {
        public Task CommitAsync(CancellationToken ct = default) =>
            transaction?.CommitAsync(ct) ?? Task.CompletedTask;

        // disposing an uncommitted transaction rolls it back
        public ValueTask DisposeAsync() =>
            transaction?.DisposeAsync() ?? ValueTask.CompletedTask;
    }

    public Task<List<WorkflowJsonVersion>> GetWorkflowVersionsAsync(
        string workflowCode,
        CancellationToken ct = default) =>
        db.WorkflowJsonVersions
            .AsNoTracking()
            .Where(x => x.WorkflowCode == workflowCode)
            .ToListAsync(ct);

    public async Task AddWorkflowVersionAsync(
        WorkflowJsonVersion version,
        CancellationToken ct = default)
    {
        db.WorkflowJsonVersions.Add(version);
        await db.SaveChangesAsync(ct);
    }

    public async Task UpdateWorkflowVersionsAsync(
        IReadOnlyList<WorkflowJsonVersion> versions,
        CancellationToken ct = default)
    {
        foreach (var version in versions)
        {
            AddOrUpdate(
                version,
                false,
                x => x.WorkflowJsonVersionId == version.WorkflowJsonVersionId);
        }

        await db.SaveChangesAsync(ct);
    }

    public async Task CopyVersionConfigurationAsync(
        int sourceWorkflowJsonVersionId,
        int targetWorkflowJsonVersionId,
        int industryId,
        CancellationToken ct = default)
    {
        // ScaleConfiguration is a reusable master; ScaleConfigurationDetails are copied per mapping
        var previousMappings = await db.IndustryParameterMappings
            .AsNoTracking()
            .Where(x =>
                x.WorkflowJsonVersionId == sourceWorkflowJsonVersionId &&
                x.IndustryDetailsId == industryId &&
                x.IsActive)
            .ToListAsync(ct);

        if (previousMappings.Count == 0)
            return;

        var clonedMappingByMaster = new Dictionary<int, IndustryParameterMapping>();
        foreach (var previousMapping in previousMappings)
        {
            var clonedMapping = new IndustryParameterMapping
            {
                WorkflowJsonVersionId = targetWorkflowJsonVersionId,
                IndustryDetailsId = previousMapping.IndustryDetailsId,
                ParameterDefinitionMasterId = previousMapping.ParameterDefinitionMasterId,
                ParentIndustryParameterMappingId = null,
                ParameterDisplayName = previousMapping.ParameterDisplayName,
                ValueType = previousMapping.ValueType,
                Weight = previousMapping.Weight,
                DisplayOrder = previousMapping.DisplayOrder,
                IsActive = true,
                StepName = previousMapping.StepName,
                ControlType = previousMapping.ControlType,
                YearFromOffset = previousMapping.YearFromOffset,
                YearColumns = previousMapping.YearColumns,
                DetailsDescription = previousMapping.DetailsDescription,
                DetailsNote = previousMapping.DetailsNote,
                SectionName = previousMapping.SectionName,
                OptionsSource = previousMapping.OptionsSource
            };
            db.IndustryParameterMappings.Add(clonedMapping);
            clonedMappingByMaster[previousMapping.ParameterDefinitionMasterId] = clonedMapping;
        }

        // the copies need their keys for the rows below
        await db.SaveChangesAsync(ct);

        var previousIds = previousMappings.Select(x => x.IndustryParameterMappingId).ToList();
        var previousIdToMaster = previousMappings.ToDictionary(x => x.IndustryParameterMappingId, x => x.ParameterDefinitionMasterId);

        IndustryParameterMapping? CopyOf(int previousMappingId) =>
            previousIdToMaster.TryGetValue(previousMappingId, out var masterId) &&
            clonedMappingByMaster.TryGetValue(masterId, out var cloned)
                ? cloned
                : null;

        // score rows
        var previousScaleDetails = await db.ScaleConfigurationDetails
            .AsNoTracking()
            .Where(x => previousIds.Contains(x.IndustryParameterMappingId))
            .ToListAsync(ct);
        foreach (var detail in previousScaleDetails)
        {
            if (CopyOf(detail.IndustryParameterMappingId) is not { } clonedMapping)
                continue;

            db.ScaleConfigurationDetails.Add(new ScaleConfigurationDetails
            {
                IndustryParameterMappingId = clonedMapping.IndustryParameterMappingId,
                ScaleConfigurationId = detail.ScaleConfigurationId,
                ScoreValue = detail.ScoreValue,
                Definition = detail.Definition,
                ScoreDescription = detail.ScoreDescription,
                MinValue = detail.MinValue,
                MaxValue = detail.MaxValue
            });
        }

        // parent links (e.g. Liquidity -> its popups)
        foreach (var previousMapping in previousMappings.Where(x => x.ParentIndustryParameterMappingId is not null))
        {
            if (CopyOf(previousMapping.ParentIndustryParameterMappingId!.Value) is { } clonedParent)
            {
                clonedMappingByMaster[previousMapping.ParameterDefinitionMasterId].ParentIndustryParameterMappingId =
                    clonedParent.IndustryParameterMappingId;
            }
        }

        // popup fields
        var previousFields = await db.ParameterFieldDefinitions
            .AsNoTracking()
            .Where(x => previousIds.Contains(x.IndustryParameterMappingId))
            .ToListAsync(ct);
        foreach (var field in previousFields)
        {
            if (CopyOf(field.IndustryParameterMappingId) is not { } clonedMapping)
                continue;

            field.ParameterFieldDefinitionId = 0;
            field.IndustryParameterMappingId = clonedMapping.IndustryParameterMappingId;
            field.IndustryParameterMapping = null;
            db.ParameterFieldDefinitions.Add(field);
        }

        // popup score rules (framework rules come from the definition)
        var previousPopupRules = await db.RuleDefinitions
            .AsNoTracking()
            .Where(x => x.IndustryParameterMappingId != null &&
                previousIds.Contains(x.IndustryParameterMappingId.Value))
            .ToListAsync(ct);
        foreach (var rule in previousPopupRules)
        {
            if (CopyOf(rule.IndustryParameterMappingId!.Value) is not { } clonedMapping)
                continue;

            rule.RuleDefinitionId = 0;
            rule.WorkflowJsonVersionId = targetWorkflowJsonVersionId;
            rule.IndustryParameterMappingId = clonedMapping.IndustryParameterMappingId;
            db.RuleDefinitions.Add(rule);
        }

        await db.SaveChangesAsync(ct);
    }

    public Task<ParameterDefinitionMaster?> GetParameterMasterByCodeAsync(
        string parameterCode,
        CancellationToken ct = default) =>
        db.ParameterDefinitionMasters
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.ParameterCode.ToLower() == parameterCode.ToLower(), ct);

    public Task<List<RuleDefinition>> GetFrameworkRulesAsync(
        int workflowJsonVersionId,
        CancellationToken ct = default) =>
        db.RuleDefinitions
            .AsNoTracking()
            .Where(x =>
                x.WorkflowJsonVersionId == workflowJsonVersionId &&
                x.IndustryParameterMappingId == null &&
                x.IsActive)
            .OrderBy(x => x.RuleDefinitionId)
            .ToListAsync(ct);

    public async Task AddRuleDefinitionsAsync(
        IReadOnlyList<RuleDefinition> rules,
        CancellationToken ct = default)
    {
        db.RuleDefinitions.AddRange(rules);
        await db.SaveChangesAsync(ct);
    }

    public async Task<List<ScaleConfigurationDetails>> GetScaleDetailsForMappingsAsync(
        IReadOnlyCollection<int> industryParameterMappingIds,
        CancellationToken ct = default) =>
        (await db.ScaleConfigurationDetails
            .AsNoTracking()
            .Where(x => industryParameterMappingIds.Contains(x.IndustryParameterMappingId))
            .ToListAsync(ct))
            .OrderByScore();

    public Task<List<ValidationDefinition>> GetValidationsForMappingsAsync(
        IReadOnlyCollection<int> industryParameterMappingIds,
        CancellationToken ct = default) =>
        db.ValidationDefinitions
            .AsNoTracking()
            .Where(x => industryParameterMappingIds.Contains(x.IndustryParameterMappingId))
            .OrderBy(x => x.ValidationDefinitionId)
            .ToListAsync(ct);

    public async Task<IReadOnlyList<IndustrySegmentDto>>
    GetAllIndustriesAsync(
        CancellationToken ct = default)
    {
        return await db.IndustryDetails
            .AsNoTracking()
            .Where(x => x.IsActive)
            .OrderBy(x => x.IndustryName)
            .Select(x => new IndustrySegmentDto(
                x.IndustryDetailId,
                x.IndustryName))
            .ToListAsync(ct);
    }

    // ------------------------------------------------------------ score configuration (EF Core only)

    public Task<IndustryParameterMapping?> GetIndustryParameterMappingAsync(
        int industryParameterMappingId,
        CancellationToken ct = default) =>
        db.IndustryParameterMappings
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.IndustryParameterMappingId == industryParameterMappingId, ct);

    public Task<WorkflowJsonVersion?> GetWorkflowVersionByIdAsync(
        int workflowJsonVersionId,
        CancellationToken ct = default) =>
        db.WorkflowJsonVersions
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.WorkflowJsonVersionId == workflowJsonVersionId, ct);

    public async Task<List<ScaleConfigurationDetails>> GetScaleDetailsAsync(
        int industryParameterMappingId,
        CancellationToken ct = default) =>
        (await db.ScaleConfigurationDetails
            .AsNoTracking()
            .Where(x => x.IndustryParameterMappingId == industryParameterMappingId)
            .ToListAsync(ct))
            .OrderByScore();

    public Task<ScaleConfiguration?> GetScaleAsync(
        int scaleConfigurationId,
        CancellationToken ct = default) =>
        db.ScaleConfigurations
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.ScaleConfigurationId == scaleConfigurationId, ct);

    public Task<ScaleConfiguration?> GetScaleByCodeAsync(
        string scaleCode,
        CancellationToken ct = default) =>
        db.ScaleConfigurations
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.ScaleCode == scaleCode, ct);

    public async Task SaveScoreConfigurationAsync(
        int industryParameterMappingId,
        ScaleConfiguration scale,
        IReadOnlyList<ScaleConfigurationDetails> details,
        CancellationToken ct = default)
    {
        await using var transaction = await BeginOwnTransactionAsync(ct);

        scale = AddOrUpdate(
            scale,
            scale.ScaleConfigurationId == 0,
            x => x.ScaleConfigurationId == scale.ScaleConfigurationId);

        // the new scale needs its key before the score rows
        await db.SaveChangesAsync(ct);

        var existing = await db.ScaleConfigurationDetails
            .Where(x => x.IndustryParameterMappingId == industryParameterMappingId)
            .ToListAsync(ct);
        db.ScaleConfigurationDetails.RemoveRange(existing);

        foreach (var detail in details)
        {
            detail.ScaleConfigurationDetailsId = 0;
            detail.IndustryParameterMappingId = industryParameterMappingId;
            detail.ScaleConfigurationId = scale.ScaleConfigurationId;
            db.ScaleConfigurationDetails.Add(detail);
        }

        await db.SaveChangesAsync(ct);
        if (transaction is not null)
            await transaction.CommitAsync(ct);
    }


    // ------------------------------------------------------------ validations (EF Core only)

    public Task<List<ValidationDefinition>> GetValidationsAsync(
        int industryParameterMappingId,
        CancellationToken ct = default) =>
        db.ValidationDefinitions
            .AsNoTracking()
            .Where(x => x.IndustryParameterMappingId == industryParameterMappingId)
            .ToListAsync(ct);

    public async Task ReplaceValidationsAsync(
        int industryParameterMappingId,
        IReadOnlyList<ValidationDefinition> validations,
        CancellationToken ct = default)
    {
        var existing = await db.ValidationDefinitions
            .Where(x => x.IndustryParameterMappingId == industryParameterMappingId)
            .ToListAsync(ct);

        db.ValidationDefinitions.RemoveRange(existing);

        foreach (var validation in validations)
        {
            validation.ValidationDefinitionId = 0;
            validation.IndustryParameterMappingId = industryParameterMappingId;
            db.ValidationDefinitions.Add(validation);
        }

        // one SaveChanges: delete and insert in the same transaction
        await db.SaveChangesAsync(ct);
    }
}