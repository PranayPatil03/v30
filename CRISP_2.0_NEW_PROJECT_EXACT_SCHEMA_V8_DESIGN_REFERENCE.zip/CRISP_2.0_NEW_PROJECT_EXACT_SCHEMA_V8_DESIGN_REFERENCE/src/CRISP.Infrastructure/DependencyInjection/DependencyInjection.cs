using CRISP.Application.Interfaces;
using CRISP.Application.Interfaces.IRepository.CRF.Framework;
using CRISP.Infrastructure.Repositories;
using CRISP.Infrastructure.Repositories.CRF.Framework;
using CRISP.Infrastructure.Rules;
using Microsoft.Extensions.DependencyInjection;
namespace CRISP.Infrastructure.DependencyInjection;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services)
    {
        services.AddScoped<IFrameworkRepository, FrameworkRepository>();
        services.AddScoped<IRuleEngineExecutor, RulesEngineExecutor>();
        services.AddMemoryCache();
        services.AddScoped<IWorkflowJsonProvider, WorkflowJsonProvider>();
        services.AddScoped<IGeneralRepository, GeneralRepository>();
        services.AddScoped<IOtherRepository, OtherRepository>();
        services.AddScoped<ISpreadRepository, SpreadRepository>();
        services.AddScoped<IParameterConfigRepository, ParameterConfigRepository>();
        services.AddScoped<IOutputRepository, OutputRepository>();
        return services;
    }
}