using CRISP.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;
namespace CRISP.Infrastructure.Persistence;

public class CrispDbContext(DbContextOptions<CrispDbContext> options) : DbContext(options)
{
    public DbSet<IndustryDetails> IndustryDetails => Set<IndustryDetails>();
    public DbSet<CustomerMaster> CustomerMasters => Set<CustomerMaster>();
    public DbSet<ParameterDefinitionMaster> ParameterDefinitionMasters => Set<ParameterDefinitionMaster>();
    public DbSet<WorkflowJsonVersion> WorkflowJsonVersions => Set<WorkflowJsonVersion>();
    public DbSet<IndustryParameterMapping> IndustryParameterMappings => Set<IndustryParameterMapping>();
    public DbSet<ValidationDefinition> ValidationDefinitions => Set<ValidationDefinition>();
    public DbSet<RuleDefinition> RuleDefinitions => Set<RuleDefinition>();
    public DbSet<ScaleConfiguration> ScaleConfigurations => Set<ScaleConfiguration>();
    public DbSet<ScaleConfigurationDetails> ScaleConfigurationDetails => Set<ScaleConfigurationDetails>();
    public DbSet<AssessmentResponse> AssessmentResponses => Set<AssessmentResponse>();
    public DbSet<FrameworkGeneral> FrameworkGenerals => Set<FrameworkGeneral>();
    public DbSet<ParameterFieldDefinition> ParameterFieldDefinitions => Set<ParameterFieldDefinition>();
    public DbSet<FrameworkParameterResponse> FrameworkParameterResponses => Set<FrameworkParameterResponse>();
    public DbSet<FrameworkParameterScore> FrameworkParameterScores => Set<FrameworkParameterScore>();
    public DbSet<RatingScale> RatingScales => Set<RatingScale>();

    public DbSet<FrameworkOutputDetails> FrameworkOutputDetails => Set<FrameworkOutputDetails>();
    public DbSet<RatingMatrix> RatingMatrices => Set<RatingMatrix>();
    public DbSet<RatingBand> RatingBands => Set<RatingBand>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<IndustryDetails>(e => {
            e.ToTable("IndustryDetails");

            e.HasKey(x => x.IndustryDetailId);

            e.Property(x => x.IndustryName)
                .HasMaxLength(256)
                .IsUnicode(false)
                .IsRequired();
        });
        b.Entity<CustomerMaster>(e =>
        {
            e.ToTable("CustomerMaster");

            e.HasKey(x => x.EntityId);

            e.Property(x => x.EntityName)
                .HasMaxLength(256)
                .IsUnicode(false)
                .IsRequired();

            e.Property(x => x.CustomerCode)
                .HasMaxLength(50)
                .IsUnicode(false);

            e.Property(x => x.IsActive)
                .IsRequired();
        });
        b.Entity<ParameterDefinitionMaster>(e => {
            e.ToTable("ParameterDefinitionMaster");

            e.HasKey(x => x.ParameterDefinitionMasterId);

            e.Property(x => x.ParameterCode)
                .HasMaxLength(128)
                .IsUnicode(false)
                .IsRequired();

            e.Property(x => x.ParameterName)
                .HasMaxLength(256)
                .IsUnicode(false)
                .IsRequired();

            e.Property(x => x.WhyItMatters)
                .HasMaxLength(2000)
                .IsUnicode(false);

            e.Property(x => x.HowDoWeMeasure)
                .HasMaxLength(2000)
                .IsUnicode(false);
        });
        b.Entity<WorkflowJsonVersion>(e =>
        {
            e.ToTable("WorkflowJsonVersion");

            e.HasKey(x => x.WorkflowJsonVersionId);

            e.Property(x => x.WorkflowJsonVersionId)
                .ValueGeneratedOnAdd();

            e.Property(x => x.IndustryDetailsId)
                .IsRequired();

            e.Property(x => x.WorkflowCode)
                .HasMaxLength(128)
                .IsUnicode(false)
                .IsRequired();

            e.Property(x => x.WorkflowName)
                .HasMaxLength(256)
                .IsUnicode(false)
                .IsRequired();

            e.Property(x => x.VersionNo)
                .IsRequired();

            e.Property(x => x.JsonContent)
                .HasColumnType("varchar(max)")
                .IsRequired();

            e.Property(x => x.VersionName)
                .HasMaxLength(128)
                .IsUnicode(false)
                .IsRequired();

            e.Property(x => x.Status)
                .HasMaxLength(30)
                .IsUnicode(false)
                .IsRequired();

            e.Property(x => x.IsPublished)
                .IsRequired();

            // IMPORTANT:
            // Explicitly bind the existing navigation properties
            // to IndustryDetailsId.
            e.HasOne(x => x.IndustryDetails)
                .WithMany(x => x.WorkflowJsonVersions)
                .HasForeignKey(x => x.IndustryDetailsId)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasIndex(x => new
            {
                x.WorkflowCode,
                x.VersionNo,
                x.IndustryDetailsId
            }).IsUnique();
        });
        b.Entity<IndustryParameterMapping>(e => {
            e.ToTable("IndustryParameterMapping");

            e.HasKey(x => x.IndustryParameterMappingId);

            e.Property(x => x.ParameterDisplayName)
                .HasMaxLength(512)
                .IsUnicode(false);

            e.Property(x => x.ValueType)
                .HasMaxLength(128)
                .IsUnicode(false);

            e.Property(x => x.Weight)
                .HasPrecision(10, 2);

            e.Property(x => x.DisplayOrder)
                .HasDefaultValue(99);

            e.Property(x => x.StepName)
                .HasMaxLength(50)
                .IsUnicode(false);

            e.Property(x => x.ControlType)
                .HasMaxLength(50)
                .IsUnicode(false);

            e.Property(x => x.SectionName)
                .HasMaxLength(256)
                .IsUnicode(false);

            e.Property(x => x.OptionsSource)
                .HasMaxLength(64)
                .IsUnicode(false);

            e.HasOne<WorkflowJsonVersion>()
                .WithMany()
                .HasForeignKey(x => x.WorkflowJsonVersionId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne<IndustryDetails>()
                .WithMany()
                .HasForeignKey(x => x.IndustryDetailsId)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasIndex(x => new { x.WorkflowJsonVersionId, x.IndustryDetailsId, x.ParameterDefinitionMasterId })
                    .IsUnique();

            e.HasOne<ParameterDefinitionMaster>()
                .WithMany()
                .HasForeignKey(x => x.ParameterDefinitionMasterId)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasOne<IndustryParameterMapping>()
                .WithMany()
                .HasForeignKey(x => x.ParentIndustryParameterMappingId)
                .OnDelete(DeleteBehavior.Restrict);

        });

        b.Entity<ValidationDefinition>(e => {
            e.ToTable("ValidationDefinition");

            e.HasKey(x => x.ValidationDefinitionId);

            e.Property(x => x.ValidationName)
                .HasMaxLength(128)
                .IsUnicode(false);

            e.Property(x => x.Expression)
                .HasColumnType("varchar(max)");

            e.Property(x => x.ErrorMessage)
                .HasMaxLength(256)
                .IsUnicode(false);

            e.HasOne<IndustryParameterMapping>()
                .WithMany()
                .HasForeignKey(x => x.IndustryParameterMappingId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<RuleDefinition>(e => {
            e.ToTable("RuleDefinition");

            e.HasKey(x => x.RuleDefinitionId);

            e.Property(x => x.RuleName)
                .HasMaxLength(128)
                .IsUnicode(false);
            e.Property(x => x.RuleExpressionType)
                .HasMaxLength(128)
                .IsUnicode(false);
            e.Property(x => x.OutputExpression)
                .HasMaxLength(2000)
                .IsUnicode(false);
            e.Property(x => x.Expression)
                .HasMaxLength(2000)
                .IsUnicode(false);
            e.HasOne<WorkflowJsonVersion>()
                .WithMany()
                .HasForeignKey(x => x.WorkflowJsonVersionId)
                .OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<ScaleConfiguration>(e => {
            e.ToTable("ScaleConfiguration");

            e.HasKey(x => x.ScaleConfigurationId);

            e.Property(x => x.ScaleCode)
                .HasMaxLength(128)
                .IsUnicode(false);
            e.Property(x => x.ScaleName)
                .HasMaxLength(256)
                .IsUnicode(false);
            e.Property(x => x.MinValue)
                .HasPrecision(10, 2);
            e.Property(x => x.MaxValue)
                .HasPrecision(10, 2);
        });
        b.Entity<ScaleConfigurationDetails>(e => {
            e.ToTable("ScaleConfigurationDetails");

            e.HasKey(x => x.ScaleConfigurationDetailsId);

            e.Property(x => x.ScoreValue)
                .HasMaxLength(256)
                .IsUnicode(false)
                .IsRequired();

            e.Property(x => x.Definition)
                .HasColumnType("nvarchar(max)")
                .IsRequired();

            e.Property(x => x.MinValue).HasPrecision(10, 2);

            e.Property(x => x.MaxValue).HasPrecision(10, 2);

            e.HasOne<IndustryParameterMapping>()
                .WithMany()
                .HasForeignKey(x => x.IndustryParameterMappingId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne<ScaleConfiguration>()
                .WithMany()
                .HasForeignKey(x => x.ScaleConfigurationId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<AssessmentResponse>(e => {
            e.ToTable("AssessmentResponse");

            e.HasKey(x => x.AssessmentResponseId);

            e.Property(x => x.ResponseJson)
                .HasColumnType("nvarchar(max)")
                .IsRequired();
            e.Property(x => x.Status)
                .HasMaxLength(30)
                .IsUnicode(false);
            e.HasOne(x => x.CustomerMaster)
                .WithMany()
                .HasForeignKey(x => x.EntityId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.WorkflowJsonVersion)
                .WithMany()
                .HasForeignKey(x => x.WorkflowJsonVersionId)
                .OnDelete(DeleteBehavior.Restrict);
            e.HasIndex(x => new {
                x.EntityId,
                x.WorkflowJsonVersionId
            });
        });

        b.Entity<FrameworkGeneral>(e =>
        {
            e.ToTable("FrameworkGeneral");

            e.HasKey(x => x.FrameworkGeneralId);

            e.Property(x => x.ParentType)
                .HasMaxLength(100)
                .IsUnicode(false);

            e.Property(x => x.CreatedOn)
                .HasDefaultValueSql("SYSUTCDATETIME()");

            e.HasIndex(x => x.AssessmentResponseId)
                .IsUnique();

            e.HasOne(x => x.AssessmentResponse)
                .WithMany()
                .HasForeignKey(x => x.AssessmentResponseId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.CustomerMaster)
                .WithMany()
                .HasForeignKey(x => x.EntityId)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasOne(x => x.WorkflowJsonVersion)
                .WithMany()
                .HasForeignKey(x => x.WorkflowJsonVersionId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<ParameterFieldDefinition>(e =>
        {
            e.ToTable("ParameterFieldDefinition");

            e.HasKey(x =>
                x.ParameterFieldDefinitionId);

            e.Property(x => x.FieldName)
                .HasMaxLength(2000)
                .IsUnicode(false)
                .IsRequired();

            e.Property(x => x.FieldType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .IsRequired();

            e.Property(x => x.FieldCode)
                .HasMaxLength(100)
                .IsUnicode(false);

            e.Property(x => x.SectionName)
                .HasMaxLength(300)
                .IsUnicode(false);

            e.Property(x => x.SourceType)
                .HasMaxLength(20)
                .IsUnicode(false);

            e.Property(x => x.SpreadRows)
                .HasMaxLength(200)
                .IsUnicode(false);

            e.Property(x => x.ResultRole)
                .HasMaxLength(20)
                .IsUnicode(false);

            e.HasOne(x =>
                    x.IndustryParameterMapping)
                .WithMany(x =>
                    x.ParameterFieldDefinitions)
                .HasForeignKey(
                    x => x.IndustryParameterMappingId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<FrameworkParameterResponse>(e =>
        {
            e.ToTable("FrameworkParameterResponse");

            e.HasKey(x =>
                x.FrameworkParameterResponseId);

            e.Property(x => x.FieldValue)
                .HasColumnType("nvarchar(max)");

            e.Property(x => x.CreatedOn)
                .HasDefaultValueSql(
                    "GETDATE()");

            e.HasOne(x =>
                    x.AssessmentResponse)
                .WithMany()
                .HasForeignKey(
                    x => x.AssessmentResponseId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x =>
                    x.IndustryParameterMapping)
                .WithMany()
                .HasForeignKey(
                    x => x.IndustryParameterMappingId)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasOne(x =>
                    x.ParameterFieldDefinition)
                .WithMany()
                .HasForeignKey(
                    x => x.ParameterFieldDefinitionId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<FrameworkParameterScore>(e =>
        {
            e.ToTable("FrameworkParameterScore");

            e.HasKey(x =>
                x.FrameworkParameterScoreId);

            e.Property(x => x.CalculatedScore)
                .HasPrecision(10, 2);

            e.Property(x => x.MinAllowedScore)
                .HasPrecision(10, 2);

            e.Property(x => x.AnalystScore)
                .HasPrecision(10, 2);

            e.Property(x => x.ValueText)
                .HasMaxLength(256)
                .IsUnicode(false);

            e.HasIndex(x => new { x.AssessmentResponseId, x.IndustryParameterMappingId })
                .IsUnique();
        });

        b.Entity<RatingScale>(e =>
        {
            e.ToTable("RatingScale");

            e.HasKey(x => x.RatingScaleId);

            e.Property(x => x.RatingCode)
                .HasMaxLength(16)
                .IsUnicode(false)
                .IsRequired();

            e.HasIndex(x => x.RatingCode)
                .IsUnique();
            e.Property(x => x.PgWeight).HasPrecision(18, 15);
            e.Property(x => x.Year1Weight).HasPrecision(18, 7);
        });

        b.Entity<FrameworkOutputDetails>(e =>
        {
            e.ToTable("FrameworkOutputDetails");
            e.HasKey(x => x.FrameworkOutputDetailsId);
            e.Property(x => x.ValueNumber).HasPrecision(18, 4);
            e.Property(x => x.ValueText).HasMaxLength(256).IsUnicode(false);
            e.Property(x => x.ValueNumberProj).HasPrecision(18, 4);
            e.Property(x => x.ValueTextProj).HasMaxLength(256).IsUnicode(false);
            e.Property(x => x.CalculatedBy).HasMaxLength(100).IsUnicode(false).IsRequired();
            e.HasIndex(x => new { x.AssessmentResponseId, x.IndustryParameterMappingId }).IsUnique();
        });
        b.Entity<RatingMatrix>(e =>
        {
            e.ToTable("RatingMatrix");
            e.HasKey(x => x.RatingMatrixId);
            e.Property(x => x.MatrixCode).HasMaxLength(40).IsUnicode(false).IsRequired();
            e.Property(x => x.RowValue).HasMaxLength(40).IsUnicode(false).IsRequired();
            e.Property(x => x.ColumnValue).HasMaxLength(40).IsUnicode(false).IsRequired();
            e.Property(x => x.Value).HasPrecision(9, 4);
            e.HasIndex(x => new { x.WorkflowJsonVersionId, x.MatrixCode, x.RowValue, x.ColumnValue }).IsUnique();
        });
        b.Entity<RatingBand>(e =>
        {
            e.ToTable("RatingBand");
            e.HasKey(x => x.RatingBandId);
            e.Property(x => x.BandCode).HasMaxLength(40).IsUnicode(false).IsRequired();
            e.Property(x => x.BandValue).HasMaxLength(16).IsUnicode(false).IsRequired();
            e.Property(x => x.MinValue).HasPrecision(18, 6);
            e.Property(x => x.MaxValue).HasPrecision(18, 6);
            e.HasIndex(x => new { x.WorkflowJsonVersionId, x.BandCode, x.BandValue }).IsUnique();
        });
    }
}