﻿using CRISP.Application.DTOs.CRF.Framework;

namespace CRISP.Web.Services.CRF.Framework
{
    public class OtherApiClient
    {
        private readonly IHttpClientFactory _factory;
        private readonly IReadOnlyList<string> _baseUrls;
        public OtherApiClient(IHttpClientFactory factory, IReadOnlyList<string> baseUrls)
        {
            _factory = factory;

            _baseUrls = baseUrls
                .Where(x =>
                    !string.IsNullOrWhiteSpace(x))
                .Select(x =>
                    x.EndsWith("/")
                        ? x
                        : x + "/")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private async Task<T?> GetAsync<T>(
            string relativeUrl,
            CancellationToken ct = default)
        {
            Exception? last = null;

            foreach (var baseUrl in _baseUrls)
            {
                try
                {
                    var client =
                        _factory.CreateClient(
                            "CRISP.Api");

                    client.BaseAddress =
                        new Uri(baseUrl);

                    using var response =
                        await client.GetAsync(
                            relativeUrl,
                            ct);

                    if (response.IsSuccessStatusCode)
                    {
                        return await response.Content
                            .ReadFromJsonAsync<T>(
                                cancellationToken: ct);
                    }

                    var body =
                        await response.Content
                            .ReadAsStringAsync(ct);

                    throw new HttpRequestException(
                        $"API Error : {(int)response.StatusCode} - {body}");
                }
                catch (Exception ex)
                {
                    last = ex;
                }
            }

            throw last ??
                  new HttpRequestException(
                      "No configured API endpoint is reachable.");
        }

        private async Task PostAsync(
            string relativeUrl,
            object request,
            CancellationToken ct = default)
        {
            Exception? last = null;

            foreach (var baseUrl in _baseUrls)
            {
                try
                {
                    var client =
                        _factory.CreateClient(
                            "CRISP.Api");

                    client.BaseAddress =
                        new Uri(baseUrl);

                    using var response =
                        await client.PostAsJsonAsync(
                            relativeUrl,
                            request,
                            ct);

                    if (response.IsSuccessStatusCode)
                        return;

                    var body =
                        await response.Content
                            .ReadAsStringAsync(ct);

                    throw new HttpRequestException(
                        $"API Error : {(int)response.StatusCode} - {body}");
                }
                catch (Exception ex)
                {
                    last = ex;
                }
            }

            throw last ?? new HttpRequestException("No configured API endpoint is reachable.");
        }

        private async Task<T?> PostForAsync<T>(
            string relativeUrl,
            object request,
            CancellationToken ct = default)
        {
            Exception? last = null;

            foreach (var baseUrl in _baseUrls)
            {
                try
                {
                    var client =
                        _factory.CreateClient(
                            "CRISP.Api");

                    client.BaseAddress =
                        new Uri(baseUrl);

                    using var response =
                        await client.PostAsJsonAsync(
                            relativeUrl,
                            request,
                            ct);

                    if (response.IsSuccessStatusCode)
                    {
                        if (response.Content.Headers.ContentLength is 0)
                            return default;

                        return await response.Content
                            .ReadFromJsonAsync<T>(
                                cancellationToken: ct);
                    }

                    var body =
                        await response.Content
                            .ReadAsStringAsync(ct);

                    // validation / calculation message from the API: show it as it is
                    if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
                        throw new InvalidOperationException(body.Trim('"'));

                    throw new HttpRequestException(
                        $"API Error : {(int)response.StatusCode} - {body}");
                }
                catch (InvalidOperationException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    last = ex;
                }
            }

            throw last ?? new HttpRequestException("No configured API endpoint is reachable.");
        }

        public async Task<List<OtherTabDto>?>
            GetOthersAsync(
                int workflowJsonVersionId,
                int assessmentResponseId,
                CancellationToken ct = default)
        {
            return await GetAsync<List<OtherTabDto>>
            (
                $"api/others?workflowJsonVersionId={workflowJsonVersionId}&assessmentResponseId={assessmentResponseId}",
                ct
            );
        }

        // Parent/Group tab: same rows and save as Others, for the "ParentGroup" step
        public async Task<List<OtherTabDto>?>
            GetParentGroupAsync(
                int workflowJsonVersionId,
                int assessmentResponseId,
                CancellationToken ct = default)
        {
            return await GetAsync<List<OtherTabDto>>
            (
                $"api/others?workflowJsonVersionId={workflowJsonVersionId}&assessmentResponseId={assessmentResponseId}&stepName=ParentGroup",
                ct
            );
        }

        // weighted score, uplift rows and unanswered rows (from the saved answers)
        public Task<ParentGroupResultDto?> CalculateParentGroupAsync(
            int workflowJsonVersionId,
            int assessmentResponseId,
            CancellationToken ct = default) =>
            PostForAsync<ParentGroupResultDto>(
                "api/others/parent-group/calculate",
                new ParentGroupCalculateRequestDto
                {
                    WorkflowJsonVersionId = workflowJsonVersionId,
                    AssessmentResponseId = assessmentResponseId
                },
                ct);

        public async Task<PopupDto?>
            GetPopupAsync(
                int industryParameterMappingId,
                int assessmentResponseId,
                CancellationToken ct = default)
        {
            // GET has no body: use the same message handling as the POST calls
            var client =
                _factory.CreateClient(
                    "CRISP.Api");

            client.BaseAddress =
                new Uri(_baseUrls.FirstOrDefault() ?? throw new HttpRequestException("No configured API endpoint."));

            using var response =
                await client.GetAsync(
                    $"api/others/{industryParameterMappingId}/popup?assessmentResponseId={assessmentResponseId}",
                    ct);

            if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
                throw new InvalidOperationException((await response.Content.ReadAsStringAsync(ct)).Trim('"'));

            response.EnsureSuccessStatusCode();

            return await response.Content.ReadFromJsonAsync<PopupDto>(cancellationToken: ct);
        }

        // ---------------------------------------------------------- admin: parameter configuration

        public async Task<ParameterConfigDto?>
            GetParameterConfigAsync(
                int industryParameterMappingId,
                CancellationToken ct = default)
        {
            var client =
                _factory.CreateClient(
                    "CRISP.Api");

            client.BaseAddress =
                new Uri(_baseUrls.FirstOrDefault() ?? throw new HttpRequestException("No configured API endpoint."));

            using var response =
                await client.GetAsync(
                    $"api/parameter-config/{industryParameterMappingId}",
                    ct);

            if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
                throw new InvalidOperationException((await response.Content.ReadAsStringAsync(ct)).Trim('"'));

            response.EnsureSuccessStatusCode();

            return await response.Content.ReadFromJsonAsync<ParameterConfigDto>(cancellationToken: ct);
        }

        public Task<List<RelatedParameterDto>?>
            GetCopySourcesAsync(
                int industryParameterMappingId,
                CancellationToken ct = default) =>
            GetAsync<List<RelatedParameterDto>>($"api/parameter-config/{industryParameterMappingId}/copy-sources", ct);

        public Task<ParameterConfigCheckDto?>
            CheckParameterConfigAsync(
                SaveParameterConfigRequest request,
                CancellationToken ct = default) =>
            PostForAsync<ParameterConfigCheckDto>("api/parameter-config/check", request, ct);

        public Task<ParameterConfigTryDto?>
            TryParameterConfigAsync(
                ParameterConfigTryRequest request,
                CancellationToken ct = default) =>
            PostForAsync<ParameterConfigTryDto>("api/parameter-config/try", request, ct);

        public Task<ParameterConfigDto?>
            SaveParameterConfigAsync(
                SaveParameterConfigRequest request,
                CancellationToken ct = default) =>
            PostForAsync<ParameterConfigDto>("api/parameter-config", request, ct);

        public Task<PopupDto?>
            CalculatePopupAsync(
                SavePopupRequestDto request,
                CancellationToken ct = default) =>
            PostForAsync<PopupDto>("api/others/popup/calculate", request, ct);

        public Task<PopupDto?>
            SavePopupAsync(
                SavePopupRequestDto request,
                CancellationToken ct = default) =>
            PostForAsync<PopupDto>("api/others/popup", request, ct);

        public async Task
            SaveScoresAsync(
                SaveOtherScoresRequestDto request,
                CancellationToken ct = default)
        {
            await PostForAsync<object>("api/others/scores", request, ct);
        }

        public async Task<List<OtherModuleDto>?>
            GetModulesAsync(
                int parentIndustryParameterMappingId,
                CancellationToken ct = default)
        {
            return await GetAsync<List<OtherModuleDto>>
            (
                $"api/others/{parentIndustryParameterMappingId}/children",
                ct
            );
        }

        public async Task<List<OtherFieldDto>?>
            GetFieldsAsync(
                int industryParameterMappingId,
                int assessmentResponseId,
                CancellationToken ct = default)
        {
            return await GetAsync<List<OtherFieldDto>>
            (
                $"api/others/{industryParameterMappingId}/fields?assessmentResponseId={assessmentResponseId}",
                ct
            );
        }

        public async Task SaveAsync(
            SaveOtherTabRequestDto request,
            CancellationToken ct = default)
        {
            await PostAsync("api/others",
                request,
                ct);
        }

    }
}