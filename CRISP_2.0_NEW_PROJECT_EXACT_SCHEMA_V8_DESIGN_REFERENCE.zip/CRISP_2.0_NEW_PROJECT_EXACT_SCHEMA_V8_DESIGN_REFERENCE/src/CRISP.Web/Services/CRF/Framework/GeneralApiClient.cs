﻿using CRISP.Application.DTOs.CRF.Framework;

namespace CRISP.Web.Services.CRF.Framework
{
    public class GeneralApiClient
    {
        private readonly IHttpClientFactory _factory;
        private readonly IReadOnlyList<string> _baseUrls;
        public GeneralApiClient(
            IHttpClientFactory factory,
            IReadOnlyList<string> baseUrls)
        {
            _factory = factory;

            _baseUrls = baseUrls
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.EndsWith("/")
                    ? x
                    : x + "/")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private async Task<T?> GetAsync<T>(
            string relativeUrl,
            CancellationToken ct = default)
        {
            Exception? last = null;

            foreach (var baseUrl in _baseUrls)
            {
                try
                {
                    var client =
                        _factory.CreateClient("CRISP.Api");

                    client.BaseAddress =
                        new Uri(baseUrl);

                    using var response =
                        await client.GetAsync(
                            relativeUrl,
                            ct);

                    if (response.IsSuccessStatusCode)
                    {
                        return await response.Content
                            .ReadFromJsonAsync<T>(
                                cancellationToken: ct);
                    }

                    var body =
                        await response.Content
                            .ReadAsStringAsync(ct);

                    throw new HttpRequestException(
                        $"API Error : {(int)response.StatusCode} - {body}");
                }
                catch (Exception ex)
                {
                    last = ex;
                }
            }

            throw last ??
                  new HttpRequestException(
                      "No configured API endpoint is reachable.");
        }

        private async Task<T?> PostAsync<T>(
            string relativeUrl,
            object request,
            CancellationToken ct = default)
        {
            Exception? last = null;

            foreach (var baseUrl in _baseUrls)
            {
                try
                {
                    var client =
                        _factory.CreateClient("CRISP.Api");

                    client.BaseAddress =
                        new Uri(baseUrl);

                    using var response =
                        await client.PostAsJsonAsync(
                            relativeUrl,
                            request,
                            ct);

                    if (response.IsSuccessStatusCode)
                    {
                        return await response.Content
                            .ReadFromJsonAsync<T>(
                                cancellationToken: ct);
                    }

                    var body =
                        await response.Content
                            .ReadAsStringAsync(ct);

                    throw new HttpRequestException(
                        $"API Error : {(int)response.StatusCode} - {body}");
                }
                catch (Exception ex)
                {
                    last = ex;
                }
            }

            throw last ??
                  new HttpRequestException(
                      "No configured API endpoint is reachable.");
        }

        public async Task<GeneralDto?>
        GetGeneralAsync(
            int assessmentResponseId,
            CancellationToken ct = default)
        {
            return await GetAsync<GeneralDto>(
                $"api/general/{assessmentResponseId}",
                ct);
        }

        public async Task<GeneralDto?>
        SaveGeneralAsync(
            GeneralDto request,
            CancellationToken ct = default)
        {
            return await PostAsync<GeneralDto>(
                "api/general",
                request,
                ct);
        }

    }
}