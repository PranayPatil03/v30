﻿using System.Net.Http.Json;
using CRISP.Application.DTOs;
using CRISP.Application.DTOs.CRF.Framework;
namespace CRISP.Web.Services.CRF.Framework
{
    // Output tab API (same base-URL fallback as OtherApiClient)
    public class OutputApiClient
    {
        private readonly IHttpClientFactory _factory;
        private readonly IReadOnlyList<string> _baseUrls;
        public OutputApiClient(IHttpClientFactory factory, IReadOnlyList<string> baseUrls)
        {
            _factory = factory;
            _baseUrls = baseUrls
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.EndsWith('/') ? x : x + "/")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
        }
        public Task<FrameworkOutputDto?> GetAsync(int assessmentResponseId, CancellationToken ct = default) =>
            SendAsync<FrameworkOutputDto>(c => c.GetAsync($"api/output/{assessmentResponseId}", ct), ct);
        public Task<List<TabErrorsDto>?> ValidateAsync(int assessmentResponseId, CancellationToken ct = default) =>
            SendAsync<List<TabErrorsDto>>(c => c.GetAsync($"api/output/{assessmentResponseId}/validate", ct), ct);
        public Task<RunOutputResultDto?> RunAsync(int assessmentResponseId, EvaluateRequest business, CancellationToken ct =
default) =>
            SendAsync<RunOutputResultDto>(c => c.PostAsJsonAsync($"api/output/{assessmentResponseId}/run",
                new RunOutputRequestDto { Business = business }, ct), ct);
        public Task SaveRatingsAsync(SaveOutputRatingsRequestDto request, CancellationToken ct = default) =>
            SendAsync<object>(c => c.PutAsJsonAsync("api/output/ratings", request, ct), ct, readBody: false);
        private async Task<T?> SendAsync<T>(
            Func<HttpClient, Task<HttpResponseMessage>> send,
            CancellationToken ct,
            bool readBody = true)
        {
            Exception? last = null;
            foreach (var baseUrl in _baseUrls)
            {
                try
                {
                    var client = _factory.CreateClient("CRISP.Api");
                    client.BaseAddress = new Uri(baseUrl);
                    using var response = await send(client);
                    if (response.IsSuccessStatusCode)
                        return readBody ? await response.Content.ReadFromJsonAsync<T>(cancellationToken: ct) : default;
                    // the API returns a short message; never show a stack trace
                    throw new HttpRequestException($"API Error : {(int)response.StatusCode}");
                }
                catch (Exception ex) when (ex is not OperationCanceledException)
                {
                    last = ex;
                }
            }
            throw last ?? new HttpRequestException("No configured API endpoint is reachable.");
        }
    }
}