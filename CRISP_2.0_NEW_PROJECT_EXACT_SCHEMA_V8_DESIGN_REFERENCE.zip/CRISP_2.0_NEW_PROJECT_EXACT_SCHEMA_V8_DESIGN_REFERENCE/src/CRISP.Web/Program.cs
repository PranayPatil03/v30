using CRISP.Web.Components;
using CRISP.Web.Services;
using CRISP.Web.Services.CRF.Framework;
using MudBlazor.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddMudServices();

var apiUrls =
    builder.Configuration.GetSection("ApiBaseUrls").Get<string[]>() ?? [];

if (apiUrls.Length == 0)
{
    var single = builder.Configuration["ApiBaseUrl"];

    if (!string.IsNullOrWhiteSpace(single))
        apiUrls = [single];
}

if (apiUrls.Length == 0)
    apiUrls = ["https://localhost:44395/"];

builder.Services.AddHttpClient("CRISP.Api", client =>
{
    client.Timeout = TimeSpan.FromSeconds(8);
});

builder.Services.AddScoped(sp =>
    new FrameworkApiClient(
        sp.GetRequiredService<IHttpClientFactory>(), apiUrls));

builder.Services.AddScoped(sp =>
    new GeneralApiClient(
        sp.GetRequiredService<IHttpClientFactory>(), apiUrls));

builder.Services.AddScoped(sp =>
    new OtherApiClient(
        sp.GetRequiredService<IHttpClientFactory>(), apiUrls));

builder.Services.AddScoped(sp =>
    new OutputApiClient(
        sp.GetRequiredService<IHttpClientFactory>(), apiUrls));

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseAntiforgery();
app.MapStaticAssets();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();