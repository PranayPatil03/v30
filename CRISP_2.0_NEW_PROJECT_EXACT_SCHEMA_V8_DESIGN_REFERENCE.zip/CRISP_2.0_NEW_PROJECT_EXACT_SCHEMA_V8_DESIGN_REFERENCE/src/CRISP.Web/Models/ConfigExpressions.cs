﻿using System.Text;
using System.Text.RegularExpressions;

namespace CRISP.Web.Models
{
    /*
    * Helpers of the Parameter Configuration page, so admins do not need to know the expression syntax:
    *   Readable   formula / condition in words, with field labels instead of codes
    *   Unknown    field codes that do not exist (checked while typing)
    *   Parse      simple conditions (A > 0 && B == "Yes") into rows of the rule builder, and back with Build
    */
    public static class ConfigExpressions
    {
        private static readonly Regex Identifier = new(@"(?<![\w.""])[A-Za-z_][A-Za-z0-9_]*\b", RegexOptions.Compiled);
        private static readonly Regex Strings = new(@"""[^""]*""", RegexOptions.Compiled);

        private static readonly HashSet<string> Keywords = new(StringComparer.OrdinalIgnoreCase)
        {
            "Math", "true", "false", "null", "and", "or", "not"
        };

        public static readonly (string Op, string Words)[] Operators =
        [
            (">", "is more than"),
            (">=", "is at least"),
            ("<", "is less than"),
            ("<=", "is at most"),
            ("==", "equals"),
            ("!=", "is not")
        ];

        public static string OperatorWords(string op) =>
            Operators.FirstOrDefault(x => x.Op == op).Words ?? op;

        // codes used in an expression (text in quotes and Math.Max etc. are skipped)
        public static IEnumerable<string> Codes(string? expression)
        {
            if (string.IsNullOrWhiteSpace(expression))
                yield break;

            var withoutText = Strings.Replace(expression, "\"\"");
            foreach (Match m in Identifier.Matches(withoutText))
            {
                if (!Keywords.Contains(m.Value))
                    yield return m.Value;
            }
        }

        public static List<string> Unknown(string? expression, ISet<string> known) =>
            Codes(expression).Where(c => !known.Contains(c)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

        // 0.02 -> 0.02m: decimal numbers must carry the m suffix for the rule engine
        public static string? FixNumbers(string? expression) =>
            expression is null
                ? null
                : Regex.Replace(expression, @"(?<![\w.""])(\d+\.\d+)(?![\d.mMdDfF])", "$1m");

        // CFO + CASH_BEGIN - Math.Max(A, 0) -> [Cash flow] + [Cash at beginning] - larger of ([A], 0)
        public static string Readable(string? expression, Func<string, string?> label)
        {
            if (string.IsNullOrWhiteSpace(expression))
                return string.Empty;

            var text = expression
                .Replace("Math.Max", "larger of ")
                .Replace("Math.Min", "smaller of ")
                .Replace("Math.Abs", "positive value of ")
                .Replace("Math.Round", "rounded ")
                .Replace("&&", " and ")
                .Replace("||", " or ")
                .Replace(">=", " ≥ ")
                .Replace("<=", " ≤ ")
                .Replace("!=", " ≠ ")
                .Replace("==", " = ");

            text = Regex.Replace(text, @"(?<![\w.])(\d+(?:\.\d+)?)[mM]\b", "$1");
            text = Identifier.Replace(text, m =>
            {
                if (Keywords.Contains(m.Value) || m.Value is "larger" or "smaller" or "of" or "positive" or "value" or "rounded")
                    return m.Value;

                var year = Regex.Match(m.Value, @"^(.+)_Y(\d+)$");
                if (year.Success && label(year.Groups[1].Value) is { } yearLabel)
                    return $"[{yearLabel}, year {year.Groups[2].Value}]";

                return $"[{label(m.Value) ?? m.Value}]";
            });

            return Regex.Replace(text, @"\s+", " ").Trim();
        }

        // ------------------------------------------------------------------ rule builder

        public sealed class Clause
        {
            public string Left { get; set; } = string.Empty;

            public string Op { get; set; } = ">";

            public string Right { get; set; } = string.Empty;
        }

        public sealed class Condition
        {
            // true: all clauses (and), false: any clause (or)
            public bool All { get; set; } = true;

            public List<Clause> Clauses { get; set; } = [];
        }

        // null = too complex for the builder (mixed and / or, brackets around conditions ...)
        public static Condition? Parse(string? expression)
        {
            var condition = new Condition();
            if (string.IsNullOrWhiteSpace(expression) || expression.Trim() == "true")
                return condition;

            var parts = SplitTopLevel(expression, out var joiners);
            if (parts is null || joiners.Distinct().Count() > 1)
                return null;

            condition.All = joiners.Count == 0 || joiners[0] == "&&";

            foreach (var part in parts)
            {
                var clause = ParseClause(part.Trim());
                if (clause is null)
                    return null;
                condition.Clauses.Add(clause);
            }

            return condition;
        }

        public static string Build(Condition condition, ISet<string> knownCodes)
        {
            var clauses = condition.Clauses
                .Where(c => !string.IsNullOrWhiteSpace(c.Left) && !string.IsNullOrWhiteSpace(c.Right))
                .Select(c => $"{FixNumbers(c.Left.Trim())} {c.Op} {RightSide(c.Right.Trim(), knownCodes)}")
                .ToList();

            return string.Join(condition.All ? " && " : " || ", clauses);
        }

        // a number, a field / calculation, or a text that needs quotes
        private static string RightSide(string value, ISet<string> knownCodes)
        {
            if (value.StartsWith('"') && value.EndsWith('"') && value.Length > 1)
                return value;

            if (value is "true" or "false")
                return value;

            if (decimal.TryParse(value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out _))
                return value.Contains('.') ? value + "m" : value;

            if (Codes(value).Any(knownCodes.Contains) || Regex.IsMatch(value, @"[+\-*/()]"))
                return FixNumbers(value)!;

            return $"\"{value.Replace("\"", "")}\"";
        }

        private static Clause? ParseClause(string text)
        {
            var depth = 0;
            var inText = false;
            for (var i = 0; i < text.Length; i++)
            {
                var ch = text[i];
                if (ch == '"') inText = !inText;
                if (inText) continue;
                if (ch == '(') depth++;
                if (ch == ')') depth--;
                if (depth != 0) continue;

                foreach (var op in new[] { ">=", "<=", "==", "!=", ">", "<" })
                {
                    if (string.CompareOrdinal(text, i, op, 0, op.Length) != 0)
                        continue;

                    var left = text[..i].Trim();
                    var right = text[(i + op.Length)..].Trim();
                    if (left.Length == 0 || right.Length == 0 || HasComparison(right))
                        return null;

                    return new Clause
                    {
                        Left = Regex.Replace(left, @"(?<![\w.])(\d+(?:\.\d+)?)[mM]\b", "$1"),
                        Op = op,
                        // texts without quotes: Build adds them again
                        Right = right.Length > 1 && right.StartsWith('"') && right.EndsWith('"')
                            ? right[1..^1]
                            : Regex.Replace(right, @"^(\d+(?:\.\d+)?)[mM]$", "$1")
                    };
                }
            }

            return null;
        }

        private static bool HasComparison(string text) =>
            Regex.IsMatch(Strings.Replace(text, "\"\""), @"(==|!=|>=|<=|<|>)");

        private static List<string>? SplitTopLevel(string expression, out List<string> joiners)
        {
            joiners = [];
            var parts = new List<string>();
            var current = new StringBuilder();
            var depth = 0;
            var inText = false;

            for (var i = 0; i < expression.Length; i++)
            {
                var ch = expression[i];
                if (ch == '"') inText = !inText;

                if (!inText)
                {
                    if (ch == '(') depth++;
                    if (ch == ')') depth--;

                    if (i + 1 < expression.Length && (expression.Substring(i, 2) is "&&" or "||"))
                    {
                        // and / or inside brackets: too complex for the builder
                        if (depth != 0)
                            return null;

                        joiners.Add(expression.Substring(i, 2));
                        parts.Add(current.ToString());
                        current.Clear();
                        i++;
                        continue;
                    }
                }

                current.Append(ch);
            }

            parts.Add(current.ToString());
            return parts;
        }

        // label -> code: "Cash flow from operations" -> CASH_FLOW_FROM_OPERATIONS
        public static string CodeFromLabel(string? label, ISet<string> used)
        {
            var words = Regex.Matches((label ?? string.Empty).ToUpperInvariant(), "[A-Z0-9]+")
                .Select(m => m.Value)
                .Where(w => w.Length > 1 || char.IsDigit(w[0]))
                .Take(4)
                .ToList();

            var code = words.Count == 0 ? "FIELD" : string.Join("_", words);
            if (code.Length > 30)
                code = code[..30].TrimEnd('_');
            if (char.IsDigit(code[0]))
                code = "F_" + code;

            var result = code;
            for (var n = 2; used.Contains(result); n++)
                result = $"{code}_{n}";

            return result;
        }
    }

}
