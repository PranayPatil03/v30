using CRISP.Application.Interfaces;
using CRISP.Application.Interfaces.IServices.CRF.Framework;
using CRISP.Application.Services;
using CRISP.Application.Services.CRF.Framework;
using CRISP.Infrastructure.DependencyInjection;
using CRISP.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<CrispDbContext>(options =>
options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddInfrastructure();

builder.Services.AddScoped<IFrameworkService, FrameworkService>();

builder.Services.AddScoped<IGeneralService, GeneralService>();

builder.Services.AddScoped<PopupCalculator>();
builder.Services.AddScoped<ParentGroupCalculator>();

builder.Services.AddScoped<IOtherService, OtherService>();

builder.Services.AddScoped<IParameterConfigService, ParameterConfigService>();

builder.Services.AddScoped<IRuleEvaluationService, RuleEvaluationService>();

// Output tab (FinancialRiskCalculator and RatingChainCalculator are static / created per run: no registration)
builder.Services.AddScoped<IFrameworkValidationService, FrameworkValidationService>();
builder.Services.AddScoped<CalculatedRowRunner>();
builder.Services.AddScoped<IFinancialRiskService, FinancialRiskNotConfiguredService>();
builder.Services.AddScoped<OutputCalculator>();
builder.Services.AddScoped<IOutputService, OutputService>();

builder.Services.AddCors(options => options.AddPolicy("web", policy =>
policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));
var app = builder.Build();

app.UseCors("web");

app.UseSwagger();

app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "CRISP API v1");
    options.RoutePrefix = "swagger";
});
app.MapControllers();

app.Run();