﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Application.Interfaces.IServices.CRF.Framework;
using Microsoft.AspNetCore.Mvc;

namespace CRISP.Api.Controllers.CRF.Framework
{

    [ApiController]
    [Route("api/general")]
    public class GeneralController : Controller
    {
        private readonly IGeneralService _generalService;

        public GeneralController(
            IGeneralService generalService)
        {
            _generalService = generalService;
        }

        [HttpGet("{assessmentResponseId:int}")]
        public async Task<ActionResult<GeneralDto>> Get(
            int assessmentResponseId,
            CancellationToken ct)
        {
            var result =
                await _generalService.GetAsync(
                    assessmentResponseId,
                    ct);

            return Ok(result);

        }

        [HttpPost]
        public async Task<ActionResult<GeneralDto>> Save(
            [FromBody] GeneralDto request,
            CancellationToken ct)
        {
            var result =
                await _generalService.SaveAsync(
                    request,
                    ct);

            return Ok(result);
        }

    }
}