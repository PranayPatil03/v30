﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Application.Interfaces.IServices.CRF.Framework;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace CRISP.Api.Controllers.CRF.Framework
{
    [ApiController]
    [Authorize]                                   // VAPT: no anonymous access (needs AddAuthentication, see Program.cs)
    [Route("api/output")]
    public class OutputController : ControllerBase
    {
        private readonly IOutputService _service;
        private readonly IFrameworkValidationService _validation;
        public OutputController(IOutputService service, IFrameworkValidationService validation)
        {
            _service = service;
            _validation = validation;
        }
        [HttpGet("{assessmentResponseId:int}")]
        public async Task<ActionResult<FrameworkOutputDto>> Get(int assessmentResponseId, CancellationToken ct)
            => Ok(await _service.GetAsync(assessmentResponseId, ct));
        [HttpGet("{assessmentResponseId:int}/validate")]
        public async Task<ActionResult<List<TabErrorsDto>>> Validate(int assessmentResponseId, CancellationToken ct)
            => Ok(await _validation.ValidateAsync(assessmentResponseId, ct));
        [HttpPost("{assessmentResponseId:int}/run")]
        public async Task<ActionResult<RunOutputResultDto>> Run(int assessmentResponseId, RunOutputRequestDto request,
CancellationToken ct)
        {
            var user = User.Identity?.Name;                // never from the request body
            if (string.IsNullOrWhiteSpace(user))
                return Unauthorized();
            return Ok(await _service.RunAsync(assessmentResponseId, request, user, ct));
        }
        [HttpPut("ratings")]
        public async Task<IActionResult> SaveRatings(SaveOutputRatingsRequestDto request, CancellationToken ct)
        {
            await _service.SaveRatingsAsync(request, ct);
            return NoContent();
        }
    }
}