﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Application.Interfaces.IServices.CRF.Framework;
using Microsoft.AspNetCore.Mvc;

namespace CRISP.Api.Controllers.CRF.Framework
{
    [ApiController]
    [Route("api/others")]
    public class OtherController : ControllerBase
    {
        private readonly IOtherService _service;
        public OtherController(IOtherService service)
        {
            _service = service;
        }

        // stepName: "Others" (default) or "ParentGroup"
        [HttpGet]
        public async Task<ActionResult<List<OtherTabDto>>> GetOthers(
                int workflowJsonVersionId,
                int assessmentResponseId,
                CancellationToken ct,
                string stepName = "Others")
        {
            var result =
                await _service.GetOtherTabsAsync(
                    workflowJsonVersionId,
                    assessmentResponseId,
                    stepName,
                    ct);

            return Ok(result);
        }

        [HttpGet("{parentIndustryParameterMappingId:int}/children")]
        public async Task<ActionResult<List<OtherModuleDto>>> GetChildren(
                int parentIndustryParameterMappingId,
                CancellationToken ct)
        {
            var result = await _service.GetModulesAsync(
                    parentIndustryParameterMappingId,
                    ct);

            return Ok(result);
        }

        [HttpGet("{industryParameterMappingId:int}/fields")]
        public async Task<ActionResult<List<OtherFieldDto>>> GetFields(
                int industryParameterMappingId,
                int assessmentResponseId,
                CancellationToken ct)
        {
            var result = await _service.GetFieldsAsync(
                    industryParameterMappingId,
                    assessmentResponseId,
                    ct);

            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> Save(
                SaveOtherTabRequestDto request,
                CancellationToken ct)
        {
            await _service.SaveAsync(
                request,
                ct);

            return Ok();
        }

        // popup with saved values + rule engine results (replaces GetLiquidityDetails)
        [HttpGet("{industryParameterMappingId:int}/popup")]
        public async Task<ActionResult<PopupDto>> GetPopup(
                int industryParameterMappingId,
                int assessmentResponseId,
                CancellationToken ct)
        {
            try
            {
                return Ok(await _service.GetPopupAsync(industryParameterMappingId, assessmentResponseId, ct));
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // recalculate with the values on screen, nothing is saved
        [HttpPost("popup/calculate")]
        public async Task<ActionResult<PopupDto>> CalculatePopup(
                SavePopupRequestDto request,
                CancellationToken ct)
        {
            try
            {
                return Ok(await _service.CalculatePopupAsync(request, ct));
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("popup")]
        public async Task<ActionResult<PopupDto>> SavePopup(
                SavePopupRequestDto request,
                CancellationToken ct)
        {
            try
            {
                return Ok(await _service.SavePopupAsync(request, ct));
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // Parent/Group tab: works out the weighted score and the Calculated rows (uplift) from the saved answers
        [HttpPost("parent-group/calculate")]
        public async Task<ActionResult<ParentGroupResultDto>> CalculateParentGroup(
                ParentGroupCalculateRequestDto request,
                CancellationToken ct)
        {
            try
            {
                return Ok(await _service.CalculateParentGroupAsync(request, ct));
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("scores")]
        public async Task<IActionResult> SaveScores(
                SaveOtherScoresRequestDto request,
                CancellationToken ct)
        {
            try
            {
                await _service.SaveScoresAsync(request, ct);
                return Ok();
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}