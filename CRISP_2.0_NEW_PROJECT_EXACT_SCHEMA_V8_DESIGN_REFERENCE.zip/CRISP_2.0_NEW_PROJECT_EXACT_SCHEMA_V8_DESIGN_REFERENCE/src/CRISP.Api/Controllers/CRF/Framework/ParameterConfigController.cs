﻿using CRISP.Application.DTOs.CRF.Framework;
using CRISP.Application.Interfaces.IServices.CRF.Framework;
using Microsoft.AspNetCore.Mvc;

namespace CRISP.Api.Controllers.CRF.Framework
{
    // admin: popup fields, popup score rules and Show Details texts of one mapped parameter
    [ApiController]
    [Route("api/parameter-config")]
    public class ParameterConfigController : ControllerBase
    {
        private readonly IParameterConfigService _service;
        public ParameterConfigController(IParameterConfigService service)
        {
            _service = service;
        }

        [HttpGet("{industryParameterMappingId:int}")]
        public async Task<ActionResult<ParameterConfigDto>> Get(
                int industryParameterMappingId,
                CancellationToken ct)
        {
            try
            {
                return Ok(await _service.GetAsync(industryParameterMappingId, ct));
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{industryParameterMappingId:int}/copy-sources")]
        public async Task<ActionResult<List<RelatedParameterDto>>> CopySources(
                int industryParameterMappingId,
                CancellationToken ct)
        {
            return Ok(await _service.GetCopySourcesAsync(industryParameterMappingId, ct));
        }

        [HttpPost("check")]
        public async Task<ActionResult<ParameterConfigCheckDto>> Check(
                SaveParameterConfigRequest request,
                CancellationToken ct)
        {
            try
            {
                return Ok(await _service.CheckAsync(request, ct));
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("try")]
        public async Task<ActionResult<ParameterConfigTryDto>> Try(
                ParameterConfigTryRequest request,
                CancellationToken ct)
        {
            try
            {
                return Ok(await _service.TryAsync(request, ct));
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<ActionResult<ParameterConfigDto>> Save(
                SaveParameterConfigRequest request,
                CancellationToken ct)
        {
            try
            {
                return Ok(await _service.SaveAsync(request, ct));
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}