/* ====================================================================================
   14_Financial_Risk_Setup.sql
   Financial risk (guide chapter 14A): legacy names for the Output table/codes, ratio definitions, year weights, per-assessment
   snapshot, the FR_* rows of a version and their bands (from FinancialParameterBenchmarkDetails,
   BenchmarkId 1). Safe to run again: only missing objects / rows are added. Draft version only.
   Note: ScaleConfigurationDetails.MinValue/MaxValue are DECIMAL(10,2), so open ends use +/-99999999.
   ==================================================================================== */
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* ------------------------------------------------------------------ PART 0: legacy names
   Scripts 12/13 created dbo.AssessmentOutput and the OUT_* codes. They get the names of the legacy
   procedures (GetFrameworkOutput / GetFrameworkOutputDetails): table FrameworkOutputDetails, codes =
   its rating columns. Runs once; nothing happens when the new names already exist. */
IF OBJECT_ID('dbo.AssessmentOutput', 'U') IS NOT NULL AND OBJECT_ID('dbo.FrameworkOutputDetails', 'U') IS NULL
BEGIN
    EXEC sp_rename 'dbo.AssessmentOutput', 'FrameworkOutputDetails';
    EXEC sp_rename 'dbo.FrameworkOutputDetails.AssessmentOutputId', 'FrameworkOutputDetailsId', 'COLUMN';

    DECLARE @sql NVARCHAR(MAX) = N'';
    SELECT @sql += N'EXEC sp_rename N''dbo.' + o.name + N''', N''' + REPLACE(o.name, 'AssessmentOutput', 'FrameworkOutputDetails') + N''', N''OBJECT'';'
    FROM sys.objects o
    WHERE o.parent_object_id = OBJECT_ID('dbo.FrameworkOutputDetails') AND o.name LIKE '%AssessmentOutput%';
    EXEC sys.sp_executesql @sql;
END;

UPDATE p SET ParameterCode = v.NewCode
FROM dbo.ParameterDefinitionMaster p
JOIN (VALUES
    ('OUT_INDUSTRY_RISK',       'IndustryRisk'),
    ('OUT_BUSINESS_RATING',     'BusinessRating'),
    ('OUT_ADJ_BUSINESS_RATING', 'AdjustedBusinessRating'),
    ('OUT_OPERATING_RATING',    'OverallOperatingRating'),
    ('OUT_FINANCIAL_RATING',    'FinancialRating'),
    ('OUT_BASE_RATING',         'BaseRating'),
    ('OUT_ADJ_DIVERSIFICATION', 'DiversificationRating'),
    ('OUT_ADJ_LIQUIDITY',       'LiquidityALMAndFinancialFlexibilityRating'),
    ('OUT_ADJ_FOREX',           'ForeignExchangeRiskRating'),
    ('OUT_ADJ_FIN_POLICY',      'FinancialPolicyRating'),
    ('OUT_ADJ_MG',              'ManagementAndGovernanceRating'),
    ('OUT_N1',                  'FrameworkImpliedRatingN1'),
    ('OUT_N2',                  'FrameworkImpliedRatingN2'),
    ('OUT_ANALYST_N1',          'RatingAsAssessedByAnalystN1'),
    ('OUT_PG_RATING',           'RatingFactoringInParentGroupSupport'),
    ('OUT_RC_N1',               'RatingAssignedByRCN1'),
    ('OUT_FINAL_RC',            'FinalRatingAssignedByRC')
) v(OldCode, NewCode) ON p.ParameterCode = v.OldCode
WHERE NOT EXISTS (SELECT 1 FROM dbo.ParameterDefinitionMaster x WHERE x.ParameterCode = v.NewCode);
GO

/* ------------------------------------------------------------------ PART A: schema */
IF OBJECT_ID('dbo.FinancialParameterMaster') IS NULL
    CREATE TABLE dbo.FinancialParameterMaster
    (
        FinancialParameterMasterId  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_FinancialParameterMaster PRIMARY KEY,
        ParameterDefinitionMasterId INT           NOT NULL CONSTRAINT FK_FPM_Master
                                    REFERENCES dbo.ParameterDefinitionMaster(ParameterDefinitionMasterId),
        TemplateCode                INT           NULL,      -- spread template code; NULL for calculated ratios
        RowPosition                 INT           NULL,      -- spread row
        IsPercentage                BIT           NOT NULL CONSTRAINT DF_FPM_Pct DEFAULT 0,
        DivByZeroValue              DECIMAL(18,6) NULL,      -- 10000 for OPBDITA/Interest and DSCR
        UsesFirstYearWeights        BIT           NOT NULL CONSTRAINT DF_FPM_FirstYr DEFAULT 0,   -- ROCE, DSCR
        ListedOnly                  BIT           NOT NULL CONSTRAINT DF_FPM_Listed DEFAULT 0,    -- TOL / Market Cap
        ListedWeightShare           DECIMAL(9,6)  NULL,      -- 0.4 on FR_TOL_TNW, 0.6 on FR_TOL_MCAP
        CONSTRAINT UQ_FPM_Master UNIQUE (ParameterDefinitionMasterId)
    );

IF OBJECT_ID('dbo.WeightByYears') IS NULL
    CREATE TABLE dbo.WeightByYears
    (
        WeightByYearsId          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WeightByYears PRIMARY KEY,
        WorkflowJsonVersionId INT          NOT NULL CONSTRAINT FK_WeightByYears_Version
                              REFERENCES dbo.WorkflowJsonVersion(WorkflowJsonVersionId),
        WeightType            VARCHAR(20)  NOT NULL,  -- 'Standard', 'ROCEAndDSCR', 'ALM'
        NoOfPastYears         INT          NOT NULL,
        NoOfProjectedYears    INT          NOT NULL,
        YearType              VARCHAR(10)  NOT NULL,  -- 'Past4'..'Past1', 'Current', 'Proj1'..'Proj5'
        Weight                DECIMAL(9,6) NOT NULL CONSTRAINT CK_WeightByYears_Range CHECK (Weight BETWEEN 0 AND 1),
        CONSTRAINT UQ_WeightByYears UNIQUE (WorkflowJsonVersionId, WeightType, NoOfPastYears, NoOfProjectedYears, YearType)
    );

IF OBJECT_ID('dbo.FinancialParameterComputationDetails') IS NULL
    CREATE TABLE dbo.FinancialParameterComputationDetails
    (
        FinancialParameterComputationDetailsId  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_FinancialParameterComputationDetails PRIMARY KEY,
        AssessmentResponseId        INT           NOT NULL CONSTRAINT FK_FPCD_Response
                                    REFERENCES dbo.AssessmentResponse(AssessmentResponseId),
        IndustryParameterMappingId  INT           NOT NULL CONSTRAINT FK_FPCD_Mapping
                                    REFERENCES dbo.IndustryParameterMapping(IndustryParameterMappingId),
        FiscalYear                  INT           NOT NULL,
        YearType                    VARCHAR(10)   NOT NULL,
        Value                       DECIMAL(18,6) NULL,
        IsDivByZero                 BIT           NOT NULL CONSTRAINT DF_FPCD_DivZero DEFAULT 0,  -- shown as "#DIV/0!"
        Score                       INT           NULL,
        YearWeight                  DECIMAL(9,6)  NOT NULL,
        CONSTRAINT UQ_FPCD UNIQUE (AssessmentResponseId, IndustryParameterMappingId, FiscalYear)
    );

-- second scenario ("only projected years") next to the blended value
IF COL_LENGTH('dbo.FrameworkOutputDetails', 'ValueNumberProj') IS NULL
    ALTER TABLE dbo.FrameworkOutputDetails ADD ValueNumberProj DECIMAL(18,4) NULL, ValueTextProj VARCHAR(256) NULL;
GO

/* ------------------------------------------------------------------ PART B: masters and ratio definitions */
DECLARE @Ratios TABLE (Code VARCHAR(128), Name VARCHAR(256), TemplateCode INT, RowPosition INT, IsPct BIT,
                       DivZero DECIMAL(18,6), FirstYr BIT, ListedOnly BIT, ListedShare DECIMAL(9,6));
INSERT @Ratios VALUES
('FR_ROCE',             'ROCE',                                                  387,  304,  1, NULL,  1, 0, NULL),
('FR_OPBDITA_INTEREST', 'OPBDITA / Interest',                                    7397, 324,  0, 10000, 0, 0, NULL),
('FR_DSCR',             'DSCR (including Short Term Debt)',                      411,  330,  0, 10000, 1, 0, NULL),
('FR_TD_OPBDITA',       'Total Debt / OPBDITA',                                  410,  329,  0, NULL,  0, 0, NULL),
('FR_TOL_TNW',          'Total Outside Liabilities / (TNW + Minority Interest)', 402,  319,  0, NULL,  0, 0, 0.4),
('FR_TOL_MCAP',         'Total Outside Liabilities / Market Capitalization',     NULL, NULL, 0, NULL,  0, 1, 0.6),
('FR_TOL',              'Total Outside Liabilities',                             286,  192,  0, NULL,  0, 1, NULL),
('FR_MCAP',             'Market Capitalisation',                                 299,  207,  0, NULL,  0, 1, NULL),
('FR_ROCE_VOLATILITY',  'Volatility in ROCE',                                    NULL, NULL, 0, NULL,  0, 0, NULL),
('FR_ROCE_ADJUSTED',    'ROCE adjusted for volatility',                          NULL, NULL, 0, NULL,  0, 0, NULL);

INSERT dbo.ParameterDefinitionMaster(ParameterCode, ParameterName, WhyItMatters, HowDoWeMeasure, IsValueDriven, IsActive)
SELECT r.Code, r.Name, '', '', 1, 1
FROM @Ratios r
WHERE NOT EXISTS (SELECT 1 FROM dbo.ParameterDefinitionMaster p WHERE p.ParameterCode = r.Code);

INSERT dbo.FinancialParameterMaster(ParameterDefinitionMasterId, TemplateCode, RowPosition, IsPercentage,
       DivByZeroValue, UsesFirstYearWeights, ListedOnly, ListedWeightShare)
SELECT p.ParameterDefinitionMasterId, r.TemplateCode, r.RowPosition, r.IsPct, r.DivZero, r.FirstYr, r.ListedOnly, r.ListedShare
FROM @Ratios r
JOIN dbo.ParameterDefinitionMaster p ON p.ParameterCode = r.Code
WHERE NOT EXISTS (SELECT 1 FROM dbo.FinancialParameterMaster d WHERE d.ParameterDefinitionMasterId = p.ParameterDefinitionMasterId);
GO

/* ------------------------------------------------------------------ PART C: one Draft version */
DECLARE @WorkflowCode VARCHAR(128) = 'AutomobileCommercial';
DECLARE @VersionNo    INT          = 14;      -- Draft version to set up

DECLARE @VersionId INT, @Status VARCHAR(50), @IndustryId INT;
SELECT @VersionId = WorkflowJsonVersionId, @Status = Status, @IndustryId = IndustryDetailsId
FROM dbo.WorkflowJsonVersion WHERE WorkflowCode = @WorkflowCode AND VersionNo = @VersionNo;

IF @VersionId IS NULL BEGIN RAISERROR('Version %s V%d not found.', 16, 1, @WorkflowCode, @VersionNo); RETURN; END
IF @Status <> 'Draft' BEGIN RAISERROR('V%d is %s. Only a Draft version is changed.', 16, 1, @VersionNo, @Status); RETURN; END

BEGIN TRANSACTION;

-- C1. rows of step Financial (weights in %, like the other steps; inputs FR_TOL / FR_MCAP get no row)
DECLARE @Rows TABLE (Code VARCHAR(128), Weight DECIMAL(10,2), DisplayOrder INT);
INSERT @Rows VALUES
('FR_ROCE', 0, 1), ('FR_OPBDITA_INTEREST', 25, 2), ('FR_DSCR', 25, 3), ('FR_TD_OPBDITA', 30, 4),
('FR_TOL_TNW', 20, 5), ('FR_TOL_MCAP', 0, 6), ('FR_ROCE_VOLATILITY', 0, 7), ('FR_ROCE_ADJUSTED', 0, 8);

INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId, IndustryDetailsId, ParameterDefinitionMasterId, ParameterDisplayName,
       ValueType, Weight, DisplayOrder, IsActive, StepName, ControlType, SectionName, OptionsSource)
SELECT @VersionId, @IndustryId, p.ParameterDefinitionMasterId, p.ParameterName,
       'ManualScore', r.Weight, r.DisplayOrder, 1, 'Financial', 'Calculated', 'Financial Risk', 'RatingScale'
FROM @Rows r
JOIN dbo.ParameterDefinitionMaster p ON p.ParameterCode = r.Code
WHERE NOT EXISTS (SELECT 1 FROM dbo.IndustryParameterMapping m
                  WHERE m.WorkflowJsonVersionId = @VersionId AND m.ParameterDefinitionMasterId = p.ParameterDefinitionMasterId);

-- C2. one score scale (1-6) for the financial bands of this version
DECLARE @ScaleCode VARCHAR(128) = CONCAT(@WorkflowCode, '_V', @VersionNo, '_FinancialRatio');
IF NOT EXISTS (SELECT 1 FROM dbo.ScaleConfiguration WHERE ScaleCode = @ScaleCode)
    INSERT dbo.ScaleConfiguration(ScaleCode, ScaleName, MinValue, MaxValue, IsActive)
    VALUES (@ScaleCode, 'Financial ratio score', 1, 6, 1);
DECLARE @ScaleId INT = (SELECT ScaleConfigurationId FROM dbo.ScaleConfiguration WHERE ScaleCode = @ScaleCode);

-- C3. bands: MinValue <= value < MaxValue. Legacy edge rules are explicit bands:
--     ROCE / TD-OPBDITA negative -> B; OPBDITA-Interest / DSCR <= 0 -> B (inside the lowest band); DIV/0 = 10000 -> AAA
DECLARE @Bands TABLE (Code VARCHAR(128), Rating VARCHAR(10), Score INT, MinV DECIMAL(10,2), MaxV DECIMAL(10,2));
INSERT @Bands VALUES
('FR_ROCE','B',6,-99999999,0.10), ('FR_ROCE','BB',5,0.10,0.13), ('FR_ROCE','BBB',4,0.13,0.16),
('FR_ROCE','A',3,0.16,0.20),      ('FR_ROCE','AA',2,0.20,0.25), ('FR_ROCE','AAA',1,0.25,99999999),
('FR_OPBDITA_INTEREST','B',6,-99999999,2.00), ('FR_OPBDITA_INTEREST','BB',5,2.00,2.80), ('FR_OPBDITA_INTEREST','BBB',4,2.80,4.00),
('FR_OPBDITA_INTEREST','A',3,4.00,7.00),      ('FR_OPBDITA_INTEREST','AA',2,7.00,18.00), ('FR_OPBDITA_INTEREST','AAA',1,18.00,99999999),
('FR_DSCR','B',6,-99999999,1.10), ('FR_DSCR','BB',5,1.10,1.40), ('FR_DSCR','BBB',4,1.40,1.80),
('FR_DSCR','A',3,1.80,2.50),      ('FR_DSCR','AA',2,2.50,4.00), ('FR_DSCR','AAA',1,4.00,99999999),
('FR_TD_OPBDITA','B',6,-99999999,0), ('FR_TD_OPBDITA','AAA',1,0,0.50), ('FR_TD_OPBDITA','AA',2,0.50,1.50),
('FR_TD_OPBDITA','A',3,1.50,2.30),   ('FR_TD_OPBDITA','BBB',4,2.30,3.00), ('FR_TD_OPBDITA','BB',5,3.00,5.00),
('FR_TD_OPBDITA','B',6,5.00,99999999),
('FR_ROCE_VOLATILITY','AAA',1,0,0.10), ('FR_ROCE_VOLATILITY','AA',2,0.10,0.15), ('FR_ROCE_VOLATILITY','A',3,0.15,0.25),
('FR_ROCE_VOLATILITY','BBB',4,0.25,0.40), ('FR_ROCE_VOLATILITY','BB',5,0.40,0.55), ('FR_ROCE_VOLATILITY','B',6,0.55,99999999);
-- FR_TOL_TNW and FR_TOL_MCAP: rows were cut off in data2.txt (open item 2a); add them here when received.

INSERT dbo.ScaleConfigurationDetails(IndustryParameterMappingId, ScaleConfigurationId, ScoreValue, Definition, MinValue, MaxValue)
SELECT m.IndustryParameterMappingId, @ScaleId, CAST(b.Score AS VARCHAR(10)), b.Rating, b.MinV, b.MaxV
FROM @Bands b
JOIN dbo.ParameterDefinitionMaster p ON p.ParameterCode = b.Code
JOIN dbo.IndustryParameterMapping m ON m.ParameterDefinitionMasterId = p.ParameterDefinitionMasterId
                                   AND m.WorkflowJsonVersionId = @VersionId
WHERE NOT EXISTS (SELECT 1 FROM dbo.ScaleConfigurationDetails d
                  WHERE d.IndustryParameterMappingId = m.IndustryParameterMappingId
                    AND d.MinValue = b.MinV AND d.MaxValue = b.MaxV)
ORDER BY m.IndustryParameterMappingId, b.MinV;

-- C4. year weights: not seeded (open item 2b). Validation stops Run Framework while a weight set is missing.

COMMIT;

-- check: leverage weights must total 100 (not listed) - listed split by ListedWeightShare
SELECT SUM(m.Weight) AS FinancialWeightTotal
FROM dbo.IndustryParameterMapping m
WHERE m.WorkflowJsonVersionId = @VersionId AND m.StepName = 'Financial';
SELECT p.ParameterCode, COUNT(*) AS Bands
FROM dbo.ScaleConfigurationDetails d
JOIN dbo.IndustryParameterMapping m ON m.IndustryParameterMappingId = d.IndustryParameterMappingId
JOIN dbo.ParameterDefinitionMaster p ON p.ParameterDefinitionMasterId = m.ParameterDefinitionMasterId
WHERE m.WorkflowJsonVersionId = @VersionId AND m.StepName = 'Financial'
GROUP BY p.ParameterCode ORDER BY p.ParameterCode;
GO