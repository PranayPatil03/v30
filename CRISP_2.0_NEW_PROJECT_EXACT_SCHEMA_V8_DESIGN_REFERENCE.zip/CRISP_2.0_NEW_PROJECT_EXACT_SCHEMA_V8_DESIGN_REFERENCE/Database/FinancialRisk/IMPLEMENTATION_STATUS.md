# Financial Risk / Output tab delivery status

## Included in this package

- Existing CRISP 2.0 solution and Output tab implementation.
- `14_Financial_Risk_Setup.sql` supplied for the Financial Risk tables, master definitions, version mappings and currently provided score bands.
- `FinancialRiskNotConfiguredService`, a temporary implementation of the existing `IFinancialRiskService` contract.
- API dependency-injection registration in `src/CRISP.Api/Program.cs` for that implementation. This resolves the startup error where `OutputCalculator` could not resolve `IFinancialRiskService`.

## Important runtime behavior

`FinancialRiskNotConfiguredService` intentionally returns `null`. The existing `OutputCalculator` then raises its existing `RatingConfigurationException` stating that financial risk is not configured for the version. This prevents a fabricated financial score. It allows the API host to build its dependency graph and start; it does **not** make the Chapter 14A calculation complete.

## Still required for complete Chapter 14A

- Implement the actual legacy financial-risk calculations in C# and replace the temporary DI registration.
- Supply and configure the missing `FR_TOL_TNW` and `FR_TOL_MCAP` score bands.
- Seed version-specific `WeightByYears` rows for the supported year-count combinations and weight types.
- Verify the full adjusted-ROCE, refinancing-dependence and final financial-score behavior against the legacy procedure outputs.
- Build and run integration tests against the target SQL Server database.

## Where the temporary registration is

`src/CRISP.Api/Program.cs`

```csharp
builder.Services.AddScoped<IFinancialRiskService, FinancialRiskNotConfiguredService>();
builder.Services.AddScoped<OutputCalculator>();
builder.Services.AddScoped<IOutputService, OutputService>();
```

No duplicate repository, output service, DbContext, or financial data-access layer was added.
