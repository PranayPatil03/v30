/*
 CRISP 2.0 - New schema + repeatable demo seed data
 SQL Server / Database-First. No EF Core migrations required.
 Creates the nine requested tables plus AssessmentResponse for entity-specific answers.
 Safe to rerun: tables are created only when missing and seed rows are inserted by natural keys.
*/

Use CRISP2_UAT


/*
  OPTIONAL RESET: drops the current schema tables before recreating them.
  WARNING: this permanently deletes all data in these tables.
  Drop child tables before parent tables to satisfy foreign-key dependencies.
*/
IF OBJECT_ID(N'dbo.AssessmentResponse', N'U') IS NOT NULL DROP TABLE dbo.AssessmentResponse;
IF OBJECT_ID(N'dbo.ValidationDefinition', N'U') IS NOT NULL DROP TABLE dbo.ValidationDefinition;
IF OBJECT_ID(N'dbo.RuleDefinition', N'U') IS NOT NULL DROP TABLE dbo.RuleDefinition;
IF OBJECT_ID(N'dbo.ScaleConfigurationDetails', N'U') IS NOT NULL DROP TABLE dbo.ScaleConfigurationDetails;
IF OBJECT_ID(N'dbo.IndustryParameterMapping', N'U') IS NOT NULL DROP TABLE dbo.IndustryParameterMapping;
IF OBJECT_ID(N'dbo.WorkflowJsonVersion', N'U') IS NOT NULL DROP TABLE dbo.WorkflowJsonVersion;
IF OBJECT_ID(N'dbo.CustomerMaster', N'U') IS NOT NULL DROP TABLE dbo.CustomerMaster;
IF OBJECT_ID(N'dbo.ParameterDefinitionMaster', N'U') IS NOT NULL DROP TABLE dbo.ParameterDefinitionMaster;
IF OBJECT_ID(N'dbo.ScaleConfiguration', N'U') IS NOT NULL DROP TABLE dbo.ScaleConfiguration;
IF OBJECT_ID(N'dbo.IndustryDetails', N'U') IS NOT NULL DROP TABLE dbo.IndustryDetails;
GO

IF OBJECT_ID(N'dbo.IndustryDetails', N'U') IS NULL
CREATE TABLE dbo.IndustryDetails(
 IndustryDetailId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_IndustryDetails PRIMARY KEY,
 IndustryName VARCHAR(256) NOT NULL,
 IsActive BIT NOT NULL CONSTRAINT DF_IndustryDetails_IsActive DEFAULT(1)
);
GO
IF OBJECT_ID(N'dbo.CustomerMaster', N'U') IS NULL
CREATE TABLE dbo.CustomerMaster(
 EntityId INT IDENTITY(1,1) NOT NULL 
     CONSTRAINT PK_CustomerMaster PRIMARY KEY,
 EntityName VARCHAR(256) NOT NULL,
 IsActive BIT NOT NULL 
     CONSTRAINT DF_CustomerMaster_IsActive DEFAULT(1)
);
GO
IF OBJECT_ID(N'dbo.ParameterDefinitionMaster', N'U') IS NULL
CREATE TABLE dbo.ParameterDefinitionMaster(
 ParameterDefinitionMasterId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ParameterDefinitionMaster PRIMARY KEY,
 ParameterCode VARCHAR(128) NOT NULL,
 ParameterName VARCHAR(256) NOT NULL,
 WhyItMatters VARCHAR(256) NOT NULL CONSTRAINT DF_ParameterDefinitionMaster_Why DEFAULT(''),
 IsActive BIT NOT NULL CONSTRAINT DF_ParameterDefinitionMaster_IsActive DEFAULT(1),
 CONSTRAINT UQ_ParameterDefinitionMaster_Code UNIQUE(ParameterCode)
);
GO
IF OBJECT_ID(N'dbo.WorkflowJsonVersion', N'U') IS NULL
CREATE TABLE dbo.WorkflowJsonVersion(
 WorkflowJsonVersionId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WorkflowJsonVersion PRIMARY KEY,
 IndustryDetailsId INT NOT NULL,
 WorkflowCode VARCHAR(128) NOT NULL,
 WorkflowName VARCHAR(256) NOT NULL,
 VersionNo INT NOT NULL,
 JsonContent VARCHAR(MAX) NOT NULL,
 VersionName VARCHAR(128) NOT NULL,
 Status VARCHAR(30) NOT NULL CONSTRAINT DF_WorkflowJsonVersion_Status DEFAULT('Draft'),
 IsPublished BIT NOT NULL CONSTRAINT DF_WorkflowJsonVersion_IsPublished DEFAULT(0),
 CONSTRAINT FK_WorkflowJsonVersion_IndustryDetails FOREIGN KEY(IndustryDetailsId) REFERENCES dbo.IndustryDetails(IndustryDetailId),
 CONSTRAINT UQ_WorkflowJsonVersion_Code_Version UNIQUE(WorkflowCode,VersionNo),
 CONSTRAINT CK_WorkflowJsonVersion_Status CHECK(Status IN ('Draft','Published','Archieve'))
);
GO
IF OBJECT_ID(N'dbo.IndustryParameterMapping', N'U') IS NULL
CREATE TABLE dbo.IndustryParameterMapping(
 IndustryParameterMappingId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_IndustryParameterMapping PRIMARY KEY,
 WorkflowJsonVersionId INT NOT NULL,
 IndustryDetailsId INT NOT NULL,
 ParameterDefinitionMasterId INT NOT NULL,
 ParentIndustryParameterMappingId INT NULL,
 ParameterDisplayName VARCHAR(128) NOT NULL,
 ValueType VARCHAR(128) NOT NULL,
 Weight DECIMAL(10,2) NOT NULL,
 DisplayOrder INT NOT NULL CONSTRAINT DF_IndustryParameterMapping_DisplayOrder DEFAULT(9999),
 IsActive BIT NOT NULL CONSTRAINT DF_IndustryParameterMapping_IsActive DEFAULT(1),
 CONSTRAINT FK_IPM_WorkflowJsonVersion FOREIGN KEY(WorkflowJsonVersionId) REFERENCES dbo.WorkflowJsonVersion(WorkflowJsonVersionId),
 CONSTRAINT FK_IPM_IndustryDetails FOREIGN KEY(IndustryDetailsId) REFERENCES dbo.IndustryDetails(IndustryDetailId),
 CONSTRAINT UQ_IPM_Version_Industry_Parameter UNIQUE(WorkflowJsonVersionId,IndustryDetailsId,ParameterDefinitionMasterId),
 CONSTRAINT FK_IPM_ParameterDefinition FOREIGN KEY(ParameterDefinitionMasterId) REFERENCES dbo.ParameterDefinitionMaster(ParameterDefinitionMasterId),
 CONSTRAINT FK_IPM_Parent FOREIGN KEY(ParentIndustryParameterMappingId) REFERENCES dbo.IndustryParameterMapping(IndustryParameterMappingId)
);
GO
IF OBJECT_ID(N'dbo.ValidationDefinition', N'U') IS NULL
CREATE TABLE dbo.ValidationDefinition(
 ValidationDefinitionId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ValidationDefinition PRIMARY KEY,
 IndustryParameterMappingId INT NOT NULL,
 ValidationName VARCHAR(128) NOT NULL,
 Expression VARCHAR(MAX) NOT NULL,
 ErrorMessage VARCHAR(256) NOT NULL,
 IsActive BIT NOT NULL CONSTRAINT DF_ValidationDefinition_IsActive DEFAULT(1),
 CONSTRAINT FK_Validation_IPM FOREIGN KEY(IndustryParameterMappingId) REFERENCES dbo.IndustryParameterMapping(IndustryParameterMappingId)
);
GO
IF OBJECT_ID(N'dbo.RuleDefinition', N'U') IS NULL
CREATE TABLE dbo.RuleDefinition(
 RuleDefinitionId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_RuleDefinition PRIMARY KEY,
 WorkflowJsonVersionId INT NOT NULL,
 RuleName VARCHAR(128) NOT NULL,
 RuleExpressionType VARCHAR(128) NOT NULL,
 OutputExpression VARCHAR(256) NOT NULL,
 IsActive BIT NOT NULL CONSTRAINT DF_RuleDefinition_IsActive DEFAULT(1),
 CONSTRAINT FK_Rule_WorkflowJsonVersion FOREIGN KEY(WorkflowJsonVersionId) REFERENCES dbo.WorkflowJsonVersion(WorkflowJsonVersionId)
);
GO
IF OBJECT_ID(N'dbo.ScaleConfiguration', N'U') IS NULL
CREATE TABLE dbo.ScaleConfiguration(
 ScaleConfigurationId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ScaleConfiguration PRIMARY KEY,
 ScaleCode VARCHAR(128) NOT NULL,
 ScaleName VARCHAR(256) NOT NULL,
 MinValue DECIMAL(10,2) NOT NULL,
 MaxValue DECIMAL(10,2) NOT NULL,
 IsActive BIT NOT NULL CONSTRAINT DF_ScaleConfiguration_IsActive DEFAULT(1),
 CONSTRAINT UQ_ScaleConfiguration_Code UNIQUE(ScaleCode),
 CONSTRAINT CK_ScaleConfiguration_Range CHECK(MinValue <= MaxValue)
);
GO
IF OBJECT_ID(N'dbo.ScaleConfigurationDetails', N'U') IS NULL
CREATE TABLE dbo.ScaleConfigurationDetails(
 ScaleConfigurationDetailsId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ScaleConfigurationDetails PRIMARY KEY,
 IndustryParameterMappingId INT NOT NULL,
 ScaleConfigurationId INT NOT NULL,
 ScoreValue DECIMAL(10,2) NOT NULL,
 Definition VARCHAR(256) NOT NULL,
 MinValue DECIMAL(10,2) NOT NULL,
 MaxValue DECIMAL(10,2) NOT NULL,
 CONSTRAINT FK_ScaleDetails_IPM FOREIGN KEY(IndustryParameterMappingId) REFERENCES dbo.IndustryParameterMapping(IndustryParameterMappingId),
 CONSTRAINT FK_ScaleDetails_Scale FOREIGN KEY(ScaleConfigurationId) REFERENCES dbo.ScaleConfiguration(ScaleConfigurationId),
 CONSTRAINT CK_ScaleDetails_Range CHECK(MinValue <= MaxValue)
);
GO
IF OBJECT_ID(N'dbo.AssessmentResponse', N'U') IS NULL
CREATE TABLE dbo.AssessmentResponse(
 AssessmentResponseId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_AssessmentResponse PRIMARY KEY,
 EntityId INT NOT NULL,
 WorkflowJsonVersionId INT NOT NULL,
 ResponseJson NVARCHAR(MAX) NOT NULL,
 Status VARCHAR(30) NOT NULL CONSTRAINT DF_AssessmentResponse_Status DEFAULT('Draft'),
 CreatedOn DATETIME2 NOT NULL CONSTRAINT DF_AssessmentResponse_CreatedOn DEFAULT(SYSUTCDATETIME()),
 UpdatedOn DATETIME2 NOT NULL CONSTRAINT DF_AssessmentResponse_UpdatedOn DEFAULT(SYSUTCDATETIME()),
 CONSTRAINT FK_AssessmentResponse_Customer FOREIGN KEY(EntityId) REFERENCES dbo.CustomerMaster(EntityId),
 CONSTRAINT FK_AssessmentResponse_Version FOREIGN KEY(WorkflowJsonVersionId) REFERENCES dbo.WorkflowJsonVersion(WorkflowJsonVersionId),
 CONSTRAINT CK_AssessmentResponse_Json CHECK(ISJSON(ResponseJson)=1)
);
GO

/* AssessmentResponse is recreated above with the intended non-unique entity/version index policy. */
GO

/* V19 exact seed data translated to the new CRISP 2.0 schema.
   Source: V19 Database/01_Create_DynamicRuleEngine_Framework.sql,
   CorporateBusiness.v1.json and CorporateBusiness.v2.json.
   This script is repeatable and preserves the original sample names, dates,
   parameter codes, weights, score definitions, workflow JSON and assessment values. */

/* Industry rows used by V19 */
IF NOT EXISTS (SELECT 1 FROM dbo.IndustryDetails WHERE IndustryName='Automobiles - Commercial Vehicles')
 INSERT dbo.IndustryDetails(IndustryName,IsActive) VALUES('Automobiles - Commercial Vehicles',1);
IF NOT EXISTS (SELECT 1 FROM dbo.IndustryDetails WHERE IndustryName='Automobiles - Passenger Vehicles')
 INSERT dbo.IndustryDetails(IndustryName,IsActive) VALUES('Automobiles - Passenger Vehicles',1);
IF NOT EXISTS (SELECT 1 FROM dbo.IndustryDetails WHERE IndustryName='Commercial Vehicles - Components')
 INSERT dbo.IndustryDetails(IndustryName,IsActive) VALUES('Commercial Vehicles - Components',1);

DECLARE @IndustryId INT=(SELECT TOP(1) IndustryDetailId FROM dbo.IndustryDetails WHERE IndustryName='Automobiles - Commercial Vehicles' ORDER BY IndustryDetailId);

/* Exact V19 entity/customer names */
/* Exact V19 entity/customer names */

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.CustomerMaster
    WHERE EntityName = '20 Microns Limited'
)
BEGIN
    INSERT INTO dbo.CustomerMaster
    (
        EntityName,
        IsActive
    )
    VALUES
    (
        '20 Microns Limited',
        1
    );
END


IF NOT EXISTS
(
    SELECT 1
    FROM dbo.CustomerMaster
    WHERE EntityName = '20 Microns Minerals, Foods Limited-Test 10'
)
BEGIN
    INSERT INTO dbo.CustomerMaster
    (
        EntityName,
        IsActive
    )
    VALUES
    (
        '20 Microns Minerals, Foods Limited-Test 10',
        1
    );
END

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.CustomerMaster
    WHERE EntityName = '20 Microns Nano Minerals Limited'
)
BEGIN
    INSERT INTO dbo.CustomerMaster
    (
        EntityName,
        IsActive
    )
    VALUES
    (
        '20 Microns Nano Minerals Limited',
        1
    );
END



/* Exact V19 parameter definitions */
IF NOT EXISTS (SELECT 1 FROM dbo.ParameterDefinitionMaster WHERE ParameterCode='MarketPositionScore')
 INSERT dbo.ParameterDefinitionMaster(ParameterCode,ParameterName,WhyItMatters,IsActive) VALUES('MarketPositionScore','Market Position & Brand Strength','Market share is a good proxy to a company''s scale & market position and R&D strengths',1);
IF NOT EXISTS (SELECT 1 FROM dbo.ParameterDefinitionMaster WHERE ParameterCode='ScaleScore')
 INSERT dbo.ParameterDefinitionMaster(ParameterCode,ParameterName,WhyItMatters,IsActive) VALUES('ScaleScore','Scale','The scale of operations, as measured by revenues, production capacity and production output, is one of the primary factors in evaluating business position.',1);
IF NOT EXISTS (SELECT 1 FROM dbo.ParameterDefinitionMaster WHERE ParameterCode='ProductPortfolioScore')
 INSERT dbo.ParameterDefinitionMaster(ParameterCode,ParameterName,WhyItMatters,IsActive) VALUES('ProductPortfolioScore','Product Portfolio','A strong product portfolio is essential for an OEM to sustain its competitive market position and cater to a diverse customer profile.',1);
IF NOT EXISTS (SELECT 1 FROM dbo.ParameterDefinitionMaster WHERE ParameterCode='GeographicDiversificationScore')
 INSERT dbo.ParameterDefinitionMaster(ParameterCode,ParameterName,WhyItMatters,IsActive) VALUES('GeographicDiversificationScore','Geographic Diversification','Geographic diversification helps mitigate risks arising from demand slowdown in a particular geography.',1);
IF NOT EXISTS (SELECT 1 FROM dbo.ParameterDefinitionMaster WHERE ParameterCode='TechnologyScore')
 INSERT dbo.ParameterDefinitionMaster(ParameterCode,ParameterName,WhyItMatters,IsActive) VALUES('TechnologyScore','Technology & Product Development Capabilities','OEMs need to continuously refresh their offering to keep pace with changing technology and emission norms.',1);

/* Version 1 and version 2 use the exact V19 JSON rule expressions and weights. */
DECLARE @WorkflowCode VARCHAR(128)='CorporateBusiness';
DECLARE @WorkflowName VARCHAR(256)='Corporate Business Framework';
DECLARE @JsonV1 VARCHAR(MAX)='[{"WorkflowName":"CorporateBusiness","GlobalParams":[{"Name":"Version","Expression":"1"}],"Weights":{"MarketPositionScore":15,"ScaleScore":15,"ProductPortfolioScore":25,"GeographicDiversificationScore":25,"TechnologyScore":20},"Rules":[{"RuleName":"CalculateWeightedAverage","SuccessEvent":"Calculated","Expression":"true","RuleExpressionType":"LambdaExpression","Actions":{"OnSuccess":{"Name":"OutputExpression","Context":{"Expression":"(input1.MarketPositionScore * 15 + input1.ScaleScore * 15 + input1.ProductPortfolioScore * 25 + input1.GeographicDiversificationScore * 25 + input1.TechnologyScore * 20) / 100.0"}}}}]}]';
DECLARE @JsonV2 VARCHAR(MAX)='[{"WorkflowName":"CorporateBusiness","GlobalParams":[{"Name":"Version","Expression":"2"}],"Weights":{"MarketPositionScore":20,"ScaleScore":10,"ProductPortfolioScore":25,"GeographicDiversificationScore":25,"TechnologyScore":20},"Rules":[{"RuleName":"CalculateWeightedAverage","SuccessEvent":"Calculated","Expression":"true","RuleExpressionType":"LambdaExpression","Actions":{"OnSuccess":{"Name":"OutputExpression","Context":{"Expression":"(input1.MarketPositionScore * 20 + input1.ScaleScore * 10 + input1.ProductPortfolioScore * 25 + input1.GeographicDiversificationScore * 25 + input1.TechnologyScore * 20) / 100.0"}}}}]}]';

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.WorkflowJsonVersion
    WHERE WorkflowCode = @WorkflowCode
      AND VersionNo = 1
)
BEGIN
    INSERT INTO dbo.WorkflowJsonVersion
    (
        IndustryDetailsId,
        WorkflowCode,
        WorkflowName,
        VersionNo,
        JsonContent,
        VersionName,
        Status,
        IsPublished
    )
    VALUES
    (
        @IndustryId,            -- IndustryDetailsId
        @WorkflowCode,          -- WorkflowCode
        @WorkflowName,          -- WorkflowName
        1,                      -- VersionNo
        @JsonV1,                -- JsonContent
        '09-Sep-2026 - Draft',  -- VersionName
        'Published',            -- Status
        1                       -- IsPublished
    );
END


IF NOT EXISTS
(
    SELECT 1
    FROM dbo.WorkflowJsonVersion
    WHERE WorkflowCode = @WorkflowCode
      AND VersionNo = 2
)
BEGIN
    INSERT INTO dbo.WorkflowJsonVersion
    (
        IndustryDetailsId,
        WorkflowCode,
        WorkflowName,
        VersionNo,
        JsonContent,
        VersionName,
        Status,
        IsPublished
    )
    VALUES
    (
        @IndustryId,            -- IndustryDetailsId
        @WorkflowCode,          -- WorkflowCode
        @WorkflowName,          -- WorkflowName
        2,                      -- VersionNo
        @JsonV2,                -- JsonContent
        '03-Sep-2026',          -- VersionName
        'Draft',                -- Status
        0                       -- IsPublished
    );
END
DECLARE @V1 INT=(SELECT WorkflowJsonVersionId FROM dbo.WorkflowJsonVersion WHERE WorkflowCode=@WorkflowCode AND VersionNo=1);
DECLARE @V2 INT=(SELECT WorkflowJsonVersionId FROM dbo.WorkflowJsonVersion WHERE WorkflowCode=@WorkflowCode AND VersionNo=2);
DECLARE @PMarket INT=(SELECT ParameterDefinitionMasterId FROM dbo.ParameterDefinitionMaster WHERE ParameterCode='MarketPositionScore');
DECLARE @PScale INT=(SELECT ParameterDefinitionMasterId FROM dbo.ParameterDefinitionMaster WHERE ParameterCode='ScaleScore');
DECLARE @PPortfolio INT=(SELECT ParameterDefinitionMasterId FROM dbo.ParameterDefinitionMaster WHERE ParameterCode='ProductPortfolioScore');
DECLARE @PGeo INT=(SELECT ParameterDefinitionMasterId FROM dbo.ParameterDefinitionMaster WHERE ParameterCode='GeographicDiversificationScore');
DECLARE @PTech INT=(SELECT ParameterDefinitionMasterId FROM dbo.ParameterDefinitionMaster WHERE ParameterCode='TechnologyScore');

/* Mappings with the exact V19 weights. */
DECLARE @MapV1Market INT, @MapV1Scale INT, @MapV1Portfolio INT, @MapV1Geo INT, @MapV1Tech INT;
DECLARE @MapV2Market INT, @MapV2Scale INT, @MapV2Portfolio INT, @MapV2Geo INT, @MapV2Tech INT;

IF NOT EXISTS(SELECT 1 FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V1 AND ParameterDefinitionMasterId=@PMarket)
 INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId,IndustryDetailsId,ParameterDefinitionMasterId,ParentIndustryParameterMappingId,ParameterDisplayName,ValueType,Weight,IsActive) VALUES(@V1,(SELECT IndustryDetailsId FROM dbo.WorkflowJsonVersion WHERE WorkflowJsonVersionId=@V1),@PMarket,NULL,'Market Position & Brand Strength','Number',15,1);
IF NOT EXISTS(SELECT 1 FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V1 AND ParameterDefinitionMasterId=@PScale)
 INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId,IndustryDetailsId,ParameterDefinitionMasterId,ParentIndustryParameterMappingId,ParameterDisplayName,ValueType,Weight,IsActive) VALUES(@V1,(SELECT IndustryDetailsId FROM dbo.WorkflowJsonVersion WHERE WorkflowJsonVersionId=@V1),@PScale,NULL,'Scale','Number',15,1);
IF NOT EXISTS(SELECT 1 FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V1 AND ParameterDefinitionMasterId=@PPortfolio)
 INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId,IndustryDetailsId,ParameterDefinitionMasterId,ParentIndustryParameterMappingId,ParameterDisplayName,ValueType,Weight,IsActive) VALUES(@V1,(SELECT IndustryDetailsId FROM dbo.WorkflowJsonVersion WHERE WorkflowJsonVersionId=@V1),@PPortfolio,NULL,'Product Portfolio','Score',25,1);
IF NOT EXISTS(SELECT 1 FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V1 AND ParameterDefinitionMasterId=@PGeo)
 INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId,IndustryDetailsId,ParameterDefinitionMasterId,ParentIndustryParameterMappingId,ParameterDisplayName,ValueType,Weight,IsActive) VALUES(@V1,(SELECT IndustryDetailsId FROM dbo.WorkflowJsonVersion WHERE WorkflowJsonVersionId=@V1),@PGeo,NULL,'Geographic Diversification','Score',25,1);
IF NOT EXISTS(SELECT 1 FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V1 AND ParameterDefinitionMasterId=@PTech)
 INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId,IndustryDetailsId,ParameterDefinitionMasterId,ParentIndustryParameterMappingId,ParameterDisplayName,ValueType,Weight,IsActive) VALUES(@V1,(SELECT IndustryDetailsId FROM dbo.WorkflowJsonVersion WHERE WorkflowJsonVersionId=@V1),@PTech,NULL,'Technology & Product Development Capabilities','Score',20,1);

IF NOT EXISTS(SELECT 1 FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V2 AND ParameterDefinitionMasterId=@PMarket)
 INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId,IndustryDetailsId,ParameterDefinitionMasterId,ParentIndustryParameterMappingId,ParameterDisplayName,ValueType,Weight,IsActive) VALUES(@V2,(SELECT IndustryDetailsId FROM dbo.WorkflowJsonVersion WHERE WorkflowJsonVersionId=@V2),@PMarket,NULL,'Market Position & Brand Strength','Number',20,1);
IF NOT EXISTS(SELECT 1 FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V2 AND ParameterDefinitionMasterId=@PScale)
 INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId,IndustryDetailsId,ParameterDefinitionMasterId,ParentIndustryParameterMappingId,ParameterDisplayName,ValueType,Weight,IsActive) VALUES(@V2,(SELECT IndustryDetailsId FROM dbo.WorkflowJsonVersion WHERE WorkflowJsonVersionId=@V2),@PScale,NULL,'Scale','Number',10,1);
IF NOT EXISTS(SELECT 1 FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V2 AND ParameterDefinitionMasterId=@PPortfolio)
 INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId,IndustryDetailsId,ParameterDefinitionMasterId,ParentIndustryParameterMappingId,ParameterDisplayName,ValueType,Weight,IsActive) VALUES(@V2,(SELECT IndustryDetailsId FROM dbo.WorkflowJsonVersion WHERE WorkflowJsonVersionId=@V2),@PPortfolio,NULL,'Product Portfolio','Score',25,1);
IF NOT EXISTS(SELECT 1 FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V2 AND ParameterDefinitionMasterId=@PGeo)
 INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId,IndustryDetailsId,ParameterDefinitionMasterId,ParentIndustryParameterMappingId,ParameterDisplayName,ValueType,Weight,IsActive) VALUES(@V2,(SELECT IndustryDetailsId FROM dbo.WorkflowJsonVersion WHERE WorkflowJsonVersionId=@V2),@PGeo,NULL,'Geographic Diversification','Score',25,1);
IF NOT EXISTS(SELECT 1 FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V2 AND ParameterDefinitionMasterId=@PTech)
 INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId,IndustryDetailsId,ParameterDefinitionMasterId,ParentIndustryParameterMappingId,ParameterDisplayName,ValueType,Weight,IsActive) VALUES(@V2,(SELECT IndustryDetailsId FROM dbo.WorkflowJsonVersion WHERE WorkflowJsonVersionId=@V2),@PTech,NULL,'Technology & Product Development Capabilities','Score',20,1);

SELECT @MapV1Market=IndustryParameterMappingId FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V1 AND ParameterDefinitionMasterId=@PMarket;
SELECT @MapV1Scale=IndustryParameterMappingId FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V1 AND ParameterDefinitionMasterId=@PScale;
SELECT @MapV1Portfolio=IndustryParameterMappingId FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V1 AND ParameterDefinitionMasterId=@PPortfolio;
SELECT @MapV1Geo=IndustryParameterMappingId FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V1 AND ParameterDefinitionMasterId=@PGeo;
SELECT @MapV1Tech=IndustryParameterMappingId FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V1 AND ParameterDefinitionMasterId=@PTech;
SELECT @MapV2Market=IndustryParameterMappingId FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V2 AND ParameterDefinitionMasterId=@PMarket;
SELECT @MapV2Scale=IndustryParameterMappingId FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V2 AND ParameterDefinitionMasterId=@PScale;
SELECT @MapV2Portfolio=IndustryParameterMappingId FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V2 AND ParameterDefinitionMasterId=@PPortfolio;
SELECT @MapV2Geo=IndustryParameterMappingId FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V2 AND ParameterDefinitionMasterId=@PGeo;
SELECT @MapV2Tech=IndustryParameterMappingId FROM dbo.IndustryParameterMapping WHERE WorkflowJsonVersionId=@V2 AND ParameterDefinitionMasterId=@PTech;

/* Scale tables preserve the original V19 score labels, values, ranges and units. */
IF NOT EXISTS(SELECT 1 FROM dbo.ScaleConfiguration WHERE ScaleCode='MarketPositionScore') INSERT dbo.ScaleConfiguration(ScaleCode,ScaleName,MinValue,MaxValue,IsActive) VALUES('MarketPositionScore','Market Position & Brand Strength',0,100,1);
IF NOT EXISTS(SELECT 1 FROM dbo.ScaleConfiguration WHERE ScaleCode='ScaleScore') INSERT dbo.ScaleConfiguration(ScaleCode,ScaleName,MinValue,MaxValue,IsActive) VALUES('ScaleScore','Scale (Rs. Crore)',0,1000000,1);
IF NOT EXISTS(SELECT 1 FROM dbo.ScaleConfiguration WHERE ScaleCode='ProductPortfolioScore') INSERT dbo.ScaleConfiguration(ScaleCode,ScaleName,MinValue,MaxValue,IsActive) VALUES('ProductPortfolioScore','Product Portfolio Subsegments',0,100,1);
IF NOT EXISTS(SELECT 1 FROM dbo.ScaleConfiguration WHERE ScaleCode='GeographicDiversificationScore') INSERT dbo.ScaleConfiguration(ScaleCode,ScaleName,MinValue,MaxValue,IsActive) VALUES('GeographicDiversificationScore','Geographic Diversification Regions',0,100,1);
IF NOT EXISTS(SELECT 1 FROM dbo.ScaleConfiguration WHERE ScaleCode='TechnologyScore') INSERT dbo.ScaleConfiguration(ScaleCode,ScaleName,MinValue,MaxValue,IsActive) VALUES('TechnologyScore','Technology & Product Development (% R&D)',0,100,1);
DECLARE @SMarket INT=(SELECT ScaleConfigurationId FROM dbo.ScaleConfiguration WHERE ScaleCode='MarketPositionScore');
DECLARE @SScale INT=(SELECT ScaleConfigurationId FROM dbo.ScaleConfiguration WHERE ScaleCode='ScaleScore');
DECLARE @SPortfolio INT=(SELECT ScaleConfigurationId FROM dbo.ScaleConfiguration WHERE ScaleCode='ProductPortfolioScore');
DECLARE @SGeo INT=(SELECT ScaleConfigurationId FROM dbo.ScaleConfiguration WHERE ScaleCode='GeographicDiversificationScore');
DECLARE @STech INT=(SELECT ScaleConfigurationId FROM dbo.ScaleConfiguration WHERE ScaleCode='TechnologyScore');

/* Insert score bands for each version mapping; endpoints are adjusted only to represent V19 exclusive boundaries in schema without inclusive flags. */
DECLARE @Bands TABLE(MapId INT, ScaleId INT, ScoreValue DECIMAL(10,2), Definition VARCHAR(256), MinValue DECIMAL(10,2), MaxValue DECIMAL(10,2));
INSERT @Bands VALUES
(@MapV1Market,@SMarket,1,'Market share > 30%',30.01,100),(@MapV1Market,@SMarket,2,'Market share 20-30%',20.01,30),(@MapV1Market,@SMarket,3,'Market share 10-20%',10.01,20),(@MapV1Market,@SMarket,4,'Market share 5-10%',5.01,10),(@MapV1Market,@SMarket,5,'Market share below 5%',0,5),
(@MapV2Market,@SMarket,1,'Market share > 30%',30.01,100),(@MapV2Market,@SMarket,2,'Market share 20-30%',20.01,30),(@MapV2Market,@SMarket,3,'Market share 10-20%',10.01,20),(@MapV2Market,@SMarket,4,'Market share 5-10%',5.01,10),(@MapV2Market,@SMarket,5,'Market share below 5%',0,5),
(@MapV1Scale,@SScale,1,'Revenue > 20,000',20000.01,1000000),(@MapV1Scale,@SScale,2,'Revenue 10,000-20,000',10000.01,20000),(@MapV1Scale,@SScale,3,'Revenue 5,000-10,000',5000.01,10000),(@MapV1Scale,@SScale,4,'Revenue 1,000-5,000',1000.01,5000),(@MapV1Scale,@SScale,5,'Revenue < 1,000',0,1000),
(@MapV2Scale,@SScale,1,'Revenue > 20,000',20000.01,1000000),(@MapV2Scale,@SScale,2,'Revenue 10,000-20,000',10000.01,20000),(@MapV2Scale,@SScale,3,'Revenue 5,000-10,000',5000.01,10000),(@MapV2Scale,@SScale,4,'Revenue 1,000-5,000',1000.01,5000),(@MapV2Scale,@SScale,5,'Revenue < 1,000',0,1000),
(@MapV1Portfolio,@SPortfolio,1,'Very diversified portfolio across all key subsegments',5,100),(@MapV1Portfolio,@SPortfolio,2,'Broad portfolio with strong presence across most subsegments',4,5),(@MapV1Portfolio,@SPortfolio,3,'Moderately diversified portfolio',3,4),(@MapV1Portfolio,@SPortfolio,4,'Limited portfolio concentration',2,3),(@MapV1Portfolio,@SPortfolio,5,'Highly concentrated portfolio',0,2),
(@MapV2Portfolio,@SPortfolio,1,'Very diversified portfolio across all key subsegments',5,100),(@MapV2Portfolio,@SPortfolio,2,'Broad portfolio with strong presence across most subsegments',4,5),(@MapV2Portfolio,@SPortfolio,3,'Moderately diversified portfolio',3,4),(@MapV2Portfolio,@SPortfolio,4,'Limited portfolio concentration',2,3),(@MapV2Portfolio,@SPortfolio,5,'Highly concentrated portfolio',0,2),
(@MapV1Geo,@SGeo,1,'Highly diversified across regions and exports',4,100),(@MapV1Geo,@SGeo,2,'Healthy diversification across 3-4 regions',3,4),(@MapV1Geo,@SGeo,3,'Moderate diversification across at least 2 regions',2,3),(@MapV1Geo,@SGeo,4,'Limited diversification across 1-2 regions',1,2),(@MapV1Geo,@SGeo,5,'Low diversification / specific region or domestic only',0,1),
(@MapV2Geo,@SGeo,1,'Highly diversified across regions and exports',4,100),(@MapV2Geo,@SGeo,2,'Healthy diversification across 3-4 regions',3,4),(@MapV2Geo,@SGeo,3,'Moderate diversification across at least 2 regions',2,3),(@MapV2Geo,@SGeo,4,'Limited diversification across 1-2 regions',1,2),(@MapV2Geo,@SGeo,5,'Low diversification / specific region or domestic only',0,1),
(@MapV1Tech,@STech,1,'R&D spend > 5% with strong capabilities',5.01,100),(@MapV1Tech,@STech,2,'R&D spend 2-5% with adequate capabilities',4,5),(@MapV1Tech,@STech,3,'R&D spend 2-5% with moderate capabilities',3,4),(@MapV1Tech,@STech,4,'R&D spend 2-5% with limited capabilities',2,3),(@MapV1Tech,@STech,5,'R&D spend < 2%',0,2),
(@MapV2Tech,@STech,1,'R&D spend > 5% with strong capabilities',5.01,100),(@MapV2Tech,@STech,2,'R&D spend 2-5% with adequate capabilities',4,5),(@MapV2Tech,@STech,3,'R&D spend 2-5% with moderate capabilities',3,4),(@MapV2Tech,@STech,4,'R&D spend 2-5% with limited capabilities',2,3),(@MapV2Tech,@STech,5,'R&D spend < 2%',0,2);
INSERT dbo.ScaleConfigurationDetails(IndustryParameterMappingId,ScaleConfigurationId,ScoreValue,Definition,MinValue,MaxValue)
SELECT b.MapId,b.ScaleId,b.ScoreValue,b.Definition,b.MinValue,b.MaxValue FROM @Bands b
WHERE NOT EXISTS(SELECT 1 FROM dbo.ScaleConfigurationDetails d WHERE d.IndustryParameterMappingId=b.MapId AND d.ScaleConfigurationId=b.ScaleId AND d.ScoreValue=b.ScoreValue);

/* Exact V19 rule records for each version */
IF NOT EXISTS(SELECT 1 FROM dbo.RuleDefinition WHERE WorkflowJsonVersionId=@V1 AND RuleName='CalculateWeightedAverage')
 INSERT dbo.RuleDefinition(WorkflowJsonVersionId,RuleName,RuleExpressionType,OutputExpression,IsActive) VALUES(@V1,'CalculateWeightedAverage','LambdaExpression','(input1.MarketPositionScore * 15 + input1.ScaleScore * 15 + input1.ProductPortfolioScore * 25 + input1.GeographicDiversificationScore * 25 + input1.TechnologyScore * 20) / 100.0',1);
IF NOT EXISTS(SELECT 1 FROM dbo.RuleDefinition WHERE WorkflowJsonVersionId=@V2 AND RuleName='CalculateWeightedAverage')
 INSERT dbo.RuleDefinition(WorkflowJsonVersionId,RuleName,RuleExpressionType,OutputExpression,IsActive) VALUES(@V2,'CalculateWeightedAverage','LambdaExpression','(input1.MarketPositionScore * 20 + input1.ScaleScore * 10 + input1.ProductPortfolioScore * 25 + input1.GeographicDiversificationScore * 25 + input1.TechnologyScore * 20) / 100.0',1);

/* V19 has no seeded ValidationDefinition rows in its original SQL scripts, so none are invented here. */

/* V19 initial assessment: exact values/scores and framework labels from the original seed script. */
DECLARE @EntityId INT=(SELECT EntityId FROM dbo.CustomerMaster WHERE EntityName='20 Microns Limited');
DECLARE @InitialResponse NVARCHAR(MAX)=N'{"FrameworkName":"09-Sep-2026 - Draft","FrameworkDate":"2026-09-09","WorkflowVersionNo":1,"ConsolidatedView":false,"Values":[{"ParameterCode":"MarketPositionScore","Value":52,"Score":1},{"ParameterCode":"ScaleScore","Value":52,"Score":5},{"ParameterCode":"ProductPortfolioScore","Value":null,"Score":1},{"ParameterCode":"GeographicDiversificationScore","Value":null,"Score":1},{"ParameterCode":"TechnologyScore","Value":null,"Score":1}],"Evaluation":null}';
IF @EntityId IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.AssessmentResponse WHERE EntityId=@EntityId AND WorkflowJsonVersionId=@V1)
 INSERT dbo.AssessmentResponse(EntityId,WorkflowJsonVersionId,ResponseJson,Status) VALUES(@EntityId,@V1,@InitialResponse,'Draft');

/* Exact additional V19 framework dropdown labels. These are represented as separate response snapshots. */
DECLARE @OldFrameworks TABLE(FrameworkName VARCHAR(128), FrameworkDate DATE, Status VARCHAR(30));
INSERT @OldFrameworks VALUES
('03-Sep-2026','2026-09-03','Saved'),('25-Aug-2026','2026-08-25','Saved'),('24-Aug-2026 17:48','2026-08-24','Saved')
/* Keep the exact labels in JSON for these historical snapshots. */
DECLARE @OldFrameworkName VARCHAR(128), @OldFrameworkDate DATE, @OldStatus VARCHAR(30), @OldJson NVARCHAR(MAX);
DECLARE old_framework_cursor CURSOR LOCAL FAST_FORWARD FOR SELECT FrameworkName,FrameworkDate,Status FROM @OldFrameworks;
OPEN old_framework_cursor;
FETCH NEXT FROM old_framework_cursor INTO @OldFrameworkName,@OldFrameworkDate,@OldStatus;
WHILE @@FETCH_STATUS=0
BEGIN
 SET @OldJson=N'{"FrameworkName":"'+@OldFrameworkName+N'","FrameworkDate":"'+CONVERT(NVARCHAR(10),@OldFrameworkDate,23)+N'","WorkflowVersionNo":1,"ConsolidatedView":false,"Values":[{"ParameterCode":"MarketPositionScore","Value":null,"Score":1},{"ParameterCode":"ScaleScore","Value":null,"Score":1},{"ParameterCode":"ProductPortfolioScore","Value":null,"Score":1},{"ParameterCode":"GeographicDiversificationScore","Value":null,"Score":1},{"ParameterCode":"TechnologyScore","Value":null,"Score":1}],"Evaluation":null}';
 IF @EntityId IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.AssessmentResponse WHERE EntityId=@EntityId AND WorkflowJsonVersionId=@V1 AND ResponseJson LIKE N'%"FrameworkName":"'+@OldFrameworkName+N'"%')
   INSERT dbo.AssessmentResponse(EntityId,WorkflowJsonVersionId,ResponseJson,Status) VALUES(@EntityId,@V1,@OldJson,@OldStatus);
 FETCH NEXT FROM old_framework_cursor INTO @OldFrameworkName,@OldFrameworkDate,@OldStatus;
END
CLOSE old_framework_cursor;
DEALLOCATE old_framework_cursor;


/* ------------------------------ Verify ------------------------------ */
SELECT 'IndustryDetails' AS TableName, COUNT(*) AS TotalRows FROM dbo.IndustryDetails
UNION ALL SELECT 'CustomerMaster',COUNT(*) FROM dbo.CustomerMaster
UNION ALL SELECT 'ParameterDefinitionMaster',COUNT(*) FROM dbo.ParameterDefinitionMaster
UNION ALL SELECT 'WorkflowJsonVersion',COUNT(*) FROM dbo.WorkflowJsonVersion
UNION ALL SELECT 'IndustryParameterMapping',COUNT(*) FROM dbo.IndustryParameterMapping
UNION ALL SELECT 'ValidationDefinition',COUNT(*) FROM dbo.ValidationDefinition
UNION ALL SELECT 'RuleDefinition',COUNT(*) FROM dbo.RuleDefinition
UNION ALL SELECT 'ScaleConfiguration',COUNT(*) FROM dbo.ScaleConfiguration
UNION ALL SELECT 'ScaleConfigurationDetails',COUNT(*) FROM dbo.ScaleConfigurationDetails
UNION ALL SELECT 'AssessmentResponse',COUNT(*) FROM dbo.AssessmentResponse;
GO









CREATE TABLE dbo.FrameworkGeneral
(
    FrameworkGeneralId INT IDENTITY(1,1) PRIMARY KEY,
    AssessmentResponseId INT NOT NULL,
    EntityId INT NOT NULL,
    WorkflowJsonVersionId INT NOT NULL,
    NoOfPastYears INT NULL,
    NoOfProjectedYears INT NULL,
    LatestFinancialYear INT NULL,
    IsListed BIT NOT NULL DEFAULT(0),
    IsParentSupported BIT NOT NULL DEFAULT(0),
    ParentType VARCHAR(100) NULL,
    CreatedOn DATETIME2 NOT NULL DEFAULT(SYSUTCDATETIME()),
    UpdatedOn DATETIME2 NULL,

    CONSTRAINT FK_FrameworkGeneral_Assessment FOREIGN KEY(AssessmentResponseId)
        REFERENCES dbo.AssessmentResponse(AssessmentResponseId),

    CONSTRAINT FK_FrameworkGeneral_Entity FOREIGN KEY(EntityId)
        REFERENCES dbo.CustomerMaster(EntityId),

    CONSTRAINT FK_FrameworkGeneral_Workflow FOREIGN KEY(WorkflowJsonVersionId)
        REFERENCES dbo.WorkflowJsonVersion(WorkflowJsonVersionId)
);

----------------------------------------
--Alter table

ALTER TABLE IndustryParameterMapping
ADD
    StepName VARCHAR(50) NULL,
    ControlType VARCHAR(50) NULL;

    select * from IndustryParameterMapping

------------------------------------------
--ParameterFieldDefinition table

CREATE TABLE dbo.ParameterFieldDefinition
(
    ParameterFieldDefinitionId INT IDENTITY(1,1) PRIMARY KEY,
    IndustryParameterMappingId INT NOT NULL,
    FieldName VARCHAR(500) NOT NULL,
    FieldType VARCHAR(50) NOT NULL,
    DisplayOrder INT NOT NULL,
    IsRequired BIT NOT NULL DEFAULT(0),
    IsActive BIT NOT NULL DEFAULT(1),
    CONSTRAINT FK_ParameterFieldDefinition_IPM FOREIGN KEY(IndustryParameterMappingId)
    REFERENCES dbo.IndustryParameterMapping(IndustryParameterMappingId)
);

select * from ParameterFieldDefinition

------------
--create table FrameworkParameterResponse

CREATE TABLE dbo.FrameworkParameterResponse
(
    FrameworkParameterResponseId INT IDENTITY(1,1) PRIMARY KEY,
    AssessmentResponseId INT NOT NULL,
    IndustryParameterMappingId INT NOT NULL,
    ParameterFieldDefinitionId INT NOT NULL,
    FieldValue NVARCHAR(MAX) NULL,
    CreatedOn DATETIME NOT NULL DEFAULT GETDATE(),
    UpdatedOn DATETIME NULL
);

select * from FrameworkParameterResponse



Use CRISP2_UAT

Alter Table ValidationDefinition
Add DisplayOrder INT Not Null
Constraint DF_ValidationDefinition_DisplayOrder
Default(1);


CREATE TABLE dbo.WorkflowStep
(
    WorkflowStepId INT IDENTITY(1,1) PRIMARY KEY,
    WorkflowJsonVersionId INT NOT NULL,
    StepCode VARCHAR(50) NOT NULL,
    StepName VARCHAR(100) NOT NULL,
    PageType VARCHAR(20) NOT NULL DEFAULT('Parameters'),
    DisplayOrder INT NOT NULL,
    IsActive BIT NOT NULL DEFAULT(1),
    CONSTRAINT FK_WorkflowStep_Version
        FOREIGN KEY (WorkflowJsonVersionId)
        REFERENCES WorkflowJsonVersion(WorkflowJsonVersionId)
        ON DELETE CASCADE,
    CONSTRAINT UQ_WorkflowStep
        UNIQUE (WorkflowJsonVersionId, StepCode)
);

ALTER TABLE IndustryParameterMapping
ADD
    ScoreFieldCode VARCHAR(100) NULL,
    YearFromOffset INT NULL,
    YearColumns INT NULL;




    Use CRISP2_UAT
GO

/* ---------- 1. Steps per version ---------- */
IF OBJECT_ID('dbo.WorkflowStep','U') IS NULL
CREATE TABLE dbo.WorkflowStep(
    WorkflowStepId        INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WorkflowStep PRIMARY KEY,
    WorkflowJsonVersionId INT          NOT NULL,
    StepCode              VARCHAR(50)  NOT NULL,   -- same value as IndustryParameterMapping.StepName
    StepName              VARCHAR(100) NOT NULL,   -- text in the step bar
    PageType              VARCHAR(20)  NOT NULL CONSTRAINT DF_WS_PageType DEFAULT('Parameters'),
                                                   -- Business | General | Parameters
    DisplayOrder          INT          NOT NULL,
    IsActive              BIT          NOT NULL CONSTRAINT DF_WS_IsActive DEFAULT(1),
    CONSTRAINT FK_WS_Version FOREIGN KEY(WorkflowJsonVersionId)
        REFERENCES dbo.WorkflowJsonVersion(WorkflowJsonVersionId) ON DELETE CASCADE,
    CONSTRAINT UQ_WS_Version_Code UNIQUE(WorkflowJsonVersionId, StepCode)
);
GO
/* default steps for every existing version */
INSERT dbo.WorkflowStep(WorkflowJsonVersionId, StepCode, StepName, PageType, DisplayOrder)
SELECT v.WorkflowJsonVersionId, s.StepCode, s.StepName, s.PageType, s.DisplayOrder
  FROM dbo.WorkflowJsonVersion v
 CROSS JOIN (VALUES
        ('Business',    'Business',     'Business',   1),
        ('General',     'General',      'General',    2),
        ('Others',      'Others',       'Parameters', 3),
        ('ParentGroup', 'Parent/Group', 'Parameters', 4),
        ('Output',      'Output',       'Parameters', 5),
        ('Sensitivity', 'Sensitivity',  'Parameters', 6),
        ('Summary',     'Summary',      'Parameters', 7),
        ('Benchmarks',  'Benchmarks',   'Parameters', 8)
     ) s(StepCode, StepName, PageType, DisplayOrder)
 WHERE NOT EXISTS (SELECT 1 FROM dbo.WorkflowStep w
                    WHERE w.WorkflowJsonVersionId = v.WorkflowJsonVersionId AND w.StepCode = s.StepCode);
GO

/* ---------- 2. Parameter mapping: score field + years for popups ---------- */
IF COL_LENGTH('dbo.IndustryParameterMapping','ScoreFieldCode') IS NULL
    ALTER TABLE dbo.IndustryParameterMapping ADD
        ScoreFieldCode VARCHAR(100) NULL,   -- field whose value is this parameter's score (e.g. LIQ_MIN_SCORE)
        YearFromOffset INT NULL,            -- popup first year = LatestFinancialYear + offset (0 = latest FY)
        YearColumns    INT NULL;            -- number of year columns (2 = FY2024, FY2025)
GO
/* same master parameter may appear under different parents */
IF EXISTS (SELECT 1 FROM sys.key_constraints WHERE name = 'UQ_IPM_Version_Industry_Parameter')
    ALTER TABLE dbo.IndustryParameterMapping DROP CONSTRAINT UQ_IPM_Version_Industry_Parameter;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UQ_IPM_Version_Industry_Parameter_Parent')
    CREATE UNIQUE INDEX UQ_IPM_Version_Industry_Parameter_Parent
        ON dbo.IndustryParameterMapping(WorkflowJsonVersionId, IndustryDetailsId,
                                        ParameterDefinitionMasterId, ParentIndustryParameterMappingId);
GO

/* ---------- 3. Popup fields: code, section, year-wise, formula ---------- */
IF COL_LENGTH('dbo.ParameterFieldDefinition','FieldCode') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD
        FieldCode     VARCHAR(100) NULL,        -- used inside formulas: [CFO]
        SectionName   VARCHAR(200) NULL,        -- table title inside the popup
        IsYearWise    BIT NOT NULL CONSTRAINT DF_PFD_IsYearWise DEFAULT(0),   -- one value per year column
        Formula       VARCHAR(MAX) NULL,        -- empty = analyst types it
        DefaultValue  VARCHAR(100) NULL,        -- e.g. 25
        IsOverridable BIT NOT NULL CONSTRAINT DF_PFD_IsOverridable DEFAULT(0), -- analyst may change a calculated value
        OptionsJson   VARCHAR(MAX) NULL;        -- ["Yes","No"] for dropdown / radio
GO
UPDATE dbo.ParameterFieldDefinition SET FieldCode = CONCAT('F', ParameterFieldDefinitionId) WHERE FieldCode IS NULL;
ALTER TABLE dbo.ParameterFieldDefinition ALTER COLUMN FieldCode VARCHAR(100) NOT NULL;
GO

/* ---------- 4. Answers: one row per field per year ---------- */
IF COL_LENGTH('dbo.FrameworkParameterResponse','FinancialYear') IS NULL
    ALTER TABLE dbo.FrameworkParameterResponse ADD
        FinancialYear INT NULL,
        IsOverridden  BIT NOT NULL CONSTRAINT DF_FPR_IsOverridden DEFAULT(0);
GO
;WITH d AS (SELECT ROW_NUMBER() OVER (PARTITION BY AssessmentResponseId, ParameterFieldDefinitionId, FinancialYear
                                     ORDER BY FrameworkParameterResponseId DESC) rn
              FROM dbo.FrameworkParameterResponse)
DELETE FROM d WHERE rn > 1;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UQ_FPR_Assessment_Field_Year')
    CREATE UNIQUE INDEX UQ_FPR_Assessment_Field_Year
        ON dbo.FrameworkParameterResponse(AssessmentResponseId, ParameterFieldDefinitionId, FinancialYear);
IF OBJECT_ID('dbo.FK_FPR_Assessment','F') IS NULL
    ALTER TABLE dbo.FrameworkParameterResponse ADD CONSTRAINT FK_FPR_Assessment
        FOREIGN KEY(AssessmentResponseId) REFERENCES dbo.AssessmentResponse(AssessmentResponseId) ON DELETE CASCADE;
IF OBJECT_ID('dbo.FK_FPR_Field','F') IS NULL
    ALTER TABLE dbo.FrameworkParameterResponse ADD CONSTRAINT FK_FPR_Field
        FOREIGN KEY(ParameterFieldDefinitionId) REFERENCES dbo.ParameterFieldDefinition(ParameterFieldDefinitionId);
GO

/* ---------- 5. Score per parameter per framework ---------- */
IF OBJECT_ID('dbo.FrameworkParameterScore','U') IS NULL
CREATE TABLE dbo.FrameworkParameterScore(
    FrameworkParameterScoreId  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_FrameworkParameterScore PRIMARY KEY,
    AssessmentResponseId       INT NOT NULL,
    IndustryParameterMappingId INT NOT NULL,
    CalculatedScore            DECIMAL(10,2) NULL,   -- from ScoreFieldCode (Liquidity)
    AnalystScore               DECIMAL(10,2) NULL,   -- dropdown on the step screen
    UpdatedOn                  DATETIME2 NOT NULL CONSTRAINT DF_FPS_UpdatedOn DEFAULT(SYSUTCDATETIME()),
    CONSTRAINT FK_FPS_Assessment FOREIGN KEY(AssessmentResponseId)
        REFERENCES dbo.AssessmentResponse(AssessmentResponseId) ON DELETE CASCADE,
    CONSTRAINT FK_FPS_IPM FOREIGN KEY(IndustryParameterMappingId)
        REFERENCES dbo.IndustryParameterMapping(IndustryParameterMappingId),
    CONSTRAINT UQ_FPS UNIQUE(AssessmentResponseId, IndustryParameterMappingId)
);
GO

/* ---------- 6. Fixes found in the current database ---------- */
/* EF entity has DisplayOrder, table does not -> validation queries fail */
IF COL_LENGTH('dbo.ValidationDefinition','DisplayOrder') IS NULL
    ALTER TABLE dbo.ValidationDefinition ADD DisplayOrder INT NOT NULL CONSTRAINT DF_VD_DisplayOrder DEFAULT(0);
/* labels with special characters */
ALTER TABLE dbo.WorkflowJsonVersion ALTER COLUMN JsonContent NVARCHAR(MAX) NOT NULL;
ALTER TABLE dbo.RuleDefinition ALTER COLUMN OutputExpression VARCHAR(MAX) NOT NULL;
/* values the code expects */
UPDATE dbo.IndustryParameterMapping SET ValueType = 'Value'       WHERE ValueType = 'Number';
UPDATE dbo.IndustryParameterMapping SET ValueType = 'ManualScore' WHERE ValueType = 'Score';
UPDATE dbo.IndustryParameterMapping SET ControlType = 'Module'    WHERE ControlType = 'LiquidityModule';
UPDATE dbo.IndustryParameterMapping SET StepName = 'Business'     WHERE StepName IS NULL;
/* rule engine gets each score as its own parameter, there is no input1 */
UPDATE dbo.RuleDefinition      SET OutputExpression = REPLACE(OutputExpression, 'input1.', '');
UPDATE dbo.WorkflowJsonVersion SET JsonContent      = REPLACE(JsonContent, 'input1.', '');
GO



Use CRISP2_UAT

/*
 CRISP 2.0 - Liquidity (Others tab) through the rule engine.
 Replaces the stored procedure GetLiquidityDetails.
 Safe to rerun: every change is guarded.
*/

-- ---------------------------------------------------------------- CustomerMaster
-- key of the customer in the spread tables (CustomerToSpreadRecordsYYYY.CustomerCode)
IF COL_LENGTH('dbo.CustomerMaster', 'CustomerCode') IS NULL
    ALTER TABLE dbo.CustomerMaster ADD CustomerCode VARCHAR(50) NULL;
GO

-- ---------------------------------------------------------------- IndustryParameterMapping
IF COL_LENGTH('dbo.IndustryParameterMapping', 'StepName') IS NULL
    ALTER TABLE dbo.IndustryParameterMapping ADD StepName VARCHAR(100) NULL;
IF COL_LENGTH('dbo.IndustryParameterMapping', 'ControlType') IS NULL
    ALTER TABLE dbo.IndustryParameterMapping ADD ControlType VARCHAR(50) NULL;
-- popup year columns: first year = General.LatestFinancialYear + YearFromOffset, YearColumns columns
IF COL_LENGTH('dbo.IndustryParameterMapping', 'YearFromOffset') IS NULL
    ALTER TABLE dbo.IndustryParameterMapping ADD YearFromOffset INT NULL;
IF COL_LENGTH('dbo.IndustryParameterMapping', 'YearColumns') IS NULL
    ALTER TABLE dbo.IndustryParameterMapping ADD YearColumns INT NULL;
-- score rules of a popup are kept in RuleDefinition (below); remove the earlier JSON column
IF COL_LENGTH('dbo.IndustryParameterMapping', 'RulesJson') IS NOT NULL
    ALTER TABLE dbo.IndustryParameterMapping DROP COLUMN RulesJson;
-- "Show Details" panel on the Others tab (HTML, entered by admin)
IF COL_LENGTH('dbo.IndustryParameterMapping', 'DetailsDescription') IS NULL
    ALTER TABLE dbo.IndustryParameterMapping ADD DetailsDescription NVARCHAR(MAX) NULL;  -- first column of the assessment table
IF COL_LENGTH('dbo.IndustryParameterMapping', 'DetailsNote') IS NULL
    ALTER TABLE dbo.IndustryParameterMapping ADD DetailsNote NVARCHAR(MAX) NULL;         -- notes under the assessment table
GO

-- ---------------------------------------------------------------- RuleDefinition
-- one table for all rules of a version:
--   IndustryParameterMappingId NULL     -> framework rule (CalculateWeightedAverage, in the version JSON)
--   IndustryParameterMappingId = popup  -> score rule of that popup (e.g. Liquidity):
--                                          Expression = condition, OutputExpression = score,
--                                          lowest DisplayOrder that matches wins
IF COL_LENGTH('dbo.RuleDefinition', 'IndustryParameterMappingId') IS NULL
    ALTER TABLE dbo.RuleDefinition ADD IndustryParameterMappingId INT NULL
        CONSTRAINT FK_RuleDefinition_IPM REFERENCES dbo.IndustryParameterMapping(IndustryParameterMappingId);
IF COL_LENGTH('dbo.RuleDefinition', 'Expression') IS NULL
    ALTER TABLE dbo.RuleDefinition ADD Expression VARCHAR(2000) NULL;               -- condition; NULL = true
IF COL_LENGTH('dbo.RuleDefinition', 'DisplayOrder') IS NULL
    ALTER TABLE dbo.RuleDefinition ADD DisplayOrder INT NOT NULL CONSTRAINT DF_RuleDefinition_DisplayOrder DEFAULT(0);
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.RuleDefinition')
           AND name = 'OutputExpression' AND max_length BETWEEN 1 AND 1999)
    ALTER TABLE dbo.RuleDefinition ALTER COLUMN OutputExpression VARCHAR(2000) NOT NULL;
GO

-- ---------------------------------------------------------------- ScaleConfigurationDetails
-- long text of a score in the "Show Details" assessment table (Definition stays the short label)
IF COL_LENGTH('dbo.ScaleConfigurationDetails', 'ScoreDescription') IS NULL
    ALTER TABLE dbo.ScaleConfigurationDetails ADD ScoreDescription NVARCHAR(MAX) NULL;
GO

-- ---------------------------------------------------------------- ParameterFieldDefinition
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'FieldCode') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD FieldCode VARCHAR(100) NULL;            -- name used in formulas
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'SectionName') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD SectionName VARCHAR(300) NULL;          -- table on the popup; 'Hidden' = not shown
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'IsYearWise') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD IsYearWise BIT NOT NULL CONSTRAINT DF_PFD_IsYearWise DEFAULT(0);
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'SourceType') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD SourceType VARCHAR(20) NOT NULL CONSTRAINT DF_PFD_SourceType DEFAULT('Input');  -- Input | Spread | Formula
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'SpreadRows') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD SpreadRows VARCHAR(200) NULL;           -- '264,265'
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'SpreadByTemplate') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD SpreadByTemplate BIT NOT NULL CONSTRAINT DF_PFD_SpreadByTemplate DEFAULT(0);  -- 1 = SpreadRows are TemplateCodes
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'SpreadSign') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD SpreadSign SMALLINT NOT NULL CONSTRAINT DF_PFD_SpreadSign DEFAULT(1);         -- 1 or -1
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'SpreadYearOffset') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD SpreadYearOffset INT NOT NULL CONSTRAINT DF_PFD_SpreadYearOffset DEFAULT(0);  -- -1 previous, +1 next year
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'Formula') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD Formula NVARCHAR(2000) NULL;            -- RulesEngine expression, e.g. CFO + CASH_BEGIN
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'DefaultValue') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD DefaultValue NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'IsOverridable') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD IsOverridable BIT NOT NULL CONSTRAINT DF_PFD_IsOverridable DEFAULT(0);
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'OptionsJson') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD OptionsJson NVARCHAR(1000) NULL;        -- '["Yes","No"]'
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'ChartSign') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD ChartSign SMALLINT NULL;                -- waterfall: 1 add, -1 subtract, 0 total
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'ResultRole') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD ResultRole VARCHAR(20) NULL;            -- Score | ParentScore | MinScore
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'HelpText') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD HelpText NVARCHAR(1000) NULL;          -- (i) icon tooltip
IF COL_LENGTH('dbo.ParameterFieldDefinition', 'ShowWhen') IS NULL
    ALTER TABLE dbo.ParameterFieldDefinition ADD ShowWhen VARCHAR(200) NULL;             -- e.g. CL_EXISTS=Yes (show only then)
GO

-- note / spacer rows are text, not values: FieldName may be long
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.ParameterFieldDefinition')
           AND name = 'FieldName' AND max_length BETWEEN 1 AND 1999)
    ALTER TABLE dbo.ParameterFieldDefinition ALTER COLUMN FieldName VARCHAR(2000) NOT NULL;
GO

-- ---------------------------------------------------------------- FrameworkParameterResponse
IF COL_LENGTH('dbo.FrameworkParameterResponse', 'FinancialYear') IS NULL
    ALTER TABLE dbo.FrameworkParameterResponse ADD FinancialYear INT NULL;
IF COL_LENGTH('dbo.FrameworkParameterResponse', 'IsOverridden') IS NULL
    ALTER TABLE dbo.FrameworkParameterResponse ADD IsOverridden BIT NOT NULL CONSTRAINT DF_FPR_IsOverridden DEFAULT(0);
GO

-- one answer per assessment + field + year
-- (drop any older unique index on this table that does not include FinancialYear)
DECLARE @sql NVARCHAR(MAX) = N'';
SELECT @sql += N'DROP INDEX ' + QUOTENAME(i.name) + N' ON dbo.FrameworkParameterResponse;'
FROM sys.indexes i
WHERE i.object_id = OBJECT_ID('dbo.FrameworkParameterResponse')
  AND i.is_unique = 1 AND i.is_primary_key = 0 AND i.is_unique_constraint = 0
  AND i.name <> 'UX_FPR_Assessment_Field_Year';
EXEC sp_executesql @sql;

SET @sql = N'';
SELECT @sql += N'ALTER TABLE dbo.FrameworkParameterResponse DROP CONSTRAINT ' + QUOTENAME(k.name) + N';'
FROM sys.key_constraints k
WHERE k.parent_object_id = OBJECT_ID('dbo.FrameworkParameterResponse') AND k.type = 'UQ';
EXEC sp_executesql @sql;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_FPR_Assessment_Field_Year'
               AND object_id = OBJECT_ID('dbo.FrameworkParameterResponse'))
    CREATE UNIQUE INDEX UX_FPR_Assessment_Field_Year
        ON dbo.FrameworkParameterResponse(AssessmentResponseId, ParameterFieldDefinitionId, FinancialYear);
GO

-- ---------------------------------------------------------------- FrameworkParameterScore
-- score of a parameter for one assessment (Others tab)
IF OBJECT_ID(N'dbo.FrameworkParameterScore', N'U') IS NULL
CREATE TABLE dbo.FrameworkParameterScore(
    FrameworkParameterScoreId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_FrameworkParameterScore PRIMARY KEY,
    AssessmentResponseId INT NOT NULL,
    IndustryParameterMappingId INT NOT NULL,
    CalculatedScore DECIMAL(10,2) NULL,     -- from the rule engine (e.g. average liquidity score)
    MinAllowedScore DECIMAL(10,2) NULL,     -- analyst may choose this score or worse
    AnalystScore DECIMAL(10,2) NULL,        -- score selected on the Others tab
    UpdatedOn DATETIME2 NOT NULL CONSTRAINT DF_FPS_UpdatedOn DEFAULT(SYSUTCDATETIME()),
    CONSTRAINT FK_FPS_AssessmentResponse FOREIGN KEY(AssessmentResponseId) REFERENCES dbo.AssessmentResponse(AssessmentResponseId) ON DELETE CASCADE,
    CONSTRAINT FK_FPS_IPM FOREIGN KEY(IndustryParameterMappingId) REFERENCES dbo.IndustryParameterMapping(IndustryParameterMappingId),
    CONSTRAINT UQ_FPS_Assessment_Mapping UNIQUE(AssessmentResponseId, IndustryParameterMappingId)
);
GO




Use CRISP2_UAT

/*
 CRISP 2.0 - Liquidity setup for ONE workflow version (data only, no code).
 Run 04_Liquidity_RuleEngine.sql first.
 Set the two variables below, then run. Safe to rerun (fields are matched by FieldCode).

 Field SourceType:
   Input    analyst types the value
   Spread   sum of spread rows (SpreadRows) * SpreadSign, for year + SpreadYearOffset
            (IsOverridable = 1: analyst may type another value)
   Formula  RulesEngine expression over other field codes (decimals need m: 0.02m)
   Rule     filled by the popup's score rules (RuleDefinition rows linked to the popup)
   Heading  sub-heading row inside a table (no value)
   Note     text under a table (FieldName = the text, new line = |)
   Spacer   empty row inside a table
 FieldType: Number | YesNo (dropdown) | Radio (Yes / No radio buttons)
 Formulas are calculated top to bottom by DisplayOrder: a formula may only use
 Formula fields with a lower DisplayOrder (inputs and spread values can be used anywhere).
*/

-- version to configure (see the list: SELECT WorkflowCode, VersionNo, Status FROM dbo.WorkflowJsonVersion)
DECLARE @WorkflowCode VARCHAR(128) = 'CorporateBusiness';   -- <-- workflow code
DECLARE @VersionNo INT = 1;                                    -- <-- version number

DECLARE @WorkflowJsonVersionId INT, @IndustryDetailsId INT;
SELECT @WorkflowJsonVersionId = WorkflowJsonVersionId,
       @IndustryDetailsId = IndustryDetailsId
FROM dbo.WorkflowJsonVersion
WHERE WorkflowCode = @WorkflowCode AND VersionNo = @VersionNo;

IF @WorkflowJsonVersionId IS NULL
BEGIN
    RAISERROR('Workflow version not found: check @WorkflowCode and @VersionNo (SELECT WorkflowCode, VersionNo FROM dbo.WorkflowJsonVersion).', 16, 1);
    RETURN;
END;

PRINT CONCAT('Configuring WorkflowJsonVersionId = ', @WorkflowJsonVersionId, ', IndustryDetailsId = ', @IndustryDetailsId);

-- ---------------------------------------------------------------- masters
MERGE dbo.ParameterDefinitionMaster AS t
USING (VALUES ('LIQUIDITY', 'Liquidity'),
              ('LIQ_CONTINGENT', 'Contingent Liability'),
              ('LIQ_DETAILS', 'Update Liquidity Details')) AS s(Code, Name)
ON t.ParameterCode = s.Code
WHEN NOT MATCHED THEN INSERT (ParameterCode, ParameterName, WhyItMatters, IsActive) VALUES (s.Code, s.Name, '', 1);

DECLARE @PL INT = (SELECT ParameterDefinitionMasterId FROM dbo.ParameterDefinitionMaster WHERE ParameterCode = 'LIQUIDITY');
DECLARE @PC INT = (SELECT ParameterDefinitionMasterId FROM dbo.ParameterDefinitionMaster WHERE ParameterCode = 'LIQ_CONTINGENT');
DECLARE @PD INT = (SELECT ParameterDefinitionMasterId FROM dbo.ParameterDefinitionMaster WHERE ParameterCode = 'LIQ_DETAILS');

-- ---------------------------------------------------------------- mappings
-- Liquidity row on the Others tab
IF NOT EXISTS (SELECT 1 FROM dbo.IndustryParameterMapping
               WHERE WorkflowJsonVersionId = @WorkflowJsonVersionId AND IndustryDetailsId = @IndustryDetailsId
                 AND ParameterDefinitionMasterId = @PL)
    INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId, IndustryDetailsId, ParameterDefinitionMasterId,
           ParameterDisplayName, ValueType, Weight, DisplayOrder, IsActive, StepName, ControlType)
    VALUES (@WorkflowJsonVersionId, @IndustryDetailsId, @PL, 'Liquidity', 'ManualScore', 0, 3, 1, 'Others', 'Module');

DECLARE @ML INT = (SELECT IndustryParameterMappingId FROM dbo.IndustryParameterMapping
                   WHERE WorkflowJsonVersionId = @WorkflowJsonVersionId AND IndustryDetailsId = @IndustryDetailsId
                     AND ParameterDefinitionMasterId = @PL);
UPDATE dbo.IndustryParameterMapping
SET StepName = 'Others', ControlType = 'Module', ParentIndustryParameterMappingId = NULL
WHERE IndustryParameterMappingId = @ML;

-- the two popups under Liquidity
IF NOT EXISTS (SELECT 1 FROM dbo.IndustryParameterMapping
               WHERE WorkflowJsonVersionId = @WorkflowJsonVersionId AND IndustryDetailsId = @IndustryDetailsId
                 AND ParameterDefinitionMasterId = @PC)
    INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId, IndustryDetailsId, ParameterDefinitionMasterId,
           ParentIndustryParameterMappingId, ParameterDisplayName, ValueType, Weight, DisplayOrder, IsActive, StepName, ControlType)
    VALUES (@WorkflowJsonVersionId, @IndustryDetailsId, @PC, @ML, 'Contingent Liability', 'ManualScore', 0, 1, 1, 'Others', 'Popup');

IF NOT EXISTS (SELECT 1 FROM dbo.IndustryParameterMapping
               WHERE WorkflowJsonVersionId = @WorkflowJsonVersionId AND IndustryDetailsId = @IndustryDetailsId
                 AND ParameterDefinitionMasterId = @PD)
    INSERT dbo.IndustryParameterMapping(WorkflowJsonVersionId, IndustryDetailsId, ParameterDefinitionMasterId,
           ParentIndustryParameterMappingId, ParameterDisplayName, ValueType, Weight, DisplayOrder, IsActive, StepName, ControlType)
    VALUES (@WorkflowJsonVersionId, @IndustryDetailsId, @PD, @ML, 'Update Liquidity Details', 'ManualScore', 0, 2, 1, 'Others', 'Popup');

DECLARE @MC INT = (SELECT IndustryParameterMappingId FROM dbo.IndustryParameterMapping
                   WHERE WorkflowJsonVersionId = @WorkflowJsonVersionId AND IndustryDetailsId = @IndustryDetailsId
                     AND ParameterDefinitionMasterId = @PC);
DECLARE @MD INT = (SELECT IndustryParameterMappingId FROM dbo.IndustryParameterMapping
                   WHERE WorkflowJsonVersionId = @WorkflowJsonVersionId AND IndustryDetailsId = @IndustryDetailsId
                     AND ParameterDefinitionMasterId = @PD);

-- popups are not scored themselves: they only feed the Liquidity score (no weight)
UPDATE dbo.IndustryParameterMapping
SET ParentIndustryParameterMappingId = @ML, StepName = 'Others', ControlType = 'Popup', Weight = 0
WHERE IndustryParameterMappingId IN (@MC, @MD);

-- Liquidity details: FY latest and latest + 1
UPDATE dbo.IndustryParameterMapping
SET YearFromOffset = 0,
    YearColumns = 2
WHERE IndustryParameterMappingId = @MD;

-- Liquidity score rules (RuleDefinition, linked to the popup): tried in DisplayOrder, first match wins
MERGE dbo.RuleDefinition AS t
USING (VALUES
    (1, 'LiquidityScore5', 'LC_BG_DEVOLVEMENT == "Yes" || SAR < 0', '5'),
    (2, 'LiquidityScore1', 'FIN_SURPLUS + CASH_BEGIN - PEAK_6M - BUFFER > 0', '1'),
    (3, 'LiquidityScore2', 'FIN_SURPLUS + CASH_BEGIN - PEAK_3M - BUFFER > 0', '2'),
    (4, 'LiquidityScore3', 'SARM > 0 && FIN_SURPLUS + CASH_BEGIN - BUFFER + UNDRAWN_LINES + PROPOSED_EQUITY > 0', '3'),
    (5, 'LiquidityScore4', 'true', '4')) AS s(DisplayOrder, RuleName, Expression, OutputExpression)
ON t.IndustryParameterMappingId = @MD AND t.RuleName = s.RuleName
WHEN MATCHED THEN UPDATE SET
    DisplayOrder = s.DisplayOrder, Expression = s.Expression, OutputExpression = s.OutputExpression,
    RuleExpressionType = 'LambdaExpression', IsActive = 1
WHEN NOT MATCHED THEN INSERT
    (WorkflowJsonVersionId, IndustryParameterMappingId, RuleName, RuleExpressionType, Expression, OutputExpression, DisplayOrder, IsActive)
    VALUES (@WorkflowJsonVersionId, @MD, s.RuleName, 'LambdaExpression', s.Expression, s.OutputExpression, s.DisplayOrder, 1);

-- score dropdown 1..5 for Liquidity
IF NOT EXISTS (SELECT 1 FROM dbo.ScaleConfigurationDetails WHERE IndustryParameterMappingId = @ML)
BEGIN
    DECLARE @Scale INT = (SELECT TOP 1 ScaleConfigurationId FROM dbo.ScaleConfiguration ORDER BY ScaleConfigurationId);
    INSERT dbo.ScaleConfigurationDetails(IndustryParameterMappingId, ScaleConfigurationId, ScoreValue, Definition, MinValue, MaxValue)
    VALUES (@ML, @Scale, 1, '1', 0, 0), (@ML, @Scale, 2, '2', 0, 0), (@ML, @Scale, 3, '3', 0, 0),
           (@ML, @Scale, 4, '4', 0, 0), (@ML, @Scale, 5, '5', 0, 0);
END;

-- "Show Details" panel on the Others tab (HTML)
UPDATE dbo.IndustryParameterMapping
SET DetailsDescription = N'<p>Liquidity is to be assessed over the near term. The meaning of ''near term'' would vary depending on the nature of the business.</p>
<p><u>Example:</u> If the business is seasonal, liquidity position may need to be assessed on a monthly or a quarterly basis</p>',
    DetailsNote = N'<p><b>Note:</b><br/><b>Undrawn lines of credit:</b></p>
<p>The <u>undrawn lines of credit</u> should be considered only from financial institutions <u>rated [ICRA]A1+ or equivalent</u> for assessing the liquidity profile of the entity.</p>
<p><b>Cash and bank balances:</b></p>
<p>The benefit of cash and bank balances/ DSRA/ bank guarantees in lieu of cash, is to be accorded only when these are deposited/ are from financial institutions that have a rating of [ICRA]A1+ or equivalent.</p>
<p>In <u>spreads, the above adjustment can be incorporated by re-classifying</u> the amount which has been deposited in lower rated financial institutions <u>under "Cash and Bank Balances (Encumbered Cash)"</u> in place of "Cash and Bank Balances (Unencumbered Cash)".</p>
<p><b>Debt with put/call options or debt acceleration clauses:</b></p>
<p>Based on an assessment of the likelihood of the exercise of the put/call options (such as the interest rate environment ), include such debt with put/ call options in the debt maturity profile. Also, based on an assessment of the likelihood of the breach of covenants which can trigger debt pre-payment, include the corresponding debt amount in the scheduled debt repayment. Moreover, the debt which have a cross-default on such debt should also be included in the debt repayment.</p>
<p><b>Note 2:</b><br/>
1) While the liquidity analysis has to be done over the near term, the <i>score should not get biased by a good liquidity position in any particular year</i>. As a result, the scoring should factor in the liquidity track record in the recent past (1- 2 years) as well as that projected over the next 1-2 years<br/>
2) The <u>benefit of undrawn working capital lines</u> is to be considered to the extent that Drawing Power is available against those lines at the beginning of the year</p>'
    -- TODO: add Note 2 point 3) onwards from the old screen (cut off in the screenshot)
WHERE IndustryParameterMappingId = @ML;

-- score texts in the assessment table (the dropdown keeps the short label 1..5)
UPDATE dbo.ScaleConfigurationDetails
SET ScoreDescription = N'The entity is positioned between score (3) and (5)'
WHERE IndustryParameterMappingId = @ML AND ScoreValue = 4;
-- TODO: scores 1, 2, 3 and 5 - copy the full text from the old screen, e.g.
-- UPDATE dbo.ScaleConfigurationDetails SET ScoreDescription = N'Unencumbered cash & cash equivalents at the beginning of the year + <b>Financing Surplus</b> ...'
-- WHERE IndustryParameterMappingId = @ML AND ScoreValue = 1;

-- ---------------------------------------------------------------- fields
DECLARE @S1 VARCHAR(300) = 'Provide the inputs below',
        @S2 VARCHAR(300) = 'Auto-calculated values based on inputs in the table on the left and cash flow statement',
        @SQ VARCHAR(300) = 'Question',
        @S3 VARCHAR(300) = 'Liquidity Analysis & Cash Flow Waterfall',
        @SH VARCHAR(300) = 'Hidden',
        @SC VARCHAR(300) = 'Contingent Liability';

DECLARE @F TABLE (
    MappingId INT, DisplayOrder INT, FieldCode VARCHAR(100), FieldName VARCHAR(2000), FieldType VARCHAR(50),
    SectionName VARCHAR(300), IsYearWise BIT, SourceType VARCHAR(20),
    SpreadRows VARCHAR(200), SpreadByTemplate BIT, SpreadSign SMALLINT, SpreadYearOffset INT,
    Formula NVARCHAR(2000), DefaultValue NVARCHAR(500), IsOverridable BIT, OptionsJson NVARCHAR(1000),
    IsRequired BIT, ChartSign SMALLINT, ResultRole VARCHAR(20), HelpText NVARCHAR(1000), ShowWhen VARCHAR(200));

INSERT @F VALUES
-- Contingent Liability popup (single values, used by Liquidity as CL_EXISTS / CL_AMOUNT)
(@MC, 1,'CL_EXISTS','Are there any contingent liabilities?','Radio',@SC,0,'Input',NULL,0,1,0,NULL,'No',0,'["Yes","No"]',1,NULL,NULL,NULL,NULL),
(@MC, 2,'CL_AMOUNT','Amount at risk (Rs crore)','Number',@SC,0,'Input',NULL,0,1,0,NULL,'0',0,NULL,1,NULL,NULL,NULL,'CL_EXISTS=Yes'),
(@MC, 3,'CL_NOTE','Note: * Capital commitments, export obligations, on-balance sheet liabilities such as LC-backed creditors, and explicit forms of support such as corporate guarantees extended by the rated entity are not considered for contingent liability analysis in this module.','Text',@SC,0,'Note',NULL,0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),

-- inputs (legacy parameter codes 1-11)
(@MD, 1,'WC_LIMIT_BEGIN','Actual/Expected working capital limits sanctioned at beginning of the year','Number',@S1,1,'Input',NULL,0,1,0,NULL,'0',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD, 2,'WC_UTIL_BEGIN','Actual / Expected working capital limits utilized at beginning of the year','Number',@S1,1,'Input',NULL,0,1,0,NULL,'0',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD, 3,'DP_BEGIN','Actual / Expected drawing power at beginning of the year','Number',@S1,1,'Input',NULL,0,1,0,NULL,'0',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD, 4,'WC_LIMIT_END','Actual / Expected working capital limits sanctioned at end of the year','Number',@S1,1,'Input',NULL,0,1,0,NULL,'0',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD, 5,'DP_END','Actual / Expected drawing power at end of the year','Number',@S1,1,'Input',NULL,0,1,0,NULL,'0',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD, 6,'SPACER_1','','Text',@S1,1,'Spacer',NULL,0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD, 7,'TD_SANCT_BEGIN','Actual / Expected total term debt sanctioned / raised at beginning of the year','Number',@S1,1,'Input',NULL,0,1,0,NULL,'0',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD, 8,'TD_DRAWN_BEGIN','Actual / Expected total term debt drawn-down/availed till beginning of year','Number',@S1,1,'Input',NULL,0,1,0,NULL,'0',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD, 9,'TD_ELIGIBLE_BEGIN','Total term debt eligible to be drawn-down / availed till beginning of the year','Number',@S1,1,'Input',NULL,0,1,0,NULL,'0',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD,10,'TD_SANCT_END','Actual / Expected total term debt sanctioned /raised at end of the year','Number',@S1,1,'Input',NULL,0,1,0,NULL,'0',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD,11,'SPACER_2','','Text',@S1,1,'Spacer',NULL,0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,12,'TD_FUNDED_REQ','Out of the total funding requirements (capex, investment etc.), amount to be funded by term debt','Number',@S1,1,'Spread','268',0,-1,0,NULL,NULL,1,NULL,1,NULL,NULL,NULL,NULL),
(@MD,13,'PROMOTER_LOAN','Actual / Expected promoter loan infused during the year','Number',@S1,1,'Input',NULL,0,1,0,NULL,'0',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD,14,'NOTE_INPUTS','Note: 1.Blue star (*)-The default values calculated in these fields can be overridden if the actual values are different.|2. Inputs in cells (Actual/Expected total term debt sanctioned/raised at beginning of the year) (actual utilization) and (Actual/Expected total term debt drawn-down/availed till beginning of year) (eligible utilization) could be different in scenarios where the entity may have either front-ended the equity infusion or may have used internal accruals/ other sources to meet the previous period capex, investments, other funding requirements (instead of drawing on the entire eligible term loan/ corporate loan).','Text',@S1,1,'Note',NULL,0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),

-- auto-calculated (legacy 12-20)
(@MD,20,'HDR_UNDRAWN_WC','Amount of undrawn / available working capital limits','Heading',@S2,1,'Heading',NULL,0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,21,'UNDRAWN_WC_BEGIN','With respect to the Drawing Power at beginning of the year','Number',@S2,1,'Formula',NULL,0,1,0,'Math.Max(Math.Min(WC_LIMIT_BEGIN, DP_BEGIN) - WC_UTIL_BEGIN, 0m)',NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,22,'UNDRAWN_WC_END','With respect to the expected Drawing Power at end of the year','Number',@S2,1,'Formula',NULL,0,1,0,'0m',NULL,0,NULL,0,NULL,NULL,NULL,NULL),            -- TODO legacy CalculateLiquidity formula
(@MD,23,'HDR_UNDRAWN_TD','Amount of undrawn / available term debt','Heading',@S2,1,'Heading',NULL,0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,24,'UNDRAWN_TD_BEGIN','With respect to the eligibility to utilize the debt at beginnig of the year','Number',@S2,1,'Formula',NULL,0,1,0,'Math.Max(Math.Min(TD_SANCT_BEGIN - TD_DRAWN_BEGIN, TD_ELIGIBLE_BEGIN), 0m)',NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,25,'UNDRAWN_TD_CAPEX','With respect to the projected capex, investment etc. during the year','Number',@S2,1,'Formula',NULL,0,1,0,'0m',NULL,0,NULL,0,NULL,NULL,NULL,NULL),           -- TODO legacy CalculateLiquidity formula
(@MD,26,'CAPEX_INCURRED','Capex incurred during the year','Number',@S2,1,'Spread','268',0,-1,0,NULL,NULL,1,NULL,1,NULL,NULL,NULL,NULL),
(@MD,27,'PEAK_6M','Peak 6 months of debt servicing (principal + interest) during next 12 months','Number',@S2,1,'Formula',NULL,0,1,0,'DEBT_INT_NEXT / 2',NULL,1,NULL,1,NULL,NULL,NULL,NULL),   -- check with CalculateLiquidity
(@MD,28,'PEAK_3M','Peak 3 months of debt servicing (principal + interest) during next 12 months','Number',@S2,1,'Formula',NULL,0,1,0,'PEAK_6M / 2',NULL,1,NULL,1,NULL,NULL,NULL,NULL),
(@MD,29,'WC_MARGIN_PCT','Margin for working capital(%)','Number',@S2,1,'Input',NULL,0,1,0,NULL,'25',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD,30,'CAPEX_MARGIN_PCT','Margin for capital expenditure(%)','Number',@S2,1,'Input',NULL,0,1,0,NULL,'25',0,NULL,1,NULL,NULL,NULL,NULL),
(@MD,31,'NOTE_AUTO','Note: 1.Blue star (*)-The default values calculated in these fields can be overridden if the actual values are different.|2. The figures in cell (With respect to the Drawing Power at beginning of the year) & ( With respect to the eligibility to utilize the debt at beginnig of the year) correspond to the amount which was not utilized by the entity for meeting its funding requirements, despite the entity being eligible to draw the loan amount. Such a scenario would unfold when the entity met the funding requirement from its own funds or other sources. Thus this undrawn amount is available to be utilized by the entity to fund its sundry needs during the year.|The figures in cells (With respect to the expected Drawing Power at end of the year) & ( With respect to the projected capex, investment etc. during the year) reflect the amount which the entity can utilize to meet its projected funding needs for working capital, capex etc;','Text',@S2,1,'Note',NULL,0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),

(@MD,35,'LC_BG_DEVOLVEMENT','Are there continuous LC/BG devolvements and/or overdrawals in working capital utilization with respect to drawing power/ sanctioned limits?','YesNo',@SQ,0,'Input',NULL,0,1,0,NULL,'No',0,'["Yes","No"]',1,NULL,NULL,NULL,NULL),

-- waterfall (legacy 20-32) + the score rows, in one table like the old screen
(@MD,40,'CFO','Cash Flow from Operations after adjusting for non-operating income and WC changes','Number',@S3,1,'Spread','264,265',0,1,0,NULL,NULL,0,NULL,0,1,NULL,NULL,NULL),
(@MD,41,'CASH_BEGIN','Cash and Liquid Investments (beginning of the year)','Number',@S3,1,'Spread','104,105',0,1,-1,NULL,NULL,0,NULL,0,1,NULL,NULL,NULL),
(@MD,42,'DEBT_REPAY','Debt Repayment','Number',@S3,1,'Spread','270,271',0,-1,0,NULL,NULL,0,NULL,0,-1,NULL,NULL,NULL),
(@MD,43,'CAPEX','Capex','Number',@S3,1,'Spread','268',0,-1,0,NULL,NULL,0,NULL,0,-1,NULL,NULL,NULL),
(@MD,44,'DIVIDEND','Dividend Payout / Share Buyback','Number',@S3,1,'Spread','353,363',1,-1,0,NULL,NULL,0,NULL,0,-1,NULL,NULL,NULL),
(@MD,45,'CHG_INVEST','Increase/ (Decrease) in Investments','Number',@S3,1,'Formula',NULL,0,1,0,'-(SP_273_274 + SP_104 - SP_104_PREV - SP_106 + SP_106_PREV)',NULL,0,NULL,0,-1,NULL,NULL,NULL),
(@MD,46,'CHG_OTHER','Increase / (Decrease) in Other items','Number',@S3,1,'Formula',NULL,0,1,0,'-(SP_275_277 - SP_58)',NULL,0,NULL,0,-1,NULL,NULL,NULL),
(@MD,47,'SALES_2PCT','2% of Net Sales','Number',@S3,1,'Formula',NULL,0,1,0,'NET_SALES * 0.02m',NULL,0,NULL,0,-1,NULL,NULL,NULL),
(@MD,48,'CONT_LIAB','Contingent Liability','Number',@S3,1,'Formula',NULL,0,1,0,'CL_EXISTS == "Yes" ? CL_AMOUNT : 0m',NULL,0,NULL,0,-1,NULL,NULL,NULL),
(@MD,49,'SURPLUS','Surplus/ (Deficit)','Number',@S3,1,'Formula',NULL,0,1,0,'CFO + CASH_BEGIN - (DEBT_REPAY + CAPEX + DIVIDEND + CHG_INVEST + CHG_OTHER + SALES_2PCT + CONT_LIAB)',NULL,0,NULL,0,0,NULL,NULL,NULL),
(@MD,50,'UNDRAWN_LINES','Undrawn / Available Lines of Credit','Number',@S3,1,'Formula',NULL,0,1,0,'UNDRAWN_WC_BEGIN + UNDRAWN_TD_BEGIN',NULL,0,NULL,0,1,NULL,NULL,NULL),
(@MD,51,'PROPOSED_EQUITY','Proposed equity and promoter loan','Number',@S3,1,'Spread','285',0,1,0,NULL,NULL,0,NULL,0,1,NULL,NULL,NULL),

-- hidden values used by the score rules (legacy #tmpSpreadDataForCalC)
(@MD,55,'BUFFER','Buffer (2% of sales + contingent liability)','Number',@SH,1,'Formula',NULL,0,1,0,'SALES_2PCT + CONT_LIAB',NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,56,'FIN_SURPLUS','Financing Surplus / (Requirements)','Number',@SH,1,'Formula',NULL,0,1,0,'SP_278 - SP_268 + SP_104 - SP_104_PREV - SP_106 + SP_106_PREV - SP_58 - CAPEX_INCURRED',NULL,0,NULL,0,NULL,NULL,NULL,NULL),

-- score: per year from the rules, then average and lowest allowed
(@MD,60,'LIQ_SCORE','Liquidity Score','Number',@S3,1,'Rule',NULL,0,1,0,NULL,NULL,0,NULL,0,NULL,'Score',NULL,NULL),
(@MD,61,'LIQ_AVG_SCORE','Average Liquidity Score','Number',@S3,0,'Formula',NULL,0,1,0,'Math.Floor((LIQ_SCORE_Y1 + LIQ_SCORE_Y2) / 2m + 0.5m)',NULL,0,NULL,0,NULL,'ParentScore',NULL,NULL),
(@MD,62,'LIQ_MIN_SCORE','Lowest allowed Liquidity Score','Number',@SH,0,'Formula',NULL,0,1,0,'Math.Min(LIQ_AVG_SCORE, LIQ_SCORE_Y2)',NULL,0,NULL,0,NULL,'MinScore',NULL,NULL),

-- spread values only used inside formulas
(@MD,70,'SP_268','Spread row 268','Number',@SH,1,'Spread','268',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,71,'SP_278','Spread row 278','Number',@SH,1,'Spread','278',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,72,'SP_273_274','Spread rows 273,274','Number',@SH,1,'Spread','273,274',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,73,'SP_104','Spread row 104','Number',@SH,1,'Spread','104',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,74,'SP_104_PREV','Spread row 104 (previous year)','Number',@SH,1,'Spread','104',0,1,-1,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,75,'SP_106','Spread row 106','Number',@SH,1,'Spread','106',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,76,'SP_106_PREV','Spread row 106 (previous year)','Number',@SH,1,'Spread','106',0,1,-1,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,77,'SP_275_277','Spread rows 275,277','Number',@SH,1,'Spread','275,277',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,78,'SP_58','Spread row 58','Number',@SH,1,'Spread','58',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,79,'NET_SALES','Net Sales','Number',@SH,1,'Spread','18',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,80,'DEBT_INT','Debt + Interest','Number',@SH,1,'Spread','261',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,81,'WC_REQ','Working capital requirement','Number',@SH,1,'Spread','263',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,82,'SARM','Surplus after repayment, margin funding and 1 month of debt servicing','Number',@SH,1,'Spread','262,265',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,83,'SAR','Surplus cash flows after repayment','Number',@SH,1,'Spread','262,265',0,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,84,'DEBT_REPAY_NEXT','Debt Repayment (next year)','Number',@SH,1,'Spread','270,271',0,-1,1,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL),
(@MD,85,'DEBT_INT_NEXT','Debt + Interest (next year)','Number',@SH,1,'Spread','261',0,1,1,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL);

MERGE dbo.ParameterFieldDefinition AS t
USING @F AS s
ON t.IndustryParameterMappingId = s.MappingId AND t.FieldCode = s.FieldCode
WHEN MATCHED THEN UPDATE SET
    DisplayOrder = s.DisplayOrder, FieldName = s.FieldName, FieldType = s.FieldType, SectionName = s.SectionName,
    IsYearWise = s.IsYearWise, SourceType = s.SourceType, SpreadRows = s.SpreadRows, SpreadByTemplate = s.SpreadByTemplate,
    SpreadSign = s.SpreadSign, SpreadYearOffset = s.SpreadYearOffset, Formula = s.Formula, DefaultValue = s.DefaultValue,
    IsOverridable = s.IsOverridable, OptionsJson = s.OptionsJson, IsRequired = s.IsRequired, ChartSign = s.ChartSign,
    ResultRole = s.ResultRole, HelpText = s.HelpText, ShowWhen = s.ShowWhen, IsActive = 1
WHEN NOT MATCHED THEN INSERT
    (IndustryParameterMappingId, DisplayOrder, FieldCode, FieldName, FieldType, SectionName, IsYearWise, SourceType,
     SpreadRows, SpreadByTemplate, SpreadSign, SpreadYearOffset, Formula, DefaultValue, IsOverridable, OptionsJson,
     IsRequired, ChartSign, ResultRole, HelpText, ShowWhen, IsActive)
VALUES
    (s.MappingId, s.DisplayOrder, s.FieldCode, s.FieldName, s.FieldType, s.SectionName, s.IsYearWise, s.SourceType,
     s.SpreadRows, s.SpreadByTemplate, s.SpreadSign, s.SpreadYearOffset, s.Formula, s.DefaultValue, s.IsOverridable, s.OptionsJson,
     s.IsRequired, s.ChartSign, s.ResultRole, s.HelpText, s.ShowWhen, 1);

-- fields from an earlier run that are no longer in the list above
UPDATE f SET IsActive = 0
FROM dbo.ParameterFieldDefinition f
WHERE f.IndustryParameterMappingId IN (@MC, @MD)
  AND NOT EXISTS (SELECT 1 FROM @F s WHERE s.MappingId = f.IndustryParameterMappingId AND s.FieldCode = f.FieldCode);
GO